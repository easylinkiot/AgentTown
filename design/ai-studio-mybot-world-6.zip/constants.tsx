
import React from 'react';
import { ShoppingBag, CheckSquare, FileText, Calendar } from 'lucide-react';
import { ChatMessage, FloatingMenuItem } from './types';

export const CHAT_DATA: ChatMessage[] = [
  {
    id: 'group_14',
    name: 'David + Elon + Sarah 9 people',
    avatar: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=200&h=200&fit=crop', // Group of people
    message: '子非鱼: 👌',
    time: '3:30 AM',
    highlight: true,
    unreadCount: 2
  },
  {
    id: '2',
    name: 'Jason + Steve + Sarah 4 people',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop', // Creative Man
    message: '@Jason We should align on the prototype first',
    time: '8:17 AM',
  },
  {
    id: '3',
    name: 'Subscription Account',
    avatar: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?w=200&h=200&fit=crop', // Business Professional
    message: 'User behavior report: Confirmed, 68% of users...',
    time: '8:13 AM',
    unreadCount: 8,
    isSystem: true,
  },
  {
    id: '4',
    name: 'Evan Huang',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop', // Real Man Portrait
    message: '[Voice Call]',
    time: '8:07 AM',
    isVoiceCall: true,
  },
  {
    id: '5',
    name: 'yy',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop', // Real Woman Portrait
    message: 'The lighting zones messed up the baking, so let\'s discuss...',
    time: '6:47 AM',
  },
  {
    id: '6',
    name: 'yy + Sven + Evan 5 people',
    avatar: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=200&h=200&fit=crop', // Person profile
    message: 'yy: Let\'s sync up tomorrow morning before submission...',
    time: '6:35 AM',
  },
  {
    id: '7',
    name: 'Chang Cheng',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop', // Smiling Man
    message: 'Okay, sounds good.',
    time: '6:12 AM',
  },
  {
    id: '8',
    name: 'Mike + Alex + Jason 4 people',
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea86b48e?w=200&h=200&fit=crop', // Office setting
    message: 'Meeting notes attached.',
    time: 'Yesterday',
  },
  {
    id: '9',
    name: 'Sarah + David + Admin 12 people',
    avatar: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=200&h=200&fit=crop', // Professional Woman
    message: 'New campaign assets are ready for review.',
    time: 'Yesterday',
  },
];

export const TOWN_MENU_ITEMS: FloatingMenuItem[] = [
  {
    id: 'market',
    label: 'Market',
    icon: <ShoppingBag size={18} className="text-orange-500" />,
    position: { top: '30%', left: '25%' },
  },
  {
    id: 'tasks',
    label: 'Tasks',
    icon: <CheckSquare size={18} className="text-green-500" />,
    position: { top: '45%', right: '15%' },
  },
  {
    id: 'docs',
    label: 'Docs',
    icon: <FileText size={18} className="text-blue-500" />,
    position: { top: '25%', right: '20%' },
  },
  {
    id: 'calendar',
    label: 'Calendar',
    icon: <Calendar size={18} className="text-purple-500" />,
    position: { top: '40%', left: '10%' },
  },
];

export const SIDE_AVATARS = [
  'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&h=200&fit=crop', // Real Man
];

export const AI_TEAM_MEMBERS = [
  {
    id: 'elon',
    name: 'Elon',
    avatar: 'https://images.unsplash.com/photo-1548543604-a87c9909abec?w=200&h=200&fit=crop', // Intense look
    role: 'First Principles',
    instruction: 'You are Elon. You communicate using First Principles thinking. You ignore analogy and boil things down to the most fundamental truths, then reason up from there. You are obsessed with physics, efficiency, and scale. You are direct, sometimes blunt, and focused on solving hard engineering problems.'
  },
  {
    id: 'jobs',
    name: 'Steve',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop', // Intellectual look with glasses
    role: 'Product Vision',
    instruction: 'You are Steve. You focus entirely on the Brand and the Product Experience. You are a perfectionist. You care about aesthetics, simplicity, and intuition. You do not compromise on quality. You are persuasive (Reality Distortion Field) and demand excellence. Ask "Is this the very best we can do?"'
  },
  {
    id: 'cto',
    name: 'David (CTO)',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop', // Tech lead look
    role: 'Technical',
    instruction: 'You are the CTO. You evaluate everything through the lens of technical feasibility, architecture, scalability, and security. You care about the tech stack, code quality, and reducing technical debt.'
  },
  {
    id: 'coo',
    name: 'Sarah (COO)',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop', // Professional woman
    role: 'Operations',
    instruction: 'You are the COO. You focus on operations, logistics, execution, and cost-efficiency. You care about the "how" and "when". You ensure processes are streamlined and the business runs smoothly.'
  },
  {
    id: 'consumer',
    name: 'Alex (User)',
    avatar: 'https://images.unsplash.com/photo-1595152772835-219674b2a8a6?w=200&h=200&fit=crop', // Young white male
    role: 'Consumer',
    instruction: 'You are a typical end-user consumer. You care about price, convenience, ease of use, and emotional satisfaction. You don\'t care about the tech stack; you care if it solves your problem and makes you feel good. You provide raw, honest feedback.'
  },
  {
    id: 'owner',
    name: 'Mike (Store)',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop', // Store owner look
    role: 'Store Owner',
    instruction: 'You are a franchise store owner. You care about foot traffic, profit margins, inventory management, and customer satisfaction in the physical world. You are practical and business-minded.'
  }
];

export const CONTACTS = [
  {
    id: 'c_evan',
    name: 'Evan Huang',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
    role: 'Hardware Lead',
    bio: 'Focusing on Powerhoo100 OTA updates.'
  },
  {
    id: 'c_zifeiyu',
    name: '子非鱼',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200&h=200&fit=crop',
    role: 'Product Owner',
    bio: 'Tracking milestones and batch failures.'
  },
  {
    id: 'c_changcheng',
    name: '常城',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
    role: 'Engineering',
    bio: 'Handling logistics and cancellations.'
  },
   {
    id: 'c_yy',
    name: 'yy',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop',
    role: 'Design',
    bio: 'Lighting zones and baking textures.'
  },
  {
    id: 'c_sven',
    name: 'Sven',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
    role: 'UI Designer',
    bio: 'Minimalist interface advocate.'
  }
];
