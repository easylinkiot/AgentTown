
import React, { useState } from 'react';
import { Newspaper, BookOpen, Tag, Plus, Minus, CheckSquare, ChevronRight, Clock, Zap, Utensils, Coffee, AlertTriangle } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { MiniApp, TaskItem } from '../types';

interface MiniAppWidgetProps {
  apps: MiniApp[]; 
  tasks: TaskItem[];
  onOpenApp: (app: MiniApp) => void;
  onOpenCreator: () => void;
  onQuickCreate: (type: string) => void;
  onMinimize?: () => void;
  onDeleteApp: (id: string) => void;
}

const ControlButton = ({ icon, label, onClick, colorClass, active, onDelete }: any) => (
  <div className="relative group w-full h-[64px]">
    <button 
        onClick={onClick}
        className={`${active ? 'bg-white/20 ring-1 ring-white/50' : 'bg-white/5 hover:bg-white/10'} border border-white/5 rounded-2xl p-2 flex flex-col items-center justify-center gap-1.5 h-full w-full transition-all active:scale-95 relative overflow-hidden`}
    >
        <div className={`w-6 h-6 rounded-full ${colorClass} flex items-center justify-center text-white shadow-sm shrink-0`}>
            {icon}
        </div>
        <span className="text-[10px] font-medium text-white/90 leading-none truncate max-w-full">{label}</span>
    </button>
    {onDelete && (
        <button 
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
            className="absolute -top-2 -right-2 w-6 h-6 bg-[#2c2c2e] text-red-500 border border-white/20 rounded-full flex items-center justify-center shadow-xl opacity-0 group-hover:opacity-100 transition-opacity z-20 hover:bg-red-500 hover:text-white hover:border-red-500"
        >
            <Minus size={14} strokeWidth={3} />
        </button>
    )}
  </div>
);

const QUICK_ACTIONS = [
  { id: 'quick_news', label: '关注', icon: Newspaper, color: 'bg-blue-500', type: 'create', param: 'news' },
  { id: 'quick_price', label: '比价', icon: Tag, color: 'bg-orange-500', type: 'create', param: 'price' },
  { id: 'quick_words', label: '单词', icon: BookOpen, color: 'bg-purple-500', type: 'create', param: 'words' },
  { id: 'quick_tasks', label: '待办', icon: CheckSquare, color: 'bg-green-500', type: 'toggle_tasks', param: '' },
  { id: 'quick_food', label: '点餐', icon: Utensils, color: 'bg-red-500', type: 'create', param: 'food' },
  { id: 'quick_weekend', label: '周末', icon: Coffee, color: 'bg-teal-500', type: 'create', param: 'weekend' },
];

const MiniAppWidget: React.FC<MiniAppWidgetProps> = ({ apps, onOpenApp, onOpenCreator, onQuickCreate, onMinimize, tasks, onDeleteApp }) => {
  const [showTasks, setShowTasks] = useState(false);
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);
  const [hiddenQuickActions, setHiddenQuickActions] = useState<string[]>([]);

  const confirmDelete = () => {
    if (deleteCandidateId) {
        if (deleteCandidateId.startsWith('quick_')) {
            setHiddenQuickActions(prev => [...prev, deleteCandidateId]);
        } else {
            onDeleteApp(deleteCandidateId);
        }
        setDeleteCandidateId(null);
    }
  };

  return (
    <div className="w-full bg-[#1c1c1e]/60 backdrop-blur-xl rounded-[32px] shadow-2xl border border-white/10 p-4 animate-fade-in-up flex flex-col gap-4 relative">
        
        {/* Delete Confirmation Overlay */}
        {deleteCandidateId && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm rounded-[32px] animate-fade-in">
                <div className="bg-[#2c2c2e] p-5 rounded-3xl border border-white/10 w-[85%] shadow-2xl animate-scale-in flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-red-500/20 text-red-500 rounded-full flex items-center justify-center mb-3">
                        <AlertTriangle size={24} />
                    </div>
                    <h3 className="text-sm font-bold text-white mb-1">Remove Item?</h3>
                    <p className="text-[10px] text-gray-400 mb-4 px-2">
                        Are you sure you want to remove this item from your dashboard?
                    </p>
                    <div className="flex gap-3 w-full">
                        <button 
                            onClick={() => setDeleteCandidateId(null)} 
                            className="flex-1 bg-white/10 hover:bg-white/20 text-white text-xs font-bold py-2.5 rounded-xl transition-colors"
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={confirmDelete} 
                            className="flex-1 bg-red-500 hover:bg-red-600 text-white text-xs font-bold py-2.5 rounded-xl transition-colors shadow-lg shadow-red-500/20"
                        >
                            Remove
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* Top Row: Create App + Minimize */}
        <div className="flex items-center gap-3">
             <button 
                onClick={onOpenCreator}
                className="flex-1 bg-white/5 hover:bg-white/10 border border-white/5 rounded-[24px] p-2 pr-4 flex items-center justify-between group transition-all active:scale-[0.98] h-[64px]"
            >
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-white/10 to-white/5 flex items-center justify-center border border-white/10 group-hover:border-white/20 ml-1">
                        <Plus size={18} className="text-white" />
                    </div>
                    <div className="text-left">
                        <div className="text-sm font-bold text-white group-hover:text-blue-200 transition-colors">Create Mini App</div>
                        <div className="text-[10px] text-white/50">Describe to generate</div>
                    </div>
                </div>
                <div className="bg-white/10 p-1.5 rounded-full text-white/50 group-hover:text-white group-hover:bg-white/20 transition-all">
                    <ChevronRight size={16} />
                </div>
            </button>

            {onMinimize && (
                <button 
                    onClick={(e) => { e.stopPropagation(); onMinimize(); }}
                    className="w-[64px] h-[64px] flex items-center justify-center bg-white/5 hover:bg-white/10 rounded-[24px] text-white/50 hover:text-white transition-colors border border-white/5 active:scale-95 shrink-0"
                >
                    <Minus size={24} />
                </button>
            )}
        </div>

        {/* Action Grid (Horizontal Scroll) */}
        <div className="flex gap-2.5 overflow-x-auto no-scrollbar snap-x pb-2 -mx-1 px-1">
            {/* Quick Actions */}
            {QUICK_ACTIONS.filter(qa => !hiddenQuickActions.includes(qa.id)).map(qa => (
                <div key={qa.id} className="min-w-[22%] snap-start">
                    <ControlButton
                        onClick={() => {
                            if (qa.type === 'toggle_tasks') setShowTasks(!showTasks);
                            else onQuickCreate(qa.param);
                        }}
                        icon={<qa.icon size={12} />}
                        label={qa.label}
                        colorClass={qa.type === 'toggle_tasks' ? (showTasks ? "bg-green-500" : "bg-white/20") : qa.color}
                        active={qa.type === 'toggle_tasks' && showTasks}
                        onDelete={() => setDeleteCandidateId(qa.id)}
                    />
                </div>
            ))}

            {/* Installed Apps */}
            {apps.map((app) => {
                 const IconComponent = (LucideIcons as any)[app.icon] || Zap;
                 return (
                    <div key={app.id} className="min-w-[22%] snap-start">
                      <ControlButton 
                          onClick={() => onOpenApp(app)}
                          icon={<IconComponent size={12} />}
                          label={app.title.slice(0, 5)}
                          colorClass={app.color || 'bg-gray-500'}
                          onDelete={() => setDeleteCandidateId(app.id)}
                      />
                    </div>
                 );
            })}
        </div>

        {/* Integrated Tasks */}
        {showTasks && (
            <div className="bg-black/20 rounded-[24px] p-2 border border-white/5 animate-fade-in">
                 <div className="flex items-center justify-between px-2 mb-2">
                    <span className="text-[10px] font-bold text-white/60 uppercase tracking-wider">Active Tasks</span>
                    <span className="text-[9px] font-bold bg-white/10 px-2 py-0.5 rounded-full text-white/60">{tasks.length}</span>
                 </div>
                 <div className="space-y-1">
                    {tasks.length > 0 ? (
                        tasks.slice(0, 3).map((task, idx) => (
                            <div key={idx} className="flex items-center gap-3 p-2.5 bg-white/5 hover:bg-white/10 rounded-[18px] border border-white/5 transition-colors group/item">
                                <div className={`w-1.5 h-1.5 rounded-full ${task.priority === 'High' ? 'bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.6)]' : 'bg-blue-500'}`}></div>
                                <div className="flex-1 min-w-0">
                                    <div className="text-[11px] text-gray-200 font-medium truncate group-hover/item:text-white">{task.title}</div>
                                    <div className="text-[9px] text-gray-500 flex items-center gap-1 mt-0.5">
                                       <Clock size={8}/> Today
                                    </div>
                                </div>
                                <input type="checkbox" className="w-4 h-4 rounded-full border-2 border-white/20 bg-transparent checked:bg-green-500 appearance-none cursor-pointer transition-colors" />
                            </div>
                        ))
                    ) : (
                        <div className="py-4 text-center">
                            <p className="text-[10px] text-white/30">No active tasks</p>
                        </div>
                    )}
                 </div>
            </div>
        )}

    </div>
  );
};

export default MiniAppWidget;
