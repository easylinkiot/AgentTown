
import React from 'react';
import { Plus } from 'lucide-react';
import { TeamMember } from '../types';

interface MyTeamBarProps {
  members: TeamMember[];
  onMemberClick: (member: TeamMember) => void;
  onAddClick: () => void;
}

const MyTeamBar: React.FC<MyTeamBarProps> = ({ members, onMemberClick, onAddClick }) => {
  return (
    <div className="w-full flex items-end justify-center pointer-events-none pb-4">
      {/* Dock Container - Capsule Shape */}
      <div className="bg-[#1c1c1e]/90 backdrop-blur-2xl border border-white/10 rounded-full shadow-[0_8px_32px_rgba(0,0,0,0.5)] pointer-events-auto ring-1 ring-white/5 relative max-w-[85vw] overflow-hidden">
        
        {/* Scrollable Area */}
        <div className="flex items-center gap-3 px-4 py-3 overflow-x-auto no-scrollbar scroll-smooth">
            {members.map((member) => (
            <button
                key={member.id}
                onClick={() => onMemberClick(member)}
                className="group relative flex flex-col items-center justify-center transition-transform active:scale-95 shrink-0"
            >
                {/* Avatar Container - Squircle */}
                <div className="w-[42px] h-[42px] rounded-[14px] overflow-hidden border border-white/10 group-hover:border-white/40 transition-colors shadow-lg relative bg-gray-800">
                    <img 
                        src={member.avatar} 
                        alt={member.name} 
                        className="w-full h-full object-cover"
                    />
                    {/* Online Indicator (Green Dot) */}
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#00e676] border-[2px] border-[#1c1c1e] rounded-full"></div>
                </div>
                
                {/* Tooltip on Hover */}
                <div className="absolute bottom-full mb-3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                    <div className="bg-black/90 backdrop-blur-md text-white text-[10px] font-bold px-2 py-1 rounded-lg border border-white/10 whitespace-nowrap shadow-xl">
                        {member.name}
                    </div>
                </div>
            </button>
            ))}

            {/* Vertical Divider */}
            <div className="w-[1px] h-6 bg-white/10 mx-1 shrink-0"></div>

            {/* Add Member Button */}
            <button 
                onClick={onAddClick}
                className="w-[42px] h-[42px] rounded-[14px] bg-white/5 hover:bg-white/10 border border-white/10 border-dashed flex items-center justify-center text-white/40 hover:text-white transition-all active:scale-95 shrink-0 group"
            >
                <Plus size={20} className="group-hover:scale-110 transition-transform"/>
            </button>
        </div>
      </div>
    </div>
  );
};

export default MyTeamBar;
