
import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, MoreHorizontal, Smile, Plus, Wifi, Send, Sparkles, X, Clock, User, Lightbulb, ArrowUp, Briefcase, MessageSquare, Check, PlusCircle, UserPlus, Search, Users, Minus } from 'lucide-react';
import { ChatMessage, TaskItem, Message } from '../types';
import { AI_TEAM_MEMBERS, CONTACTS } from '../constants';
import { GoogleGenAI, Type } from "@google/genai";

interface ChatDetailScreenProps {
  chat: ChatMessage;
  onBack: () => void;
  onAddTask: (task: TaskItem) => void;
  systemInstruction?: string;
  variant?: 'default' | 'embedded';
  // Props for persistence & minimize
  history?: Message[];
  onUpdateMessages?: (msgs: Message[]) => void;
  onMinimize?: () => void;
}

interface AiContextState {
  mode: 'idle' | 'loading' | 'reply' | 'task' | 'brainstorm' | 'custom';
  data: any;
}

const POWERHOO_MESSAGES: Message[] = [
  {
    id: '1',
    senderName: 'Cathy (厨房业务)',
    senderAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop',
    content: '这个问题可以先用这个 UI 的配色，目前的颜色对比度不够。',
    type: 'reply',
    replyContext: '李震铭: 开关状态看起来不是很明显',
    isMe: false,
    time: '昨天 10:40 PM'
  },
  {
    id: '2',
    senderName: 'Evan Huang',
    senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
    content: '',
    type: 'voice',
    voiceDuration: '4"',
    isMe: false,
    time: '昨天 10:45 PM'
  },
  {
    id: '3',
    senderName: 'Sven',
    senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
    content: '👌，那我更新成这一版的 UI。话说 AI 界面是否该追求极简？',
    type: 'text',
    isMe: false,
  },
  {
    id: '4',
    senderName: '子非鱼',
    senderAvatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200&h=200&fit=crop',
    content: '@Evan Huang 周工邮寄订单先取消，目前看 Powerhoo100 低电量 OTA 无法更新。硬件初创如何处理这种批次故障？',
    type: 'text',
    isMe: false,
    time: '3:30 AM'
  },
  {
    id: '5',
    senderName: '常城',
    senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
    content: '已经取消了。',
    type: 'text',
    isMe: false,
  },
  {
    id: '6',
    senderName: '子非鱼',
    senderAvatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200&h=200&fit=crop',
    content: '👌',
    type: 'text',
    isMe: false,
    time: '3:30 AM'
  },
];

const ChatDetailScreen: React.FC<ChatDetailScreenProps> = ({ 
    chat, 
    onBack, 
    onAddTask, 
    systemInstruction, 
    variant = 'default',
    history,
    onUpdateMessages,
    onMinimize
}) => {
  const isEmbedded = variant === 'embedded';

  const bubbleTextClass = isEmbedded ? "text-[12px] leading-snug" : "text-[15px] leading-snug";
  const bubblePaddingClass = isEmbedded ? "px-3 py-2 min-h-[32px]" : "px-4 py-2.5 min-h-[42px]";
  const avatarClass = isEmbedded ? "w-8 h-8 rounded-lg" : "w-10 h-10 rounded-[14px]";
  const senderNameClass = isEmbedded ? "text-[9px]" : "text-[11px]";
  const timeClass = isEmbedded ? "text-[9px]" : "text-[10px]";
  const headerTitleClass = isEmbedded ? "text-[13px]" : "text-[17px]";
  const inputClass = isEmbedded ? "text-[12px]" : "text-[15px]";
  const iconScale = isEmbedded ? 0.8 : 1;

  const [messages, setMessages] = useState<Message[]>(() => {
    // If history is provided from parent, use it.
    if (history && history.length > 0) return history;
    
    // Fallback to defaults
    if (chat.id === 'group_14') return POWERHOO_MESSAGES;
    return [{
      id: 'init',
      senderName: chat.name,
      senderAvatar: chat.avatar,
      content: chat.message || '你好！我是你的 AI 创业导师。让我们聊聊你的项目吧。',
      type: 'text',
      isMe: false,
      time: '刚刚'
    }];
  });
  
  const [inputValue, setInputValue] = useState('');
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState('');
  const [addedTasks, setAddedTasks] = useState<Set<number>>(new Set());
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [aiContext, setAiContext] = useState<AiContextState>({ mode: 'idle', data: null });
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  
  // Multi-selection state
  const [selectedMemberIds, setSelectedMemberIds] = useState<Set<string>>(new Set());

  // Active Group Participants (Initialized with defaults for demo)
  const [groupParticipants, setGroupParticipants] = useState<Set<string>>(() => {
      const initial = new Set<string>();
      // Always add the current chat counterpart if it exists in our constants
      // Also add some defaults for the group chat demo
      if (chat.id === 'group_14') {
          initial.add('elon');
          initial.add('jobs');
          initial.add('c_evan');
      }
      return initial;
  });

  // Mention Popover State
  const [mentionSearch, setMentionSearch] = useState<{ active: boolean; query: string }>({ active: false, query: '' });

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync messages back to parent whenever they change
  useEffect(() => {
      if (onUpdateMessages) {
          onUpdateMessages(messages);
      }
  }, [messages, onUpdateMessages]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isAiThinking]);

  useEffect(() => {
    setAiContext({ mode: 'idle', data: null });
    setCustomPrompt('');
    setAddedTasks(new Set());
  }, [activeMessageId]);

  // Reset selections when modal opens/closes
  useEffect(() => {
      if (!showAddMemberModal) {
          setSelectedMemberIds(new Set());
      }
  }, [showAddMemberModal]);

  // Handle Input Change for Mentions
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setInputValue(val);

      // Regex to detect if user is typing a mention at the end (e.g., "Hello @St")
      // Matches @ followed by non-whitespace characters at the end of string
      const match = val.match(/@([^@\s]*)$/);
      if (match) {
          setMentionSearch({ active: true, query: match[1].toLowerCase() });
      } else {
          setMentionSearch({ active: false, query: '' });
      }
  };

  const handleSelectMention = (name: string) => {
      // Replace the query part with the full name
      // e.g., "Hello @St" -> "Hello @Steve "
      const newValue = inputValue.replace(/@([^@\s]*)$/, `@${name} `);
      setInputValue(newValue);
      setMentionSearch({ active: false, query: '' });
      inputRef.current?.focus();
  };

  // Helper to generate AI reply
  const generateReply = async (prompt: string, instruction: string, senderName: string, avatar: string) => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const historyContext = messages.slice(-10).map(m => ({
            role: m.isMe ? 'user' : 'model',
            parts: [{ text: `${m.senderName ? m.senderName + ': ' : ''}${m.content}` }]
        }));

        // Efficient Instruction
        const efficientInstruction = `${instruction}\n\nIMPORTANT: Reply in Chinese. Be extremely concise, efficient, and direct. No fluff. Maximum 60 words.`;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: [ ...historyContext, { role: 'user', parts: [{ text: prompt }] } ],
            config: { systemInstruction: efficientInstruction }
        });

        const aiText = response.text || '...';
        const aiReply: Message = {
            id: Date.now().toString() + Math.random().toString(),
            senderName: senderName,
            senderAvatar: avatar,
            content: aiText,
            type: 'text',
            isMe: false,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, aiReply]);
      } catch (error) {
          console.error(`Error generating reply for ${senderName}:`, error);
      }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userText = inputValue;
    setInputValue('');
    setMentionSearch({ active: false, query: '' });

    const newMessage: Message = {
      id: Date.now().toString(),
      senderAvatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&h=200&fit=crop', 
      content: userText,
      type: 'text',
      isMe: true,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMessage]);
    setIsAiThinking(true);

    try {
      // 1. Detect Mentions
      const mentionRegex = /@(\w+)/g; // Matches @Steve, @everyone, etc.
      const mentions = [...userText.matchAll(mentionRegex)].map(match => match[1].toLowerCase());
      
      let responded = false;

      // 2. Handle @everyone or @all
      if (mentions.includes('everyone') || mentions.includes('all')) {
           // Trigger currently active AI members in group
           const activeBots = AI_TEAM_MEMBERS.filter(m => groupParticipants.has(m.id));
           // Fallback to top 3 if group is empty/defaults not set for demo
           const botsToReply = activeBots.length > 0 ? activeBots : AI_TEAM_MEMBERS.slice(0, 3);

           for (const bot of botsToReply) {
               await generateReply(userText, bot.instruction, bot.name, bot.avatar);
           }
           responded = true;
      } else {
          // 3. Handle Specific Mentions
          for (const mention of mentions) {
              const targetBot = AI_TEAM_MEMBERS.find(m => m.name.toLowerCase().includes(mention));
              if (targetBot) {
                  await generateReply(userText, targetBot.instruction, targetBot.name, targetBot.avatar);
                  responded = true;
              } else {
                  // Check if it's a contact (mock reply for now since contacts don't have instructions)
                  const targetContact = CONTACTS.find(c => c.name.toLowerCase().includes(mention));
                  if (targetContact) {
                       // Mock reply for contact
                       setTimeout(() => {
                           setMessages(prev => [...prev, {
                               id: Date.now().toString(),
                               senderName: targetContact.name,
                               senderAvatar: targetContact.avatar,
                               content: "收到，我等下看。",
                               type: 'text',
                               isMe: false,
                               time: 'Now'
                           }]);
                       }, 1000);
                       responded = true;
                  }
              }
          }
      }

      // 4. Default Reply (if no specific mention and this is a bot chat)
      // Only if NO mentions were processed, reply as the main bot of this chat.
      if (!responded) {
           // Check if current chat is a specific bot
           const currentBot = AI_TEAM_MEMBERS.find(m => chat.name.includes(m.name));
           
           if (currentBot) {
               await generateReply(userText, currentBot.instruction, currentBot.name, currentBot.avatar);
           } else {
              // Generic Chat Logic
              const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
              const history = messages.slice(-10).map(m => ({
                role: m.isMe ? 'user' : 'model',
                parts: [{ text: `${m.senderName ? m.senderName + ': ' : ''}${m.content}` }]
              }));
              
              const finalInstruction = systemInstruction || `
                你是一名顶尖的 AI 创业导师，目前在名为“${chat.name}”的群聊中。
                回复规则：1. 使用中文。2. 契合AI创业语境。3. 简短有力(50字内)。
              `;
              
              const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: [ ...history, { role: 'user', parts: [{ text: userText }] } ],
                config: { systemInstruction: finalInstruction }
              });
              const aiText = response.text || '...';
              const aiReply: Message = {
                id: (Date.now() + 1).toString(),
                senderName: chat.name === 'MyBot' ? chat.name : (chat.name.includes('(') ? chat.name.split(' ')[0] : chat.name),
                senderAvatar: chat.avatar,
                content: aiText,
                type: 'text',
                isMe: false,
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              };
              setMessages(prev => [...prev, aiReply]);
           }
      }

    } catch (error) { console.error("AI Error", error); } finally { setIsAiThinking(false); }
  };

  const handleReplyClick = async (msg: Message) => {
    setAiContext({ mode: 'loading', data: null });
    // Simulate AI for brevity in this snippet
    setTimeout(() => {
        setAiContext({ mode: 'reply', data: ["这个建议不错，值得一试。", "成本控制是关键，怎么落地？", "我们这周开个会讨论下？"] });
    }, 1000);
  };

  const handleCustomAiPrompt = async (msg: Message, promptText: string) => {
    setAiContext({ mode: 'custom', data: "AI 导师正在思考: " + promptText });
  };
  const handleSuggestionSelect = (text: string) => { setInputValue(text); setActiveMessageId(null); };

  const toggleMemberSelection = (id: string) => {
      const newSet = new Set(selectedMemberIds);
      if (newSet.has(id)) {
          newSet.delete(id);
      } else {
          newSet.add(id);
      }
      setSelectedMemberIds(newSet);
  };

  const handleConfirmAddMembers = () => {
      const allCandidates = [...AI_TEAM_MEMBERS, ...CONTACTS];
      const selected = allCandidates.filter(m => selectedMemberIds.has(m.id));
      
      if (selected.length === 0) return;

      const newMessages: Message[] = selected.map((member, index) => ({
          id: Date.now().toString() + index,
          senderAvatar: member.avatar,
          content: `${member.name} has joined the group.`,
          type: 'system',
          isMe: false,
          senderName: 'System',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }));

      // Update active participants
      const updatedParticipants = new Set(groupParticipants);
      selected.forEach(m => updatedParticipants.add(m.id));
      setGroupParticipants(updatedParticipants);

      setMessages(prev => [...prev, ...newMessages]);
      setShowAddMemberModal(false);
  };

  // Filter members for mention popup
  const filteredMentionMembers = mentionSearch.active 
    ? [...AI_TEAM_MEMBERS, ...CONTACTS].filter(m => 
        // Show if in group OR if query matches (allowing adding by mention behavior)
        // For strictly "in group" behavior: groupParticipants.has(m.id) && m.name...
        // But for better demo UX, let's show all matches but prioritize group members
        m.name.toLowerCase().includes(mentionSearch.query)
      ).sort((a, b) => {
          // Prioritize members already in group
          const aIn = groupParticipants.has(a.id) ? 1 : 0;
          const bIn = groupParticipants.has(b.id) ? 1 : 0;
          return bIn - aIn;
      })
    : [];

  return (
    <div className={`flex flex-col h-full font-sans relative z-50 animate-fade-in ${isEmbedded ? 'bg-transparent' : 'bg-black/90'}`}>
      
      {/* Glass Header */}
      <div className="absolute top-0 left-0 right-0 z-[60] bg-[#1c1c1e]/70 backdrop-blur-xl border-b border-white/10 flex items-center justify-between px-4 py-3 pb-4 rounded-t-[32px]">
          <div className="flex items-center gap-3">
             <button onClick={onBack} className="flex items-center text-blue-500 hover:text-blue-400 active:opacity-60 transition-colors">
                <ChevronLeft size={26} strokeWidth={2} />
             </button>
             {isEmbedded && (
                 <div className="w-8 h-8 rounded-full overflow-hidden border border-white/20">
                    <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover"/>
                 </div>
             )}
             <div className="flex flex-col">
                <h1 className={`${headerTitleClass} font-semibold text-white`}>
                    {chat.name}
                </h1>
                {!isEmbedded && <span className="text-[10px] text-gray-400">{groupParticipants.size} people active</span>}
             </div>
          </div>
          <div className="flex items-center gap-2">
            {onMinimize && (
                <button 
                    onClick={onMinimize}
                    className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-colors"
                >
                    <Minus size={16} />
                </button>
            )}
            <button 
                onClick={() => setShowAddMemberModal(true)}
                className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-colors"
            >
                <UserPlus size={16} />
            </button>
            <button className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-colors">
                <MoreHorizontal size={18} />
            </button>
          </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar relative z-10 pt-20 pb-24">
        {messages.map((msg, index) => {
          const showTime = msg.time && (index === 0 || messages[index - 1].time !== msg.time);
          const isSystem = msg.type === 'system';
          
          if (isSystem) {
              return (
                  <div key={msg.id} className="flex flex-col items-center justify-center my-4 space-y-1 animate-fade-in">
                      {showTime && <span className={`${timeClass} text-white/40 font-medium`}>{msg.time}</span>}
                      <div className="bg-white/10 px-3 py-1 rounded-full text-[10px] text-gray-300 flex items-center gap-2 border border-white/5">
                          <img src={msg.senderAvatar} className="w-4 h-4 rounded-full" alt="avatar"/>
                          <span>{msg.content}</span>
                      </div>
                  </div>
              )
          }

          return (
            <React.Fragment key={msg.id}>
              {showTime && (
                <div className="flex justify-center my-4">
                  <span className={`${timeClass} text-white/40 font-medium`}>{msg.time}</span>
                </div>
              )}
              
              <div className={`flex flex-col gap-1 ${msg.isMe ? 'items-end' : 'items-start'}`}>
                <div className={`flex gap-3 ${msg.isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                  {!msg.isMe && <img src={msg.senderAvatar} alt={msg.senderName} className={`${avatarClass} object-cover bg-gray-800 shadow-sm`} />}
                  <div className={`flex flex-col max-w-[80%] ${msg.isMe ? 'items-end' : 'items-start'}`}>
                    {!msg.isMe && msg.senderName && (
                      <span className={`${senderNameClass} text-gray-500 mb-1 ml-1`}>{msg.senderName}</span>
                    )}
                    <div className="relative group transition-all duration-300">
                      <div 
                        onClick={(e) => { e.stopPropagation(); setActiveMessageId(activeMessageId === msg.id ? null : msg.id); }}
                        className={`
                          cursor-pointer relative ${bubblePaddingClass} shadow-sm break-words ${bubbleTextClass}
                          ${msg.isMe 
                            ? 'bg-blue-600 text-white rounded-[20px] rounded-br-[4px]' 
                            : 'bg-[#2c2c2e] text-gray-100 rounded-[20px] rounded-bl-[4px] border border-white/5'}
                          ${msg.type === 'voice' ? 'min-w-[80px] flex items-center' : ''}
                          ${activeMessageId === msg.id ? 'ring-2 ring-blue-500/50 scale-[1.02]' : ''}
                        `}
                      >
                        {msg.type === 'text' && <span>{msg.content}</span>}
                        {msg.type === 'reply' && (
                          <div className="flex flex-col">
                            <span>{msg.content}</span>
                            <div className="mt-1.5 pt-1.5 border-t border-white/10 relative opacity-70">
                              <div className={`${timeClass} text-white/80 italic`}>{msg.replyContext}</div>
                            </div>
                          </div>
                        )}
                        {msg.type === 'voice' && (
                          <div className="flex items-center gap-2">
                            <Wifi className="transform rotate-90 text-white/80" size={14 * iconScale} />
                            <span className="font-medium">{msg.voiceDuration}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Context Menu - Glass Style */}
                {activeMessageId === msg.id && (
                    <div className={`w-full max-w-[280px] ${msg.isMe ? 'mr-12' : 'ml-12'} animate-fade-in-up origin-top z-10 mt-2`}>
                        <div className="bg-[#1c1c1e]/90 backdrop-blur-xl rounded-[20px] p-3 flex flex-col gap-3 border border-white/20 shadow-2xl">
                            <div className="flex items-center gap-2 px-3 py-2 bg-black/40 rounded-xl border border-white/10 focus-within:ring-1 focus-within:ring-blue-500 transition-all">
                                <Sparkles size={14} className="text-blue-400 shrink-0" />
                                <input 
                                    className="flex-1 bg-transparent text-[12px] outline-none text-white placeholder-gray-500 min-w-0"
                                    placeholder="Ask AI..."
                                    value={customPrompt}
                                    onChange={(e) => setCustomPrompt(e.target.value)}
                                />
                                <button className={`p-1 rounded-full ${customPrompt.trim() ? 'bg-blue-500 text-white' : 'bg-white/10 text-gray-500'}`}>
                                    <ArrowUp size={12} />
                                </button>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={() => handleReplyClick(msg)} className="flex-1 text-[11px] font-bold text-white bg-white/10 hover:bg-white/20 py-2 rounded-lg transition-colors">Reply</button>
                                <button className="flex-1 text-[11px] font-bold text-white bg-white/10 hover:bg-white/20 py-2 rounded-lg transition-colors">Task</button>
                            </div>
                             {aiContext.mode === 'reply' && aiContext.data && (
                                <div className="space-y-1">
                                    {(aiContext.data as string[]).map((suggestion, idx) => (
                                        <button key={idx} onClick={() => handleSuggestionSelect(suggestion)} className="w-full text-left text-[11px] text-gray-300 bg-white/5 hover:bg-white/10 p-2 rounded-lg border border-white/5 transition-colors">{suggestion}</button>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                )}
              </div>
            </React.Fragment>
          );
        })}
      </div>

      {/* Mention Popup */}
      {mentionSearch.active && filteredMentionMembers.length > 0 && (
          <div className="absolute bottom-20 left-4 right-4 z-[70] animate-fade-in-up">
              <div className="bg-[#1c1c1e]/95 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden max-h-[240px] flex flex-col">
                  <div className="px-3 py-2 border-b border-white/5 text-[10px] font-bold text-white/50 bg-white/5 uppercase tracking-wider">
                      Mention Member
                  </div>
                  <div className="overflow-y-auto no-scrollbar">
                      {filteredMentionMembers.map(member => (
                          <button
                              key={member.id}
                              onClick={() => handleSelectMention(member.name.split(' ')[0])} // Use first name for cleaner mention
                              className="w-full px-3 py-2.5 flex items-center gap-3 hover:bg-blue-500/20 hover:text-white transition-colors group"
                          >
                              <div className="relative">
                                <img src={member.avatar} className="w-8 h-8 rounded-lg object-cover bg-gray-800" alt={member.name}/>
                                {groupParticipants.has(member.id) && (
                                    <div className="absolute -bottom-1 -right-1 bg-green-500 w-2.5 h-2.5 rounded-full border border-[#1c1c1e]"></div>
                                )}
                              </div>
                              <div className="flex flex-col items-start">
                                  <span className="text-sm font-bold text-gray-200 group-hover:text-white">{member.name}</span>
                                  <span className="text-[10px] text-gray-500 group-hover:text-blue-200">{member.role}</span>
                              </div>
                          </button>
                      ))}
                  </div>
              </div>
          </div>
      )}

      {/* Input Area - Floating Capsule */}
      <div className={`absolute bottom-0 left-0 right-0 bg-[#1c1c1e]/80 backdrop-blur-xl border-t border-white/10 p-2 flex items-end gap-2 z-[60] rounded-b-[32px] ${isEmbedded ? 'pb-3' : 'pb-6'}`}>
        <button className="p-2.5 rounded-full bg-gray-800 text-gray-400 hover:text-white transition-colors">
            <Plus size={20} />
        </button>
        <div className="flex-1 bg-[#2c2c2e] rounded-[24px] min-h-[44px] px-4 py-2.5 flex items-center border border-white/10 focus-within:border-white/30 transition-colors relative">
           <input 
            ref={inputRef}
            type="text" 
            className={`w-full bg-transparent outline-none ${inputClass} text-white placeholder-gray-500`} 
            placeholder="Message (@Steve, @everyone)"
            value={inputValue} 
            onChange={handleInputChange} 
            onKeyDown={(e) => {
                if (e.key === 'Enter') {
                    if (mentionSearch.active && filteredMentionMembers.length > 0) {
                        e.preventDefault();
                        handleSelectMention(filteredMentionMembers[0].name.split(' ')[0]);
                    } else {
                        handleSendMessage();
                    }
                }
            }} 
           />
           <button className="text-gray-400 hover:text-white ml-2">
               <Smile size={20} />
           </button>
        </div>
        {inputValue.trim() ? (
             <button onClick={handleSendMessage} className="p-2.5 bg-blue-500 text-white rounded-full shadow-lg shadow-blue-500/30 animate-scale-in">
                <ArrowUp size={20} strokeWidth={3} />
             </button>
        ) : (
            <button className="p-2.5 rounded-full bg-gray-800 text-gray-400">
                <Wifi className="transform rotate-90" size={20} />
            </button>
        )}
      </div>

      {/* Add Member Modal */}
      {showAddMemberModal && (
        <div className="absolute inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center animate-fade-in">
            <div className="bg-[#1c1c1e] w-full sm:w-[360px] sm:rounded-[24px] rounded-t-[24px] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[85%] animate-slide-in-up">
                <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
                    <span className="text-sm font-bold text-white">Add Members</span>
                    <button onClick={() => setShowAddMemberModal(false)} className="p-1 bg-white/10 rounded-full text-gray-400 hover:text-white">
                        <X size={16} />
                    </button>
                </div>
                <div className="p-3">
                    <div className="bg-black/40 rounded-xl flex items-center px-3 py-2 border border-white/10 focus-within:border-blue-500/50 transition-colors">
                        <Search size={14} className="text-gray-500 mr-2" />
                        <input placeholder="Search bots or people..." className="bg-transparent text-xs text-white outline-none w-full placeholder-gray-600" />
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-4 custom-scrollbar">
                    
                    {/* Bot Section */}
                    <div className="px-2">
                        <div className="text-[10px] font-bold text-gray-500 uppercase mb-2 flex items-center gap-1.5">
                            <Sparkles size={10} className="text-blue-500" />
                            AI Team Members
                        </div>
                        <div className="space-y-1">
                            {AI_TEAM_MEMBERS.filter(m => m.name !== chat.name).map(member => {
                                const isSelected = selectedMemberIds.has(member.id);
                                return (
                                <button 
                                    key={member.id}
                                    onClick={() => toggleMemberSelection(member.id)}
                                    className={`w-full flex items-center gap-3 p-2 rounded-xl transition-colors group ${isSelected ? 'bg-white/10' : 'hover:bg-white/5'}`}
                                >
                                    <div className="relative">
                                        <img src={member.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" alt={member.name} />
                                        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-blue-500 rounded-full border-2 border-[#1c1c1e]"></div>
                                    </div>
                                    <div className="flex-1 text-left">
                                        <div className="text-sm font-bold text-white">{member.name}</div>
                                        <div className="text-[10px] text-gray-400">{member.role}</div>
                                    </div>
                                    <div className={`w-6 h-6 rounded-full border flex items-center justify-center transition-all ${
                                        isSelected 
                                        ? 'bg-blue-500 border-blue-500 text-white' 
                                        : 'border-white/20 group-hover:border-white/40 text-white/50'
                                    }`}>
                                        {isSelected ? <Check size={14} /> : <Plus size={14} />}
                                    </div>
                                </button>
                            )})}
                        </div>
                    </div>

                    {/* Contacts Section */}
                    <div className="px-2">
                         <div className="text-[10px] font-bold text-gray-500 uppercase mb-2 flex items-center gap-1.5">
                            <Users size={10} className="text-green-500" />
                            Contacts & Colleagues
                        </div>
                        <div className="space-y-1">
                            {CONTACTS.filter(m => m.name !== chat.name).map(contact => {
                                const isSelected = selectedMemberIds.has(contact.id);
                                return (
                                <button 
                                    key={contact.id}
                                    onClick={() => toggleMemberSelection(contact.id)}
                                    className={`w-full flex items-center gap-3 p-2 rounded-xl transition-colors group ${isSelected ? 'bg-white/10' : 'hover:bg-white/5'}`}
                                >
                                    <div className="relative">
                                        <img src={contact.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" alt={contact.name} />
                                    </div>
                                    <div className="flex-1 text-left">
                                        <div className="text-sm font-bold text-white">{contact.name}</div>
                                        <div className="text-[10px] text-gray-400">{contact.role}</div>
                                    </div>
                                    <div className={`w-6 h-6 rounded-full border flex items-center justify-center transition-all ${
                                        isSelected 
                                        ? 'bg-green-500 border-green-500 text-white' 
                                        : 'border-white/20 group-hover:border-white/40 text-white/50'
                                    }`}>
                                        {isSelected ? <Check size={14} /> : <Plus size={14} />}
                                    </div>
                                </button>
                            )})}
                        </div>
                    </div>
                </div>

                {/* Footer Action */}
                <div className="p-4 border-t border-white/10 bg-white/5">
                    <button 
                        onClick={handleConfirmAddMembers}
                        disabled={selectedMemberIds.size === 0}
                        className={`w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
                            selectedMemberIds.size > 0 
                            ? 'bg-blue-600 text-white shadow-lg hover:bg-blue-500 active:scale-95' 
                            : 'bg-white/10 text-white/30 cursor-not-allowed'
                        }`}
                    >
                        {selectedMemberIds.size > 0 ? (
                            <>
                                <UserPlus size={18} />
                                <span>Add {selectedMemberIds.size} Member{selectedMemberIds.size > 1 ? 's' : ''}</span>
                            </>
                        ) : (
                            <span>Select members to add</span>
                        )}
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default ChatDetailScreen;
