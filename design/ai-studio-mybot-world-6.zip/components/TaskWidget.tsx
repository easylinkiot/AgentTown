
import React, { useState } from 'react';
import { ChevronUp, ChevronDown, CheckSquare, Clock } from 'lucide-react';
import { TaskItem } from '../types';

interface TaskWidgetProps {
  tasks: TaskItem[];
  onMinimize?: () => void;
}

const TaskWidget: React.FC<TaskWidgetProps> = ({ tasks, onMinimize }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="w-full animate-fade-in-up">
      <div 
        className={`
          bg-white/10 backdrop-blur-2xl rounded-[26px] shadow-2xl border border-white/20 overflow-hidden transition-all duration-300
          ${isExpanded ? 'h-auto' : 'h-[50px]'}
        `}
      >
        {/* Header */}
        <div 
          className="w-full flex items-center justify-between p-3.5 bg-transparent transition-colors cursor-pointer"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <div className="flex items-center gap-2.5">
            <div className="bg-green-500 rounded-full p-1.5 shadow-lg shadow-green-500/30">
                <CheckSquare size={14} className="text-white" strokeWidth={3} />
            </div>
            <span className="font-semibold text-[13px] text-white tracking-wide">Tasks</span>
          </div>
          
          <div className="flex items-center gap-2 pr-1">
              {isExpanded ? <ChevronDown size={18} className="text-white/50" /> : <ChevronUp size={18} className="text-white/50" />}
          </div>
        </div>

        {/* Task List */}
        <div 
          className={`
            transition-all duration-300 ease-in-out px-3.5 pb-3.5 space-y-2
            ${isExpanded ? 'opacity-100 max-h-[300px] overflow-y-auto no-scrollbar' : 'opacity-0 max-h-0'}
          `}
        >
          {tasks.length === 0 ? (
            <div className="p-4 flex flex-col items-center justify-center text-white/40 gap-2 border border-dashed border-white/10 rounded-2xl">
               <CheckSquare size={16} className="opacity-50" />
               <span className="text-[10px]">No active tasks</span>
            </div>
          ) : (
             tasks.slice(0, 3).map((task, idx) => (
                <div key={idx} className="bg-black/20 border border-white/5 p-3 rounded-[18px] hover:bg-white/10 transition-colors group flex items-center gap-3">
                   <div className="w-4 h-4 rounded-full border-2 border-white/30 group-hover:border-green-400 transition-colors"></div>
                   <div className="flex-1 min-w-0">
                      <h4 className="text-[12px] font-medium text-white leading-tight truncate">{task.title}</h4>
                      <div className="flex items-center gap-2 text-[10px] text-white/50 mt-0.5">
                          <span className="flex items-center gap-1"><Clock size={10}/> Today</span>
                      </div>
                   </div>
                   <span className={`
                        text-[9px] w-2 h-2 rounded-full
                        ${task.priority === 'High' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]' : 
                          task.priority === 'Medium' ? 'bg-orange-500' : 
                          'bg-blue-500'}
                      `}>
                   </span>
                </div>
             ))
          )}
        </div>
      </div>
    </div>
  );
};

export default TaskWidget;
