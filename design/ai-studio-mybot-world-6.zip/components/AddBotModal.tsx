
import React, { useState } from 'react';
import { X, Upload, User, Briefcase, Sparkles, Check } from 'lucide-react';
import { TeamMember } from '../types';

interface AddBotModalProps {
  onClose: () => void;
  onAdd: (member: TeamMember) => void;
}

const AddBotModal: React.FC<AddBotModalProps> = ({ onClose, onAdd }) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [instructions, setInstructions] = useState('');
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  const handleCreate = () => {
    const newMember: TeamMember = {
        id: `custom_${Date.now()}`,
        name,
        role,
        avatar: avatarPreview || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&h=200&fit=crop',
        instruction: instructions
    };
    onAdd(newMember);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#1c1c1e]/90 backdrop-blur-2xl w-full max-w-sm rounded-[32px] shadow-2xl overflow-hidden animate-scale-in flex flex-col border border-white/10 ring-1 ring-white/5">
        
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex justify-between items-center bg-white/5">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles size={20} className="text-blue-400" />
            Create a Bot Member
          </h2>
          <button 
            onClick={onClose}
            className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white/70 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          
          {/* Avatar Upload */}
          <div className="flex flex-col items-center gap-3">
             <div className="relative group cursor-pointer">
                 <div className="w-24 h-24 rounded-full bg-white/5 border-2 border-dashed border-white/20 flex items-center justify-center overflow-hidden hover:border-blue-500/50 transition-colors">
                    {avatarPreview ? (
                        <img src={avatarPreview} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                        <User size={32} className="text-white/20 group-hover:text-white/40" />
                    )}
                 </div>
                 <div className="absolute bottom-0 right-0 p-2 bg-blue-500 rounded-full shadow-lg border border-[#1c1c1e]">
                    <Upload size={14} className="text-white" />
                 </div>
                 <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleImageUpload} accept="image/*" />
             </div>
             <span className="text-[10px] text-gray-500 font-medium">Upload Avatar</span>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">Name</label>
                <div className="bg-black/40 rounded-xl border border-white/10 flex items-center px-3 focus-within:border-blue-500/50 transition-colors">
                    <input 
                        type="text" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Architect Bot"
                        className="w-full bg-transparent h-10 text-sm text-white placeholder-gray-600 outline-none font-medium"
                    />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">Role / Expertise</label>
                <div className="bg-black/40 rounded-xl border border-white/10 flex items-center px-3 focus-within:border-blue-500/50 transition-colors">
                    <Briefcase size={16} className="text-gray-500 mr-2" />
                    <input 
                        type="text" 
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                        placeholder="e.g. Python Backend Developer"
                        className="w-full bg-transparent h-10 text-sm text-white placeholder-gray-600 outline-none font-medium"
                    />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">System Instructions</label>
                <textarea 
                    value={instructions}
                    onChange={(e) => setInstructions(e.target.value)}
                    placeholder="Describe how this bot should behave, its tone, and specific knowledge..."
                    className="w-full bg-black/40 rounded-xl border border-white/10 p-3 text-sm text-white placeholder-gray-600 outline-none min-h-[80px] resize-none focus:border-blue-500/50 transition-colors"
                />
              </div>
          </div>

          {/* Create Button */}
          <button 
             className={`w-full font-bold py-3.5 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 mt-2 ${!name ? 'bg-white/10 text-gray-500 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-500/20 active:scale-95'}`}
             onClick={handleCreate}
             disabled={!name}
          >
             <Check size={18} />
             Create Member
          </button>

        </div>
      </div>
    </div>
  );
};

export default AddBotModal;
