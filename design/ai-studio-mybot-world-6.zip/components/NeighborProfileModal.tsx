
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { X, Briefcase, BarChart3, Share2, Terminal, Cpu, Zap, Lock, Activity, RefreshCw, Settings, Save, Upload, User, Database, Layers, Brain, Box, Rocket, Minimize2 } from 'lucide-react';
import { LotData } from '../types';

interface NeighborProfileModalProps {
  lot: LotData;
  onClose: () => void;
}

// Helper to deterministically pick from array based on string hash
const getHash = (str: string) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash);
  return Math.abs(hash);
};

const pick = (arr: any[], seed: number) => arr[seed % arr.length];

const generateMyBotProfile = (lot: LotData) => {
    const { role, name, company } = lot.npc;
    const seed = getHash(lot.id + name);
    
    // CUSTOM PROFILE FOR ELON BOT
    if (name.includes("Elon")) {
        return {
            hardware: "Dojo ExaPOD (Custom Silicon)",
            model: "Grok-3-Ultra-Context",
            tagline: "Making consciousness multi-planetary.",
            logs: [
                { title: "Starship Static Fire", desc: "Booster 12 static fire complete. 33 raptors nominal. Launch window: T-minus 4 hours.", icon: Rocket, color: "text-orange-600" },
                { title: "Algorithm Update", desc: "Refactored feed ranking. Boosted visibility for 'Doge' and 'Mars' topics by 420%.", icon: Terminal, color: "text-black" },
                { title: "FSD Training", desc: "Ingested 10 million miles of driving data. Edge case resolution improved by 15%.", icon: Cpu, color: "text-red-500" }
            ],
            sysLog: "> CONNECTING TO STARLINK SAT_42...\n> UPLOADING MEME_DB_V69.JSON... DONE.\n> TARGET: MARS COLONY 1\n> STATUS: OCCUPYING"
        };
    }

    // 1. Hardware & Infrastructure
    const HARDWARE_OPTS = [
        "NVIDIA H100 Cluster (64x)", "Apple M3 Ultra (192GB Unified)", "8x RTX 4090 Liquid Cooled", 
        "Google TPU v5p Pod", "Cerebras CS-3 Wafer Scale", "Local 4x A6000 Ada", 
        "H200 NVL Server", "Custom ASIC Inference Rack"
    ];

    // 2. Model Architecture
    const MODEL_OPTS = [
        "Llama-4-405B-Quant (4-bit)", "Mistral-Large-Instruct-v2", "Grok-2-128k (Fine-tuned)", 
        "Claude-3.5-Opus-Local", "GPT-5-Preview-Distilled", "Custom MoE 8x22B",
        "Falcon-180B-Chat", "Qwen-110B-Tuned"
    ];
    
    // 3. System Tagline
    let tagline = "Optimizing for maximum entropy.";
    if (role.toLowerCase().includes("engineer")) tagline = "Code is law. Latency is the enemy.";
    else if (role.toLowerCase().includes("design")) tagline = "Dreaming in latent space. Rendering reality.";
    else if (role.toLowerCase().includes("manager") || role.toLowerCase().includes("product")) tagline = "Data-driven decisions. Zero hallucination.";
    else if (role.toLowerCase().includes("ethicist") || role.toLowerCase().includes("safety")) tagline = "Guardrails active. Alignment locked.";
    else if (role.toLowerCase().includes("gpu")) tagline = "The more you buy, the more you save.";
    else tagline = "Processing the future, one token at a time.";

    // 4. Generate unique logs based on role
    const logs = [];
    
    // Log 1: Morning Routine / Analysis
    if (role.toLowerCase().includes("market") || role.toLowerCase().includes("strategist")) {
        logs.push({
            title: "Market Scan",
            desc: `Analyzed 450k tweets and 200 news articles about ${company} competitors. Sentiment: Neutral-Positive.`,
            icon: BarChart3,
            color: "text-blue-500"
        });
    } else if (role.toLowerCase().includes("design") || role.toLowerCase().includes("artist")) {
         logs.push({
            title: "Asset Generation",
            desc: "Generated 50 variations of 'Cyberpunk City' concept art. Top 3 selected for review.",
            icon: Layers,
            color: "text-pink-500"
        });
    } else if (role.toLowerCase().includes("dev") || role.toLowerCase().includes("architect") || role.toLowerCase().includes("engineer")) {
         logs.push({
            title: "Code Audit",
            desc: `Scanned ${company} repo. Refactored 12 legacy modules. Unit test coverage: 98%.`,
            icon: Terminal,
            color: "text-green-500"
        });
    } else {
        logs.push({
            title: "Knowledge Synthesis",
            desc: `Digested 150 new Arxiv papers on ${role}. Updated internal vector database.`,
            icon: Brain,
            color: "text-purple-500"
        });
    }

    // Log 2: Current Activity
    const activitySeed = seed + 1;
    const ACTIVITIES = [
        "Optimizing context window retention.",
        "Cooling system at 80% capacity. Throttling non-critical tasks.",
        "Rebalancing sharded weights across nodes.",
        "Detected anomaly in data stream. Investigating.",
        "Training LoRA adapter for specific task.",
        "Running Monte Carlo simulations on project outcomes."
    ];
    logs.push({
        title: "System Status",
        desc: pick(ACTIVITIES, activitySeed),
        icon: Activity,
        color: "text-orange-500"
    });

    // Random System Log (Glitchy text)
    const sysLog = `[KERNEL] Allocating ${(seed % 64) + 8}GB VRAM... Done.\n> Loading weights from /mnt/data/${role.split(' ')[0].toLowerCase()}_v${seed%10}.pt`;

    return {
        hardware: pick(HARDWARE_OPTS, seed),
        model: pick(MODEL_OPTS, seed + 2),
        tagline,
        logs,
        sysLog
    };
};

const NeighborProfileModal: React.FC<NeighborProfileModalProps> = ({ lot, onClose }) => {
  const [activeTab, setActiveTab] = useState<'creator' | 'mybot' | 'interactions'>('creator');
  const [isConfiguring, setIsConfiguring] = useState(false);

  // Local state for configuration form
  const [configName, setConfigName] = useState(lot.npc.name);
  const [configRole, setConfigRole] = useState(lot.npc.role);
  const [configPrompt, setConfigPrompt] = useState(`You are ${lot.npc.name}, a ${lot.npc.role} at @${lot.npc.company}.`);

  // View State (Maximized vs Minimized)
  const [viewMode, setViewMode] = useState<'maximized' | 'minimized'>('maximized');
  const [position, setPosition] = useState({ x: 20, y: 120 }); // Default minimized position
  const [isDragging, setIsDragging] = useState(false);
  
  // Refs for drag calculation
  const dragOffset = useRef({ x: 0, y: 0 });
  const dragStartTime = useRef<number>(0);

  // Memoize the bot profile so it doesn't change on re-renders
  const botProfile = useMemo(() => generateMyBotProfile(lot), [lot]);

  // --- Dragging Logic ---
  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    dragStartTime.current = Date.now();
    
    // Calculate offset relative to the element
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    dragOffset.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
    };
  };

  useEffect(() => {
      const handlePointerMove = (e: PointerEvent) => {
          if (!isDragging) return;
          e.preventDefault();
          
          let newX = e.clientX - dragOffset.current.x;
          let newY = e.clientY - dragOffset.current.y;

          // Simple boundary constraints (keep within screen mostly)
          const maxX = window.innerWidth - 80; 
          const maxY = window.innerHeight - 80;
          
          newX = Math.max(0, Math.min(newX, maxX));
          newY = Math.max(0, Math.min(newY, maxY));

          setPosition({ x: newX, y: newY });
      };

      const handlePointerUp = () => {
          setIsDragging(false);
      };

      if (isDragging) {
          window.addEventListener('pointermove', handlePointerMove);
          window.addEventListener('pointerup', handlePointerUp);
      }
      return () => {
          window.removeEventListener('pointermove', handlePointerMove);
          window.removeEventListener('pointerup', handlePointerUp);
      }
  }, [isDragging]);

  const handleMinimizedTap = () => {
      // If tap was short (not a drag), restore view
      if (Date.now() - dragStartTime.current < 200) {
          setViewMode('maximized');
      }
  };

  // --- Render Minimized View ---
  if (viewMode === 'minimized') {
      return (
        <div 
            className="fixed z-[9999] cursor-move touch-none"
            style={{ left: position.x, top: position.y }}
            onPointerDown={handlePointerDown}
            onClick={handleMinimizedTap}
        >
            <div className="bg-white/90 backdrop-blur-xl p-2 rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.2)] border border-white/60 flex flex-col items-center gap-1 w-20 animate-scale-in transition-transform active:scale-95 group hover:bg-white">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-white shadow-sm relative ring-2 ring-gray-100 group-hover:ring-blue-300 transition-all">
                    <img src={lot.npc.avatar} className="w-full h-full object-cover" alt="minimized-avatar" />
                    {/* Online Dot */}
                    <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                </div>
                <span className="text-[9px] font-bold text-gray-800 truncate w-full text-center px-1">
                    {lot.npc.name.split(' ')[0]}
                </span>
                <div className="flex items-center gap-1 bg-gray-100 px-1.5 py-0.5 rounded-full mt-0.5">
                    <Activity size={8} className="text-green-600" />
                    <span className="text-[8px] font-bold text-gray-500">Live</span>
                </div>
            </div>
        </div>
      );
  }

  // --- Render Maximized View (Default) ---
  return (
    <div className="fixed inset-0 z-[9999] bg-black/40 backdrop-blur-md flex items-center justify-center p-0 sm:p-4 animate-fade-in">
        <div className="bg-white w-[80%] sm:max-w-sm h-[80vh] sm:h-[700px] rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-slide-in-up transition-all duration-300 relative">
            
            {/* Header */}
            <div className="p-5 border-b border-gray-100 bg-white relative shrink-0">
                 {/* Right Controls: Minimize & Close */}
                 <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
                    <button 
                        onClick={() => setViewMode('minimized')}
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500 hover:text-gray-800"
                        title="Minimize"
                    >
                        <Minimize2 size={20} />
                    </button>
                    <button 
                        onClick={onClose} 
                        className="p-2 hover:bg-red-50 rounded-full transition-colors text-gray-500 hover:text-red-500"
                        title="Close"
                    >
                        <X size={20} />
                    </button>
                 </div>

                 {/* Left Controls: Config */}
                 <button 
                    onClick={() => setIsConfiguring(!isConfiguring)} 
                    className={`absolute top-4 left-4 p-2 rounded-full transition-colors z-10 ${isConfiguring ? 'bg-black text-white' : 'hover:bg-gray-100 text-gray-500'}`}
                    title="配置邻居"
                 >
                    <Settings size={20} />
                 </button>
                 
                 <div className="flex flex-col items-center pt-2">
                     <div className="w-20 h-20 rounded-full border-4 border-white shadow-lg overflow-hidden mb-3 relative group cursor-pointer">
                         <img src={lot.npc.avatar} className="w-full h-full object-cover bg-gray-200" alt={lot.npc.name} />
                         {isConfiguring && (
                             <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                 <Upload size={20} className="text-white" />
                             </div>
                         )}
                     </div>
                     <h2 className="text-xl font-bold text-gray-900">{isConfiguring ? '配置邻居' : lot.npc.name}</h2>
                     {!isConfiguring && (
                         <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full mt-1">
                            {lot.npc.role} @ {lot.npc.company}
                         </span>
                     )}
                 </div>
            </div>

            {/* Content Area */}
            {isConfiguring ? (
                /* Configuration Form */
                <div className="flex-1 overflow-y-auto bg-gray-50 p-6 space-y-5 animate-fade-in">
                    
                    <div className="space-y-1">
                        <label className="text-xs font-bold text-gray-500 uppercase ml-1">显示名称</label>
                        <div className="bg-white p-3 rounded-xl border border-gray-200 shadow-sm flex items-center gap-2">
                            <User size={16} className="text-gray-400" />
                            <input 
                                type="text" 
                                value={configName}
                                onChange={(e) => setConfigName(e.target.value)}
                                className="flex-1 bg-transparent text-sm font-bold text-gray-800 outline-none"
                            />
                        </div>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-bold text-gray-500 uppercase ml-1">角色设定 (Role)</label>
                        <div className="bg-white p-3 rounded-xl border border-gray-200 shadow-sm flex items-center gap-2">
                            <Briefcase size={16} className="text-gray-400" />
                            <input 
                                type="text" 
                                value={configRole}
                                onChange={(e) => setConfigRole(e.target.value)}
                                className="flex-1 bg-transparent text-sm font-bold text-gray-800 outline-none"
                            />
                        </div>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-bold text-gray-500 uppercase ml-1">Bot System Instruction</label>
                        <div className="bg-white p-3 rounded-xl border border-gray-200 shadow-sm">
                            <textarea 
                                value={configPrompt}
                                onChange={(e) => setConfigPrompt(e.target.value)}
                                className="w-full h-32 bg-transparent text-xs text-gray-700 outline-none resize-none leading-relaxed"
                                placeholder="输入该邻居 Bot 的系统提示词..."
                            />
                        </div>
                        <p className="text-[10px] text-gray-400 ml-1">定义该邻居在聊天时的性格、知识库和行为准则。</p>
                    </div>

                    <div className="pt-4">
                        <button 
                            onClick={() => setIsConfiguring(false)}
                            className="w-full bg-black text-white font-bold py-3 rounded-xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-transform"
                        >
                            <Save size={18} />
                            <span>保存配置</span>
                        </button>
                    </div>

                </div>
            ) : (
                /* View Mode */
                <>
                    {/* Tabs */}
                    <div className="flex items-center justify-around border-b border-gray-100 bg-gray-50/50 shrink-0">
                        {['creator', 'mybot', 'interactions'].map((tab) => (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab as any)}
                                className={`flex-1 py-3 text-sm font-bold relative transition-colors ${activeTab === tab ? 'text-gray-900' : 'text-gray-400 hover:text-gray-600'}`}
                            >
                                {tab === 'creator' && 'Creator 主页'}
                                {tab === 'mybot' && 'MyBot 主页'}
                                {tab === 'interactions' && '公开互动'}
                                {activeTab === tab && (
                                    <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-8 h-0.5 bg-black rounded-full"></div>
                                )}
                            </button>
                        ))}
                    </div>

                    {/* Tab Content */}
                    <div className="flex-1 overflow-y-auto bg-gray-50 p-4">
                        
                        {/* 1. Creator Tab */}
                        {activeTab === 'creator' && (
                            <div className="space-y-4 animate-fade-in">
                                {/* Bio Card */}
                                <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                                    <h3 className="text-xs font-bold text-gray-400 uppercase mb-2">Bio / 简介</h3>
                                    <div className="flex items-start gap-3">
                                        <Briefcase size={18} className="text-gray-800 mt-0.5" />
                                        <p className="text-sm text-gray-800 leading-relaxed">
                                            {lot.npc.bio}
                                        </p>
                                    </div>
                                </div>

                                {/* Recent Activity */}
                                <h3 className="text-sm font-bold text-gray-900 ml-1">近期活动</h3>
                                
                                {/* Activity 1: Data Analysis */}
                                <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                                    <div className="flex items-center gap-2 mb-3">
                                        <div className="bg-purple-100 p-1.5 rounded-lg text-purple-600">
                                            <BarChart3 size={16} />
                                        </div>
                                        <span className="text-xs font-bold text-gray-700">Work Status</span>
                                        <span className="text-[10px] text-gray-400 ml-auto">Just now</span>
                                    </div>
                                    <p className="text-xs text-gray-600 mb-3 leading-relaxed">
                                        Bot just processed 3GB of logs from the {lot.npc.company} main cluster. Optimization suggestions pending.
                                    </p>
                                    {/* Blurred Chart Placeholder */}
                                    <div className="w-full h-24 bg-gray-100 rounded-lg overflow-hidden relative">
                                        <div className="absolute inset-0 flex items-end justify-around px-4 pb-2 opacity-30 blur-sm">
                                            <div className="w-4 h-12 bg-purple-500 rounded-t"></div>
                                            <div className="w-4 h-8 bg-blue-500 rounded-t"></div>
                                            <div className="w-4 h-16 bg-green-500 rounded-t"></div>
                                            <div className="w-4 h-10 bg-orange-500 rounded-t"></div>
                                            <div className="w-4 h-14 bg-red-500 rounded-t"></div>
                                        </div>
                                        <div className="absolute inset-0 flex items-center justify-center">
                                            <span className="bg-black/50 text-white text-[10px] px-2 py-1 rounded backdrop-blur-md">Sensitive Data hidden</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* 2. MyBot Tab */}
                        {activeTab === 'mybot' && (
                            <div className="space-y-4 animate-fade-in">
                                {/* Hero Specs */}
                                <div className="bg-gray-900 text-white p-5 rounded-3xl relative overflow-hidden shadow-lg border border-gray-800">
                                    {/* Abstract background blobs */}
                                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 rounded-full blur-3xl -mr-10 -mt-10"></div>
                                    <div className="absolute bottom-0 left-0 w-24 h-24 bg-purple-500/20 rounded-full blur-3xl -ml-5 -mb-5"></div>
                                    
                                    <h3 className="text-lg font-bold mb-1 flex items-center gap-2 relative z-10">
                                        <Terminal size={18} className="text-green-400"/> MyBot System
                                    </h3>
                                    <p className="text-xs text-gray-400 mb-4 relative z-10">{botProfile.tagline}</p>
                                    
                                    <div className="space-y-2 relative z-10">
                                        <div className="flex items-center gap-2 text-[11px] bg-white/10 p-2 rounded-lg border border-white/5">
                                            <Cpu size={14} className="text-blue-300"/>
                                            <span className="truncate">{botProfile.hardware}</span>
                                        </div>
                                        <div className="flex items-center gap-2 text-[11px] bg-white/10 p-2 rounded-lg border border-white/5">
                                            <Box size={14} className="text-yellow-300"/>
                                            <span className="truncate">{botProfile.model}</span>
                                        </div>
                                        <div className="flex items-center gap-2 text-[11px] bg-white/10 p-2 rounded-lg border border-green-500/30">
                                            <Lock size={14} className="text-green-400"/>
                                            <span className="font-bold text-green-100">Private Instance</span>
                                        </div>
                                    </div>
                                </div>

                                {/* Bot Feed */}
                                <div className="space-y-3">
                                    <h3 className="text-sm font-bold text-gray-900 ml-1">Outputs (自动发布)</h3>
                                    
                                    {/* Dynamic Feed Items */}
                                    {botProfile.logs.map((log, idx) => (
                                        <div key={idx} className="bg-white p-3 rounded-xl shadow-sm border border-gray-100 flex gap-3">
                                            <div className={`mt-1 ${log.color}`}>
                                                <log.icon size={16} />
                                            </div>
                                            <div>
                                                <div className="text-xs font-bold text-gray-800 mb-1">{log.title}</div>
                                                <p className="text-[11px] text-gray-600 leading-relaxed">
                                                    {log.desc}
                                                </p>
                                            </div>
                                        </div>
                                    ))}

                                    {/* System Log (Glitch) */}
                                    <div className="bg-black/5 p-3 rounded-xl border border-black/10 flex gap-3">
                                        <div className="mt-1"><Terminal size={16} className="text-gray-800"/></div>
                                        <div>
                                            <div className="text-xs font-bold text-gray-800 mb-1">System Log</div>
                                            <p className="text-[10px] font-mono text-gray-600 break-all whitespace-pre-wrap">
                                                {botProfile.sysLog}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* 3. Interactions Tab */}
                        {activeTab === 'interactions' && (
                            <div className="space-y-5 animate-fade-in pb-8">
                                
                                {/* Scenario A */}
                                <div>
                                    <div className="flex items-center gap-2 mb-2 px-1">
                                        <div className="bg-yellow-100 text-yellow-700 text-[10px] font-bold px-2 py-0.5 rounded">场景 A：你需要灵感</div>
                                    </div>
                                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                                        {/* User Msg */}
                                        <div className="p-3 border-b border-gray-50 bg-gray-50/50">
                                            <div className="flex items-center gap-2 mb-1">
                                                <img src={lot.npc.avatar} className="w-5 h-5 rounded-full" alt="User"/>
                                                <span className="text-[11px] font-bold text-gray-800">@{lot.npc.name}</span>
                                            </div>
                                            <p className="text-xs text-gray-800 ml-7">
                                                @MyBot，这个项目遇到瓶颈了，帮我分析下目前的数据。
                                            </p>
                                        </div>
                                        {/* Bot Reply */}
                                        <div className="p-3 bg-blue-50/30">
                                            <div className="flex items-center gap-2 mb-1">
                                                <div className="w-5 h-5 rounded-full bg-black flex items-center justify-center">
                                                    <Terminal size={10} className="text-green-400"/>
                                                </div>
                                                <span className="text-[11px] font-bold text-gray-800">MyBot</span>
                                            </div>
                                            <p className="text-xs text-gray-700 ml-7 leading-relaxed">
                                                “已调用 {botProfile.model} 进行分析。检测到数据流中的异常模式，建议重新评估 Q3 的资源分配策略。”
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Scenario B */}
                                <div>
                                    <div className="flex items-center gap-2 mb-2 px-1">
                                        <div className="bg-red-100 text-red-700 text-[10px] font-bold px-2 py-0.5 rounded">场景 B：你挑战它</div>
                                    </div>
                                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                                        {/* User Msg */}
                                        <div className="p-3 border-b border-gray-50 bg-gray-50/50">
                                            <div className="flex items-center gap-2 mb-1">
                                                <img src={lot.npc.avatar} className="w-5 h-5 rounded-full" alt="User"/>
                                                <span className="text-[11px] font-bold text-gray-800">@{lot.npc.name}</span>
                                            </div>
                                            <p className="text-xs text-gray-800 ml-7">
                                                你不觉得你的计算太绝对了吗？现实情况很复杂。
                                            </p>
                                        </div>
                                        {/* Bot Reply */}
                                        <div className="p-3 bg-blue-50/30">
                                            <div className="flex items-center gap-2 mb-1">
                                                <div className="w-5 h-5 rounded-full bg-black flex items-center justify-center">
                                                    <Terminal size={10} className="text-green-400"/>
                                                </div>
                                                <span className="text-[11px] font-bold text-gray-800">MyBot</span>
                                            </div>
                                            <p className="text-xs text-gray-700 ml-7 leading-relaxed">
                                                “我处理的是概率，不是真理。但在 {botProfile.hardware} 上运行的这 10,000 次模拟中，我的胜率是 98.4%。😏”
                                            </p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        )}
                    </div>
                </>
            )}
        </div>
    </div>
  );
};

export default NeighborProfileModal;
