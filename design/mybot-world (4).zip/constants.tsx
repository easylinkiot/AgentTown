
import React from 'react';
import { ShoppingBag, CheckSquare, FileText, Calendar } from 'lucide-react';
import { ChatMessage, FloatingMenuItem } from './types';

export const CHAT_DATA: ChatMessage[] = [
  {
    id: 'group_14',
    name: 'powerhoo AIR 项目沟通群(14)',
    avatar: 'https://img.freepik.com/free-psd/3d-illustration-human-avatar-profile_23-2150671142.jpg?w=200', // Group avatar (using existing image)
    message: '子非鱼: 👌',
    time: '3:30 AM',
    highlight: true,
    unreadCount: 2
  },
  {
    id: '2',
    name: 'Platform Design',
    avatar: 'https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?w=200', // 3D Girl with glasses
    message: '@Jason We should align on the prototype first',
    time: '8:17 AM',
  },
  {
    id: '3',
    name: 'Subscription Account',
    avatar: 'https://img.freepik.com/free-psd/3d-illustration-business-man-with-glasses_23-2149436194.jpg?w=200', // 3D Man glasses
    message: 'User behavior report: Confirmed, 68% of users...',
    time: '8:13 AM',
    unreadCount: 8,
    isSystem: true,
  },
  {
    id: '4',
    name: 'Evan Huang',
    avatar: 'https://img.freepik.com/free-psd/3d-illustration-human-avatar-profile_23-2150671122.jpg?w=200', // 3D Boy 2
    message: '[Voice Call]',
    time: '8:07 AM',
    isVoiceCall: true,
  },
  {
    id: '5',
    name: 'yy',
    avatar: 'https://img.freepik.com/free-psd/3d-illustration-person-with-glasses_23-2149436190.jpg?w=200', // 3D Girl Pink hair
    message: 'The lighting zones messed up the baking, so let\'s discuss...',
    time: '6:47 AM',
  },
  {
    id: '6',
    name: 'Findhoo Mini Project',
    avatar: 'https://img.freepik.com/free-psd/3d-illustration-human-avatar-profile_23-2150671140.jpg?w=200', // 3D Character
    message: 'yy: Let\'s sync up tomorrow morning before submission...',
    time: '6:35 AM',
  },
  {
    id: '7',
    name: 'Chang Cheng',
    avatar: 'https://img.freepik.com/free-psd/3d-rendering-avatar_23-2150833560.jpg?w=200', // 3D Bear/Boy
    message: 'Okay, sounds good.',
    time: '6:12 AM',
  },
  {
    id: '8',
    name: 'Team Alpha',
    avatar: 'https://img.freepik.com/free-psd/3d-rendering-avatar_23-2150833536.jpg?w=200', // 3D Boy Cap
    message: 'Meeting notes attached.',
    time: 'Yesterday',
  },
  {
    id: '9',
    name: 'Marketing Dept',
    avatar: 'https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436180.jpg?w=200', // 3D Girl
    message: 'New campaign assets are ready for review.',
    time: 'Yesterday',
  },
];

export const TOWN_MENU_ITEMS: FloatingMenuItem[] = [
  {
    id: 'market',
    label: 'Market',
    icon: <ShoppingBag size={18} className="text-orange-500" />,
    position: { top: '30%', left: '25%' },
  },
  {
    id: 'tasks',
    label: 'Tasks',
    icon: <CheckSquare size={18} className="text-green-500" />,
    position: { top: '45%', right: '15%' },
  },
  {
    id: 'docs',
    label: 'Docs',
    icon: <FileText size={18} className="text-blue-500" />,
    position: { top: '25%', right: '20%' },
  },
  {
    id: 'calendar',
    label: 'Calendar',
    icon: <Calendar size={18} className="text-purple-500" />,
    position: { top: '40%', left: '10%' },
  },
];

export const SIDE_AVATARS = [
  'https://img.freepik.com/premium-psd/3d-cartoon-character-avatar-isolated-3d-rendering_235528-554.jpg?w=200', // 3D Blonde Boy
];
