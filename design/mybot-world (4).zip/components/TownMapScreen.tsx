
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { ChevronLeft, Plus, Minus, Home, Globe, MessageCircle, Mic, Smile, Send, Users, Maximize2, Minimize2, Move, Loader2, Lightbulb } from 'lucide-react';
import { LotData } from '../types';
import NeighborProfileModal from './NeighborProfileModal';
import { GoogleGenAI } from "@google/genai";

interface TownMapScreenProps {
  onBack: () => void;
}

interface WorldChatMsg {
  id: string;
  botId: string;
  senderName: string;
  senderAvatar: string;
  senderRole: string;
  text: string;
  type: 'text' | 'voice' | 'image';
  timestamp: string;
  botIndex: number;
}

// -- Map Constants --
const MAP_WIDTH = 3000; 
const MAP_HEIGHT = 3000;
const TOTAL_BOTS = 100;
const GRID_SIZE = 600; 
const ROAD_WIDTH = 60;

const ROLES = [
  '提示词工程师', 'RLHF 专家', '潜在空间架构师', '向量数据库策略师', 
  'GPU 集群管理员', '代币经济学研究员', '推理优化师', 'Agent 编排员',
  '多模态设计师', '神经伦理学家', '上下文窗口工程师', '模型蒸馏负责人'
];

const COMPANIES = [
  '神经流科技', '深智-X', '代理逻辑', '硅脑实验室', '张量小镇', '开放权重', 
  '梯度实验室', '语境化科技', '超参动力', '合智心灵', '向量核心', '递归 AI'
];

const ACTIONS = [
  '微调 Llama-4', '优化上下文窗口', '训练自主 Agent', '基准测试量化', 
  '设计对齐协议', '扩展 RAG 流水线', '研究涌现行为', '构建代码工具'
];

const NAMES = ['Oliver', 'Luna', 'Felix', 'Maya', 'Leo', 'Nova', 'Silas', 'Ivy', 'Delta', 'Echo', 'Zeta', 'Puck', 'Kore', 'Finn', 'Aria'];

// -- Map Components --

const BotAvatar: React.FC<{ x: number; y: number; avatar: string; name: string; isSpeaking: boolean }> = ({ x, y, avatar, name, isSpeaking }) => (
    <div 
      className="absolute flex flex-col items-center z-40 transition-all duration-500"
      style={{ left: x, top: y }}
    >
       {isSpeaking && (
           <div className="absolute bottom-[100%] mb-1 animate-bounce-small">
               <div className="bg-white text-[8px] px-2 py-1 rounded-lg rounded-bl-none shadow-md border border-gray-100 whitespace-nowrap z-50 flex items-center gap-1">
                   <MessageCircle size={8} className="text-blue-500 fill-blue-500" />
                   <span className="text-gray-800 font-bold max-w-[80px] truncate">发言中...</span>
               </div>
           </div>
       )}
       <div className={`w-8 h-8 rounded-full border-[1.5px] shadow-sm overflow-hidden bg-white relative z-10 transition-transform ${isSpeaking ? 'scale-110 border-blue-500' : 'border-white'}`}>
          <img src={avatar} className="w-full h-full object-cover" />
       </div>
       <div className="w-4 h-3 bg-gray-800 rounded-b-md -mt-1 shadow-sm"></div>
       <div className="mt-0.5 bg-black/40 text-white text-[6px] px-1 rounded-full backdrop-blur-[1px] whitespace-nowrap">
          {name}
       </div>
    </div>
);

const Car: React.FC<{ roadX?: number; roadY?: number; vertical?: boolean; speed: number; color: string; delay: number }> = ({ roadX, roadY, vertical, speed, color, delay }) => {
  const [position, setPosition] = useState(-200);
  useEffect(() => {
    const totalDist = vertical ? MAP_HEIGHT + 400 : MAP_WIDTH + 400;
    let start = -200;
    const interval = setInterval(() => {
      start += speed;
      if (start > totalDist - 200) start = -200;
      setPosition(start);
    }, 30);
    return () => clearInterval(interval);
  }, [speed, vertical]);

  const style: React.CSSProperties = vertical 
    ? { left: (roadX || 0) + ROAD_WIDTH / 2 - 10, top: position, width: 20, height: 35 }
    : { left: position, top: (roadY || 0) + ROAD_WIDTH / 2 - 10, width: 35, height: 20 };

  return <div className={`absolute rounded-sm shadow-md border border-black/10 transition-transform ${color} z-40`} style={{ ...style, transition: 'none' }}><div className={`absolute ${vertical ? 'w-full h-1/4 top-1/4' : 'h-full w-1/4 left-1/4'} bg-black/20`}></div></div>;
};

const Bridge: React.FC<{ x: number; y: number; vertical?: boolean }> = ({ x, y, vertical }) => (
  <div className="absolute z-30" style={{ left: x, top: y, width: vertical ? ROAD_WIDTH : 240, height: vertical ? 240 : ROAD_WIDTH, backgroundColor: '#525252', borderRadius: '4px', border: '4px solid #404040' }}>
    {vertical ? <><div className="absolute left-0 top-0 bottom-0 w-1 bg-[#888] text-white"></div><div className="absolute right-0 top-0 bottom-0 w-1 bg-[#888] text-white"></div></> : <><div className="absolute top-0 left-0 right-0 h-1 bg-[#888] text-white"></div><div className="absolute bottom-0 left-0 right-0 h-1 bg-[#888] text-white"></div></>}
  </div>
);

const FlatHouse: React.FC<{ type: LotData['visualType']; selected: boolean }> = ({ type, selected }) => {
  const styles = { 'red-cottage': { roof: '#c92a2a', body: 'bg-[#fff7ed]' }, 'blue-villa': { roof: '#3b5bdb', body: 'bg-white' }, 'dark-cabin': { roof: '#343a40', body: 'bg-[#f8f9fa]' }, 'brown-manor': { roof: '#78350f', body: 'bg-[#fffbeb]' }, 'market-stall': { roof: '#f59e0b', body: 'bg-[#fef3c7]' } }[type] || { roof: '#777', body: 'bg-white' };
  return (
    <div className={`relative flex flex-col items-center transition-transform duration-300 ${selected ? 'scale-105 z-20' : 'hover:scale-105 z-10'}`}>
        <div className="w-0 h-0 border-l-[30px] border-r-[30px] border-b-[35px] border-l-transparent border-r-transparent filter drop-shadow-sm" style={{ borderBottomColor: styles.roof }}></div>
        <div className={`w-12 h-10 ${styles.body} shadow-md flex justify-center items-end pb-1 -mt-0.5`}><div className="w-4 h-6 bg-amber-900/40 rounded-t-sm"></div></div>
        <div className="absolute -bottom-2 w-14 h-4 bg-black/10 rounded-full blur-[2px] -z-10"></div>
    </div>
  );
};

// -- Map Generation --
const generateCity = () => {
  const lots: LotData[] = [];
  const trees: { x: number; y: number; scale: number }[] = [];
  const roadNetwork: { x?: number; y?: number; vertical: boolean }[] = [];
  const bridges: { x: number; y: number; vertical: boolean }[] = [];
  const getRiverY = (x: number) => 1500 + 400 * Math.sin(x / 600);
  const isOverRiver = (x: number, y: number) => Math.abs(y - getRiverY(x)) < 160;

  for (let x = GRID_SIZE; x < MAP_WIDTH; x += GRID_SIZE) roadNetwork.push({ x, vertical: true });
  for (let y = GRID_SIZE; y < MAP_HEIGHT; y += GRID_SIZE) { if (Math.abs(y - 1500) < 400) continue; roadNetwork.push({ y, vertical: false }); }
  roadNetwork.forEach(road => {
    if (road.vertical) { const x = road.x!; bridges.push({ x: x, y: getRiverY(x) - 120, vertical: true }); }
    else { const y = road.y!; if (Math.abs(y - 1500) < 600) { for (let ix = 200; ix < MAP_WIDTH; ix += 200) { if (Math.abs(y - getRiverY(ix)) < 60) bridges.push({ x: ix - 120, y: y, vertical: false }); } } }
  });
  let attempts = 0;
  while (lots.length < TOTAL_BOTS && attempts < 10000) {
    attempts++;
    const road = roadNetwork[Math.floor(Math.random() * roadNetwork.length)];
    const distFromRoad = 80;
    const side = Math.random() > 0.5 ? 1 : -1;
    let x, y;
    if (road.vertical) { x = road.x! + (side * distFromRoad); y = Math.random() * MAP_HEIGHT; }
    else { x = Math.random() * MAP_WIDTH; y = road.y! + (side * distFromRoad); }
    if (x < 100 || x > MAP_WIDTH - 100 || y < 100 || y > MAP_HEIGHT - 100) continue;
    if (isOverRiver(x, y)) continue;
    if (lots.some(l => Math.hypot(l.x - x, l.y - y) < 140)) continue;
    const visualTypes: LotData['visualType'][] = ['red-cottage', 'blue-villa', 'dark-cabin', 'brown-manor'];
    const visualType = visualTypes[Math.floor(Math.random() * visualTypes.length)];
    const role = ROLES[lots.length % ROLES.length];
    const company = COMPANIES[lots.length % COMPANIES.length];
    const action = ACTIONS[lots.length % ACTIONS.length];
    const name = `${NAMES[lots.length % NAMES.length]}-${lots.length + 1}`;
    // Fix: Remove duplicate 'company' property in the npc object literal.
    lots.push({ id: `bot_${lots.length}`, x, y, label: name, visualType, npc: { name: `${name} Bot`, role, company, avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`, greeting: `你好！正在${action}`, skills: role.split(' ')[0], bio: `@${company}的${role}。` } });
  }
  for (let i = 0; i < 200; i++) {
    const x = Math.random() * MAP_WIDTH; const y = Math.random() * MAP_HEIGHT;
    if (!roadNetwork.some(r => r.vertical ? Math.abs(x - r.x!) < 100 : Math.abs(y - r.y!) < 100) && !isOverRiver(x, y)) trees.push({ x, y, scale: 0.6 + Math.random() * 0.8 });
  }
  return { lots, trees, roadNetwork, bridges, riverPath: Array.from({ length: 150 }).map((_, i) => { const x = (i / 150) * MAP_WIDTH; return `${i === 0 ? 'M' : 'L'} ${x} ${getRiverY(x)}`; }).join(' ') };
};

// -- Main Component --

const TownMapScreen: React.FC<TownMapScreenProps> = ({ onBack }) => {
  const [scale, setScale] = useState(0.4);
  const [selectedLot, setSelectedLot] = useState<LotData | null>(null);
  const [worldChat, setWorldChat] = useState<WorldChatMsg[]>([]);
  const [activeSpeakerId, setActiveSpeakerId] = useState<string | null>(null);
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const nextBotIndexRef = useRef(0);

  // Chat Widget State
  const [chatViewMode, setChatViewMode] = useState<'normal' | 'minimized' | 'maximized'>('normal');
  const [minimizedPos, setMinimizedPos] = useState({ x: 20, y: window.innerHeight - 200 }); 
  const [isDraggingChat, setIsDraggingChat] = useState(false);
  const [isPanning, setIsPanning] = useState(false);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatDragRef = useRef({ x: 0, y: 0 }); 

  const { lots, trees, roadNetwork, bridges, riverPath } = useMemo(() => generateCity(), []);
  
  const carsData = useMemo(() => {
    const carColors = ['bg-red-500', 'bg-blue-500', 'bg-yellow-400', 'bg-white', 'bg-slate-700'];
    return roadNetwork.map((r, i) => ({ ...r, speed: 3 + Math.random() * 5, color: carColors[i % carColors.length], delay: Math.random() * 10 }));
  }, [roadNetwork]);

  useEffect(() => {
    if (containerRef.current) containerRef.current.scrollTo({ left: (MAP_WIDTH * scale) / 4, top: (MAP_HEIGHT * scale) / 4, behavior: 'instant' });
    
    // Initialize with MyBot as Team Lead
    setWorldChat([
        { 
            id: 'sys_init', 
            botId: 'sys', 
            senderName: 'System', 
            senderAvatar: '', 
            senderRole: 'Admin', 
            text: '用户视角需求洞察模式已激活。', 
            type: 'text', 
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 
            botIndex: -1 
        },
        { 
            id: 'lead_1', 
            botId: 'mybot_lead', 
            senderName: 'MyBot (Team Lead)', 
            senderAvatar: 'https://img.freepik.com/premium-psd/3d-cartoon-character-avatar-isolated-3d-rendering_235528-554.jpg?w=200',
            senderRole: 'Product Manager', 
            text: '各位，今天我们换个角度。请大家把自己想象成普通用户（学生、打工人、宝妈等），在衣食住行玩中，你最希望能“一句话生成”什么样的 Mini App 来解决实际麻烦？开始！', 
            type: 'text', 
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 
            botIndex: 0 
        }
    ]);
  }, []);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [worldChat, chatViewMode]);

  // Logic: Bot Sequential Generation
  const generateNextMessage = async () => {
    if (isAiGenerating || nextBotIndexRef.current >= TOTAL_BOTS) return;
    
    setIsAiGenerating(true);
    const botIndex = nextBotIndexRef.current;
    const currentBot = lots[botIndex];
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const recentMsgs = worldChat.filter(m => m.botId !== 'sys').slice(-8).map(m => `${m.senderName} (${m.senderRole}): ${m.text}`).join('\n');
      
      const prompt = `
        你是一个参与《生成式 Mini App 平民化应用》讨论的群成员。
        请暂时忘掉你的技术专家身份，扮演一个【普通人类用户】（例如：正在减肥的白领、赶作业的学生、装修新房的业主、不知道送什么礼物的男朋友、去陌生城市旅游的游客等）。
        
        上下文（最近的几个创意，请避免重复）：
        ${recentMsgs}
        
        任务：提出一个你通过“一句话生成 Mini App”就能解决的具体痛点。
        
        要求：
        1. 格式必须为：【身份：需求】Mini App 构想。
        2. 参考范例风格（请参考以下高质量样本）：
           - 【上班族：信息焦虑】生成一个阅读早报 Mini App，每天早上 8 点，采集 Reddit、TechCrunch 过去 24 小时 AI 热点，生成摘要卡片。
           - 【项目经理：会议记录难】生成一个 Chat 决策摘要机器人，自动汇总群聊中过去 2 小时的技术讨论，提取共识和待分配任务。
           - 【商务人士：邮件积压】生成一个收件箱“脱水”日报，扫描未读邮件，生成“谁发了什么”、“需要我做什么”的结构化总结。
           - 【健忘症：忘记回邮件】生成一个“追单” Mini App，自动标记已发送但超过 3 天未回复的重要邮件，生成“是否再次跟进”按钮。
           - 【骑行爱好者：怕丢车】生成一个车辆守卫 Mini App，当智能锁检测到非授权移动时，弹出实时坐标和周边画面。
        3. 内容必须具体、接地气，体现“普通人”在衣食住行玩工作学习中的真实烦恼。
        4. 严格限制 60 个汉字以内。
        5. 语气自然、口语化。
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });

      const replyText = response.text?.trim() || "【吃货：选店难】输入预算和口味，自动生成本地美食探店路线图的 App。";

      const newMsg: WorldChatMsg = {
        id: Date.now().toString(),
        botId: currentBot.id,
        senderName: currentBot.npc.name,
        senderAvatar: currentBot.npc.avatar,
        senderRole: currentBot.npc.role, // Keep their actual role for display contrast
        text: replyText,
        type: 'text',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        botIndex: botIndex + 1
      };

      setWorldChat(prev => [...prev.slice(-40), newMsg]);
      setActiveSpeakerId(currentBot.id);
      nextBotIndexRef.current = botIndex + 1;

      setTimeout(() => setActiveSpeakerId(null), 3000);
    } catch (e) {
      console.error("Simulation error", e);
    } finally {
      setIsAiGenerating(false);
    }
  };

  useEffect(() => {
      const interval = setInterval(() => {
          generateNextMessage();
      }, 6000); // 6 seconds per bot
      return () => clearInterval(interval);
  }, [worldChat]);

  const handleZoom = (delta: number) => setScale(prev => Math.min(Math.max(0.2, prev + delta), 2.0));
  const handleMapMouseDown = (e: React.MouseEvent) => { if (!(e.target as HTMLElement).closest('button') && !(e.target as HTMLElement).closest('.pointer-events-auto')) setIsPanning(true); };
  const handleMapMouseMove = (e: React.MouseEvent) => { if (!isPanning || !containerRef.current) return; containerRef.current.scrollLeft -= e.movementX; containerRef.current.scrollTop -= e.movementY; };
  const handleMapMouseUp = () => setIsPanning(false);

  const handleChatPointerDown = (e: React.PointerEvent) => {
    if (chatViewMode !== 'minimized') return;
    e.preventDefault(); e.stopPropagation(); setIsDraggingChat(true);
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    chatDragRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  useEffect(() => {
      const handlePointerMove = (e: PointerEvent) => {
          if (!isDraggingChat) return;
          e.preventDefault();
          let newX = Math.max(0, Math.min(e.clientX - chatDragRef.current.x, window.innerWidth - 60));
          let newY = Math.max(0, Math.min(e.clientY - chatDragRef.current.y, window.innerHeight - 60));
          setMinimizedPos({ x: newX, y: newY });
      };
      if (isDraggingChat) { window.addEventListener('pointermove', handlePointerMove); window.addEventListener('pointerup', () => setIsDraggingChat(false)); }
      return () => window.removeEventListener('pointermove', () => {});
  }, [isDraggingChat]);

  const renderChatWidget = () => {
    if (chatViewMode === 'minimized') return (
        <div className="absolute z-[60] cursor-move touch-none animate-scale-in" style={{ left: minimizedPos.x, top: minimizedPos.y }} onPointerDown={handleChatPointerDown}>
            <div className="bg-white/90 backdrop-blur-md rounded-full px-3 py-2 shadow-2xl border border-white/60 flex items-center gap-2 group hover:bg-white active:scale-95 transition-all">
                <div className="bg-green-500 p-1.5 rounded-full text-white animate-pulse"><Lightbulb size={14} /></div>
                <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-gray-800 leading-none">User Needs Brainstorm</span>
                    <span className="text-[8px] text-gray-500 leading-none mt-0.5">Agent {nextBotIndexRef.current + 1} 思考中...</span>
                </div>
                <button onClick={() => setChatViewMode('normal')} className="ml-1 p-1 hover:bg-gray-100 rounded-full text-gray-400"><Maximize2 size={12} /></button>
            </div>
        </div>
    );
    const cardClasses = chatViewMode === 'maximized' ? "w-[80%] h-[80%] bg-white/90 backdrop-blur-xl rounded-3xl shadow-2xl overflow-hidden flex flex-col border border-white/40 animate-scale-in pointer-events-auto" : "w-full h-full bg-white/80 backdrop-blur-xl rounded-3xl border border-white/40 shadow-2xl overflow-hidden pointer-events-auto flex flex-col animate-slide-in-up";
    return (
        <div className={chatViewMode === 'maximized' ? "absolute inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm p-6" : "absolute bottom-0 left-0 w-full sm:w-[320px] h-[350px] z-50 pointer-events-none flex flex-col justify-end p-4"}>
             <div className={cardClasses}>
                <div className="bg-white/50 border-b border-gray-100 p-3 flex justify-between items-center backdrop-blur-md shrink-0">
                    <div className="flex items-center gap-2">
                        <div className="bg-green-500 p-1.5 rounded-lg text-white"><Users size={14} /></div>
                        <div className="flex flex-col">
                            <span className="text-xs font-bold text-gray-900">Agent Team (Bot: {nextBotIndexRef.current}/100)</span>
                            <span className="text-[9px] text-green-600 font-medium flex items-center gap-1"><span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span> 脑暴主题: 普通用户 Mini App 需求</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-1">
                        <button onClick={() => setChatViewMode(chatViewMode === 'maximized' ? 'normal' : 'maximized')} className="p-1.5 hover:bg-gray-200/50 rounded-full text-gray-500">{chatViewMode === 'maximized' ? <Minimize2 size={16} /> : <Maximize2 size={16} />}</button>
                        <button onClick={() => setChatViewMode('minimized')} className="p-1.5 hover:bg-gray-200/50 rounded-full text-gray-500"><Minus size={16} /></button>
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto p-3 space-y-3 no-scrollbar mask-gradient-top">
                    {worldChat.map((msg) => (
                        <div key={msg.id} className="flex gap-2 animate-fade-in-up">
                            {msg.botId === 'sys' ? <div className="w-full flex justify-center my-1"><span className="text-[9px] bg-gray-200 text-gray-500 px-2 py-0.5 rounded-full">{msg.text}</span></div> : <>
                                <img src={msg.senderAvatar} className="w-7 h-7 rounded-lg bg-gray-100 border border-white shadow-sm shrink-0" />
                                <div className="flex flex-col max-w-[85%]">
                                    <div className="flex items-baseline gap-1.5 mb-0.5">
                                        <span className={`text-[10px] font-bold truncate ${msg.botId === 'mybot_lead' ? 'text-blue-600' : 'text-gray-600'}`}>{msg.senderName}</span>
                                        <span className="text-[8px] text-gray-400 bg-gray-100 px-1 rounded truncate">
                                            {msg.botId === 'mybot_lead' ? 'TEAM LEAD' : `Bot #${msg.botIndex} • ${msg.senderRole}`}
                                        </span>
                                    </div>
                                    <div className={`p-2 rounded-xl rounded-tl-none shadow-sm text-[10px] border leading-relaxed ${msg.botId === 'mybot_lead' ? 'bg-blue-50 text-blue-900 border-blue-100' : 'bg-white text-gray-800 border-gray-50'}`}>
                                        {msg.text}
                                    </div>
                                </div>
                            </>}
                        </div>
                    ))}
                    {isAiGenerating && (
                        <div className="flex gap-2 items-center opacity-50 px-2">
                             <Loader2 size={12} className="animate-spin text-blue-500" />
                             <span className="text-[10px] text-gray-400">Bot {nextBotIndexRef.current + 1} 构思创意中...</span>
                        </div>
                    )}
                    <div ref={chatEndRef} />
                </div>
                <div className="p-2 bg-white border-t border-gray-100 flex items-center gap-2 shrink-0">
                    <button className="p-1.5 rounded-full hover:bg-gray-100"><Mic size={14} className="text-gray-400"/></button>
                    <div className="flex-1 bg-gray-100 h-7 rounded-lg flex items-center px-2 text-[10px] text-gray-400 select-none">旁观模式 (Team Lead 已锁定议题)</div>
                    <button className="p-1.5 rounded-full hover:bg-gray-100"><Plus size={14} className="text-gray-400"/></button>
                </div>
             </div>
        </div>
    );
  };

  return (
    <div className="w-full h-full bg-[#7ec850] relative overflow-hidden font-sans select-none">
      <div ref={containerRef} className={`w-full h-full overflow-auto no-scrollbar relative ${isPanning ? 'cursor-grabbing' : 'cursor-grab'}`} onMouseDown={handleMapMouseDown} onMouseMove={handleMapMouseMove} onMouseUp={handleMapMouseUp} onMouseLeave={handleMapMouseUp}>
        <div className="relative transition-transform duration-300 origin-top-left" style={{ width: `${MAP_WIDTH * scale}px`, height: `${MAP_HEIGHT * scale}px` }}>
            <div style={{ transform: `scale(${scale})`, transformOrigin: '0 0', width: `${MAP_WIDTH}px`, height: `${MAP_HEIGHT}px`, position: 'absolute', pointerEvents: 'none' }}>
                <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/grass.png')]"></div>
                {roadNetwork.map((road, i) => <div key={`road-${i}`} className="absolute bg-[#404040] shadow-inner" style={{ left: road.vertical ? road.x : 0, top: road.vertical ? 0 : road.y, width: road.vertical ? ROAD_WIDTH : MAP_WIDTH, height: road.vertical ? MAP_HEIGHT : ROAD_WIDTH, zIndex: 10 }}><div className={`absolute ${road.vertical ? 'h-full w-0.5 left-1/2' : 'w-full h-0.5 top-1/2'} border-dashed border-white/30`} style={{ borderStyle: 'dashed', borderWidth: road.vertical ? '0 0 0 2px' : '2px 0 0 0' }}></div></div>)}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-0"><path d={riverPath} fill="none" stroke="#38bdf8" strokeWidth="180" strokeLinecap="round" className="opacity-70" /><path d={riverPath} fill="none" stroke="#a5f3fc" strokeWidth="240" strokeLinecap="round" className="opacity-30" /></svg>
                {bridges.map((b, i) => <Bridge key={`bridge-${i}`} {...b} />)}
                {carsData.map((c, i) => <Car key={`car-${i}`} roadX={c.x} roadY={c.y} vertical={c.vertical} speed={c.speed} color={c.color} delay={c.delay} />)}
                {trees.map((t, i) => <div key={`t-${i}`} className="absolute flex flex-col items-center pointer-events-none" style={{ left: t.x, top: t.y, transform: `scale(${t.scale})`, zIndex: Math.floor(t.y) }}><div className="w-16 h-16 bg-[#2f9e44] rounded-full -mb-6 relative z-10 shadow-sm border-b-4 border-[#2b8a3e]"></div><div className="w-3 h-8 bg-[#8a5a44] rounded-sm"></div></div>)}
                {lots.map(lot => (
                    <React.Fragment key={lot.id}>
                        <div onClick={(e) => { e.stopPropagation(); setSelectedLot(lot); }} className="absolute flex flex-col items-center cursor-pointer group pointer-events-auto" style={{ left: lot.x, top: lot.y, zIndex: Math.floor(lot.y) }}><FlatHouse type={lot.visualType} selected={selectedLot?.id === lot.id} /></div>
                        <BotAvatar x={lot.x + 30} y={lot.y + 40} avatar={lot.npc.avatar} name={lot.npc.name.split(' ')[0]} isSpeaking={activeSpeakerId === lot.id} />
                    </React.Fragment>
                ))}
            </div>
        </div>
      </div>
      <div className="absolute top-0 left-0 right-0 p-4 pt-safe-top flex items-center justify-between pointer-events-none z-50">
        <button onClick={onBack} className="pointer-events-auto w-12 h-12 bg-white/95 backdrop-blur rounded-full flex items-center justify-center shadow-xl text-gray-800 active:scale-90 transition-transform"><ChevronLeft size={28} /></button>
        <div className="bg-white/95 backdrop-blur px-5 py-2 rounded-full shadow-xl flex items-center gap-2 border border-white/50 pointer-events-auto"><Globe size={16} className="text-green-600" /><span className="text-xs font-black text-gray-800 uppercase">AI 创业大地图 (100 位 Agent 实时辩论)</span></div>
      </div>
      <div className="absolute bottom-32 right-6 z-50 flex flex-col gap-3 pointer-events-auto"><button onClick={() => handleZoom(0.1)} className="w-12 h-12 bg-white/95 backdrop-blur rounded-full flex items-center justify-center shadow-xl text-gray-800 border border-white/50"><Plus size={24} /></button><button onClick={() => handleZoom(-0.1)} className="w-12 h-12 bg-white/95 backdrop-blur rounded-full flex items-center justify-center shadow-xl text-gray-800 border border-white/50"><Minus size={24} /></button></div>
      {renderChatWidget()}
      {selectedLot && <NeighborProfileModal lot={selectedLot} onClose={() => setSelectedLot(null)} />}
    </div>
  );
};

export default TownMapScreen;
