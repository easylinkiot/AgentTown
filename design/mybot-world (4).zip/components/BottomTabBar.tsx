
import React from 'react';
import { MiniApp } from '../types';

interface BottomTabBarProps {
  tabs: MiniApp[];
  activeTabId: string | null;
  onTabClick: (app: MiniApp) => void;
}

const BottomTabBar: React.FC<BottomTabBarProps> = ({ tabs, activeTabId, onTabClick }) => {
  return (
    <div className="absolute bottom-6 left-0 right-0 z-[80] flex justify-center animate-slide-in-up pointer-events-none">
        <div className="pointer-events-auto bg-[#1c1c1e]/80 backdrop-blur-2xl border border-white/10 px-2 py-2.5 rounded-[32px] shadow-[0_10px_40px_rgba(0,0,0,0.5)] flex items-center gap-3 mx-4 max-w-full overflow-hidden ring-1 ring-white/5">
        
        {/* Brand / Label */}
        <div className="flex flex-col items-center justify-center shrink-0 px-3 border-r border-white/10 mr-1 opacity-50">
            <span className="text-[9px] font-black text-white leading-none uppercase tracking-wider">Mini</span>
            <span className="text-[10px] font-black text-white leading-none uppercase tracking-wider">OS</span>
        </div>

        {/* Scrollable Tabs */}
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar mask-gradient-right px-1">
            {tabs.map((app) => {
                let label = app.title.slice(0, 2);
                if (app.title.includes('订阅') || app.title.includes('新闻')) label = '热点';
                else if (app.title.includes('单词') || app.title.includes('学习') || app.title.includes('英语')) label = '学习';
                else if (app.title.includes('比价') || app.title.includes('价格') || app.title.includes('监控')) label = '比价';
                
                const isActive = activeTabId === app.id;

                return (
                    <button
                    key={app.id}
                    onClick={() => onTabClick(app)}
                    className={`
                        shrink-0 relative w-12 h-12 rounded-[16px] transition-all duration-300 flex flex-col items-center justify-center
                        ${isActive 
                            ? 'bg-white text-black shadow-lg shadow-white/20 scale-105' 
                            : 'bg-white/10 text-white hover:bg-white/20'}
                    `}
                    >
                        <span className="text-[10px] font-bold">{label}</span>
                        {isActive && (
                            <div className="absolute -bottom-1 w-1 h-1 bg-white rounded-full"></div>
                        )}
                    </button>
                );
            })}
            {tabs.length === 0 && (
                <div className="px-2 text-white/30 text-[10px] font-medium whitespace-nowrap italic">
                    Create Apps...
                </div>
            )}
        </div>
        </div>
    </div>
  );
};

export default BottomTabBar;
