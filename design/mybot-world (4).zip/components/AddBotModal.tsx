
import React, { useState } from 'react';
import { X, QrCode, Search, UserPlus, ScanLine } from 'lucide-react';

interface AddBotModalProps {
  onClose: () => void;
}

const AddBotModal: React.FC<AddBotModalProps> = ({ onClose }) => {
  const [botId, setBotId] = useState('');

  return (
    <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#1c1c1e]/80 backdrop-blur-2xl w-full max-w-sm rounded-[32px] shadow-2xl overflow-hidden animate-scale-in flex flex-col border border-white/10">
        
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex justify-between items-center bg-white/5">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <UserPlus size={20} className="text-green-500" />
            Add Bot Friend
          </h2>
          <button 
            onClick={onClose}
            className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white/70 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          
          {/* Search Input */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase ml-1">Bot ID / Name</label>
            <div className="flex items-center gap-2 bg-black/40 p-1 rounded-2xl border border-white/10 focus-within:border-green-500 transition-all">
                <div className="p-2 text-gray-500">
                    <Search size={20} />
                </div>
                <input 
                    type="text" 
                    value={botId}
                    onChange={(e) => setBotId(e.target.value)}
                    placeholder="e.g. elon_bot_v2"
                    className="flex-1 bg-transparent outline-none text-white font-medium placeholder-gray-600 h-10"
                />
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/10"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-[#1c1c1e] px-2 text-gray-500 font-bold">Or</span>
            </div>
          </div>

          {/* QR Scan Button */}
          <button className="w-full py-4 border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center gap-2 text-gray-400 hover:bg-white/5 hover:border-green-500/50 hover:text-green-500 transition-all group">
             <div className="bg-white/10 p-3 rounded-full group-hover:bg-green-500/20 transition-colors">
                <ScanLine size={24} />
             </div>
             <span className="text-sm font-bold">Scan QR Code</span>
          </button>

          {/* Add Button */}
          <button 
             className="w-full bg-[#07C160] hover:bg-[#06ad56] text-white font-bold py-3.5 rounded-2xl shadow-lg shadow-green-500/30 active:scale-95 transition-all flex items-center justify-center gap-2"
             onClick={onClose}
          >
             <UserPlus size={18} />
             Add to Contacts
          </button>

        </div>
      </div>
    </div>
  );
};

export default AddBotModal;
