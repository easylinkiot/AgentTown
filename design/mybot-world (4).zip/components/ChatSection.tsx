
import React from 'react';
import { CHAT_DATA } from '../constants';
import ChatListItem from './ChatListItem';

interface ChatSectionProps {
  onChatClick: (chatId: string) => void;
}

const ChatSection: React.FC<ChatSectionProps> = ({ onChatClick }) => {
  return (
    <div className="flex-1 bg-[#1c1c1e]/60 backdrop-blur-2xl relative -mt-6 rounded-t-[40px] shadow-[0_-10px_40px_rgba(0,0,0,0.6)] z-30 flex flex-col overflow-hidden border-t border-white/10 ring-1 ring-white/5">
      {/* Handle bar for visual cue of sheet */}
      <div className="w-full flex justify-center pt-3 pb-1">
        <div className="w-10 h-1 bg-white/20 rounded-full backdrop-blur-sm"></div>
      </div>
      
      {/* Scrollable List */}
      <div className="flex-1 overflow-y-auto no-scrollbar pb-10 pt-1">
        <div className="flex flex-col px-3 space-y-0.5">
          {CHAT_DATA.slice(0, 6).map((chat) => (
            <ChatListItem 
              key={chat.id} 
              chat={chat} 
              onClick={() => onChatClick(chat.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ChatSection;
