
import React from 'react';
import { ChatMessage } from '../types';

interface ChatListItemProps {
  chat: ChatMessage;
  onClick: () => void;
}

const ChatListItem: React.FC<ChatListItemProps> = ({ chat, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="flex items-center gap-3 py-2 px-3 rounded-[16px] hover:bg-white/10 active:bg-white/15 transition-all cursor-pointer group"
    >
      {/* Avatar */}
      <div className="relative flex-shrink-0">
        <div className="w-[38px] h-[38px] rounded-[14px] overflow-hidden bg-white/5 border border-white/10 shadow-sm group-hover:scale-105 transition-transform">
            <img 
            src={chat.avatar} 
            alt={chat.name} 
            className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" 
            />
        </div>
        {chat.unreadCount && (
          <div className="absolute -top-1 -right-1 bg-[#FF3B30] text-white text-[9px] font-bold px-1 min-w-[14px] h-[14px] flex items-center justify-center rounded-full border border-[#1c1c1e] shadow-sm">
            {chat.unreadCount}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 py-0.5">
        <div className="flex justify-between items-baseline mb-0.5">
          <h4 className="text-[13px] font-semibold text-white truncate pr-2 tracking-tight">
            {chat.name}
          </h4>
          <span className="text-[10px] text-gray-400 flex-shrink-0 font-medium opacity-80">
            {chat.time}
          </span>
        </div>
        <p className={`text-[11px] truncate leading-snug ${chat.highlight ? 'text-gray-200 font-medium' : 'text-gray-400/90'}`}>
          {chat.highlight && <span className="text-blue-400 font-semibold mr-1">[{chat.unreadCount}]</span>}
          {chat.message}
        </p>
      </div>
      
      {/* Chevron for depth */}
      <div className="text-gray-600 opacity-0 group-hover:opacity-50 transition-opacity">
          <svg width="5" height="8" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1 9L5 5L1 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
      </div>
    </div>
  );
};

export default ChatListItem;
