
import React, { useState, useMemo } from 'react';
import { X, RefreshCw, Share2, TrendingUp, TrendingDown, Clock, MessageSquare, Volume2, RotateCw, Tag, BarChart2, Activity, Zap, Eye } from 'lucide-react';
import { MiniApp } from '../types';
import * as LucideIcons from 'lucide-react';

interface MiniAppRendererProps {
  app: MiniApp;
  onClose: () => void;
}

// --- Visual Components ---

const Sparkline = ({ data, color = "#10b981", height = 24, width = 60, fill = true }: { data: number[], color?: string, height?: number, width?: number, fill?: boolean }) => {
  if (!data || data.length < 2) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1);
  
  const points = data.map((d, i) => {
    const x = i * step;
    const y = height - ((d - min) / range) * height; // Invert Y
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width={width} height={height} className="overflow-visible">
      <defs>
        <linearGradient id={`grad-${color.replace('#', '')}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={color} stopOpacity={0.2} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      {fill && <polygon points={`0,${height} ${points} ${width},${height}`} fill={`url(#grad-${color.replace('#', '')})`} stroke="none" />}
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={width} cy={height - ((data[data.length-1] - min) / range) * height} r="1.5" fill={color} />
    </svg>
  );
};

const ProgressBar = ({ value, max = 100, color = "bg-blue-500", trackColor = "bg-gray-100", height = "h-1.5" }: { value: number, max?: number, color?: string, trackColor?: string, height?: string }) => {
    const percent = Math.min(100, Math.max(0, (value / max) * 100));
    return (
        <div className={`w-full ${height} ${trackColor} rounded-full overflow-hidden`}>
            <div className={`h-full rounded-full ${color}`} style={{ width: `${percent}%` }}></div>
        </div>
    );
};

const CircularProgress = ({ value, size = 36, color = "#8b5cf6", strokeWidth = 3, label }: { value: number, size?: number, color?: string, strokeWidth?: number, label?: string }) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const offset = circumference - (value / 100) * circumference;

    return (
        <div className="relative flex flex-col items-center gap-1">
            <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
                <svg width={size} height={size} className="transform -rotate-90">
                    <circle cx={size/2} cy={size/2} r={radius} stroke="#f3f4f6" strokeWidth={strokeWidth} fill="none" />
                    <circle cx={size/2} cy={size/2} r={radius} stroke={color} strokeWidth={strokeWidth} fill="none" strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round" />
                </svg>
                <span className="absolute text-[8px] font-bold text-gray-700">{Math.round(value)}%</span>
            </div>
            {label && <span className="text-[8px] text-gray-500 font-medium">{label}</span>}
        </div>
    );
};

// --- Main Renderer ---

const MiniAppRenderer: React.FC<MiniAppRendererProps> = ({ app, onClose }) => {
  // Dynamic Icon
  const IconComponent = (LucideIcons as any)[app.icon] || LucideIcons.Zap;

  // Render logic based on app type
  const renderContent = () => {
    switch (app.type) {
      case 'news_feed':
        return <NewsFeedView data={app.content} />;
      case 'flashcard':
        return <FlashcardView data={app.content} />;
      case 'price_tracker':
        return <PriceTrackerView data={app.content} />;
      default:
        return <div className="p-4 text-center text-gray-500">不支持的应用类型</div>;
    }
  };

  return (
    <div className="absolute inset-0 z-[70] flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm animate-fade-in">
        <div className="bg-[#F2F2F6] w-full h-[85%] max-w-sm rounded-[32px] shadow-2xl overflow-hidden flex flex-col animate-scale-in border border-white/40">
            
            {/* App Header */}
            <div className="bg-white/80 backdrop-blur-md px-4 py-3 border-b border-gray-200 flex justify-between items-center shrink-0">
                <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl ${app.color || 'bg-black'} flex items-center justify-center text-white shadow-md shadow-${app.color?.split('-')[1]}-200`}>
                        <IconComponent size={18} />
                    </div>
                    <div>
                        <h2 className="text-sm font-bold text-gray-900 leading-none">{app.title}</h2>
                        <span className="text-[9px] text-gray-500 font-medium mt-1 block">
                            AI 生成应用
                        </span>
                    </div>
                </div>
                <div className="flex gap-2">
                     <button className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors">
                        <Share2 size={18} />
                     </button>
                     <button onClick={onClose} className="p-2 hover:bg-red-50 hover:text-red-500 rounded-full text-gray-500 transition-colors">
                        <X size={18} />
                     </button>
                </div>
            </div>

            {/* App Body */}
            <div className="flex-1 overflow-y-auto no-scrollbar relative">
                 {renderContent()}
            </div>
            
            {/* App Footer */}
            <div className="bg-white px-4 py-2 border-t border-gray-200 shrink-0 flex justify-between items-center">
                 <span className="text-[9px] text-gray-400 font-medium">AI 自动生成内容</span>
                 <div className="flex items-center gap-1 text-[9px] text-green-600 font-bold bg-green-50 px-2 py-0.5 rounded-full border border-green-100">
                    <Activity size={10} />
                    实时数据
                 </div>
            </div>
        </div>
    </div>
  );
};

// --- Views ---

// 1. News Feed Template
const NewsFeedView: React.FC<{ data: any }> = ({ data }) => {
    const items = Array.isArray(data) ? data : (data.items || []);

    return (
        <div className="p-4 space-y-4">
            <div className="space-y-3">
                {items.map((item: any, idx: number) => {
                    // Simulate random engagement data
                    const views = Math.floor(Math.random() * 5000) + 1000;
                    const heat = Math.floor(Math.random() * 100);
                    
                    return (
                        <div key={idx} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 active:scale-[0.99] transition-transform group">
                            <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                    <span className="text-[9px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
                                        {item.source || '快讯'}
                                    </span>
                                    <span className="text-[9px] text-gray-400 flex items-center gap-0.5">
                                        <Clock size={8} /> {item.time || '2小时前'}
                                    </span>
                                </div>
                                <div className="flex items-center gap-1 text-[9px] text-gray-400">
                                    <Eye size={10} /> {views}
                                </div>
                            </div>
                            
                            <h3 className="text-xs font-bold text-gray-800 leading-snug mb-1.5 group-hover:text-blue-600 transition-colors">
                                {item.title}
                            </h3>
                            <p className="text-[11px] text-gray-500 leading-relaxed line-clamp-2 mb-3">
                                {item.summary}
                            </p>

                            {/* Engagement Viz */}
                            <div className="flex items-center gap-3 pt-2 border-t border-gray-50">
                                <div className="flex-1">
                                    <div className="flex justify-between text-[8px] text-gray-400 mb-0.5">
                                        <span>热度指数</span>
                                        <span className="font-bold text-orange-500">{heat}/100</span>
                                    </div>
                                    <ProgressBar value={heat} color="bg-gradient-to-r from-orange-400 to-red-500" height="h-1" />
                                </div>
                                {item.tag && (
                                    <div className="px-2 py-0.5 bg-gray-50 rounded text-[9px] text-gray-500 font-medium">
                                        #{item.tag}
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

// 2. Flashcard Template
const FlashcardView: React.FC<{ data: any }> = ({ data }) => {
    const [flipped, setFlipped] = useState(false);
    
    // Fallback if data structure varies slightly
    const word = data.word || "Serendipity";
    const phonetic = data.pronunciation || "/ˌser.ənˈdɪp.ə.ti/";
    const def = data.definition || "意外发现珍奇事物的本领；机缘凑巧。";
    const example = data.example || "We found the restaurant by pure serendipity.";

    // Simulated Stats
    const mastery = 72;
    const history = [20, 45, 60, 65, 72];

    return (
        <div className="flex flex-col h-full bg-gray-50">
            {/* Stats Bar */}
            <div className="px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <CircularProgress value={mastery} color="#8b5cf6" size={40} label="掌握度" />
                    <div>
                        <div className="text-[10px] text-gray-400 font-bold uppercase">连续打卡</div>
                        <div className="flex items-baseline gap-1">
                            <span className="text-lg font-black text-gray-800">12</span>
                            <span className="text-[10px] text-gray-500">天</span>
                        </div>
                    </div>
                </div>
                <div className="text-right">
                    <div className="text-[10px] text-gray-400 font-bold uppercase">下次复习</div>
                    <div className="text-xs font-bold text-purple-600">4小时后</div>
                </div>
            </div>

            <div className="flex-1 px-6 pb-6 flex flex-col justify-center">
                <div 
                    className="w-full aspect-[4/5] perspective-1000 cursor-pointer"
                    onClick={() => setFlipped(!flipped)}
                >
                    <div className={`relative w-full h-full duration-500 transform-style-3d transition-transform ${flipped ? 'rotate-y-180' : ''}`}>
                        
                        {/* Front */}
                        <div className="absolute w-full h-full backface-hidden bg-white rounded-[32px] shadow-xl border border-white/60 flex flex-col items-center justify-between p-8 text-center bg-gradient-to-b from-white to-purple-50/30">
                            <div className="w-full flex justify-between items-start">
                                <span className="text-[10px] font-bold text-white bg-purple-500 px-2 py-0.5 rounded-full shadow-sm shadow-purple-200">每日单词</span>
                                <Volume2 size={16} className="text-gray-400 hover:text-purple-600 transition-colors" />
                            </div>
                            
                            <div>
                                <h2 className="text-3xl font-black text-gray-800 mb-2 tracking-tight">{word}</h2>
                                <div className="inline-block bg-gray-100 px-3 py-1 rounded-full text-xs font-mono text-gray-500 border border-gray-200">
                                    {phonetic}
                                </div>
                            </div>

                            <div className="w-full">
                                <div className="flex justify-center mb-2">
                                     <span className="text-[9px] text-gray-400 font-medium animate-pulse">点击翻转卡片</span>
                                </div>
                                {/* Simple visual decor */}
                                <div className="h-1 w-16 bg-gray-100 rounded-full mx-auto"></div>
                            </div>
                        </div>

                        {/* Back */}
                        <div className="absolute w-full h-full backface-hidden bg-gray-900 text-white rounded-[32px] shadow-xl flex flex-col p-8 rotate-y-180 border border-gray-700">
                             <div className="flex-1 flex flex-col justify-center text-center">
                                <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-2">释义</span>
                                <p className="text-sm font-medium leading-relaxed mb-6">{def}</p>
                                
                                <div className="bg-white/10 p-4 rounded-2xl border border-white/5 text-left mb-6">
                                    <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest block mb-1">例句</span>
                                    <p className="text-xs italic text-gray-300">"{example}"</p>
                                </div>
                             </div>

                             <div className="border-t border-white/10 pt-4">
                                <div className="flex justify-between items-end mb-2">
                                    <span className="text-[9px] font-bold text-gray-500 uppercase">记忆曲线</span>
                                </div>
                                <SparklesSparkline data={history} color="#a78bfa" height={30} width={200} />
                             </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="px-6 pb-4 flex justify-center">
                 <button className="flex items-center gap-2 text-xs font-bold text-gray-500 hover:text-gray-900 transition-colors bg-white px-4 py-2 rounded-full shadow-sm border border-gray-100">
                    <RotateCw size={14} /> 下一个
                </button>
            </div>
            <style>{`.perspective-1000 { perspective: 1000px; } .transform-style-3d { transform-style: preserve-3d; } .backface-hidden { backface-visibility: hidden; } .rotate-y-180 { transform: rotateY(180deg); }`}</style>
        </div>
    );
};

// 3. Price Tracker Template
const PriceTrackerView: React.FC<{ data: any }> = ({ data }) => {
    const items = Array.isArray(data) ? data : (data.items || []);

    return (
        <div className="p-4 space-y-5">
             {/* Category Tabs */}
             <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                 {['全部', '鞋履', '数码', '家居'].map((cat, i) => (
                     <button key={i} className={`px-3 py-1.5 rounded-full text-[10px] font-bold whitespace-nowrap transition-colors ${i===0 ? 'bg-black text-white shadow-md' : 'bg-white text-gray-500 border border-gray-200 hover:bg-gray-50'}`}>
                         {cat}
                     </button>
                 ))}
             </div>

             {/* Items List */}
             <div className="space-y-4">
                 {items.map((item: any, idx: number) => {
                     // Generate Simulated Price History
                     const basePrice = item.price || 100;
                     const history = [
                         basePrice * 1.05, 
                         basePrice * 1.02, 
                         basePrice * 1.08, 
                         basePrice * 1.04, 
                         basePrice * 0.98,
                         basePrice
                     ];
                     const isDrop = item.trend === 'down';
                     const percentChange = Math.floor(Math.random() * 15) + 5;

                     return (
                         <div key={idx} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col gap-3">
                             {/* Top Row: Icon + Info + Current Price */}
                             <div className="flex gap-3">
                                <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center text-2xl border border-gray-100 shadow-inner">
                                    {item.product?.includes('LEGO') ? '🧱' : item.product?.includes('Lululemon') ? '🧘' : '👟'}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <h4 className="text-xs font-bold text-gray-800 truncate mb-1">{item.product}</h4>
                                    <div className="flex items-center gap-1 text-[9px] text-gray-400">
                                        <Tag size={10} /> {item.retailer}
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className="text-sm font-black text-gray-900">¥{item.price}</div>
                                    <div className={`text-[9px] font-bold flex items-center justify-end gap-0.5 ${isDrop ? 'text-green-600' : 'text-red-500'}`}>
                                        {isDrop ? <TrendingDown size={10} /> : <TrendingUp size={10} />}
                                        {percentChange}%
                                    </div>
                                </div>
                             </div>

                             {/* Bottom Row: Sparkline + Action */}
                             <div className="bg-gray-50 rounded-xl p-3 flex items-center justify-between border border-gray-100">
                                 <div className="flex flex-col gap-1">
                                     <span className="text-[8px] font-bold text-gray-400 uppercase">30天价格趋势</span>
                                     <Sparkline data={history} color={isDrop ? "#10b981" : "#ef4444"} width={80} height={24} />
                                 </div>
                                 <div className="h-6 w-[1px] bg-gray-200"></div>
                                 <button className="text-[10px] font-bold bg-black text-white px-3 py-1.5 rounded-lg hover:scale-105 transition-transform shadow-md">
                                     查看详情
                                 </button>
                             </div>
                         </div>
                     );
                 })}
             </div>
             
             {/* Total Savings Card */}
             <div className="bg-gradient-to-r from-orange-400 to-pink-500 rounded-2xl p-4 text-white shadow-lg shadow-orange-200">
                 <div className="flex justify-between items-center mb-2">
                     <span className="text-[10px] font-bold opacity-80 uppercase tracking-wider">潜在节省</span>
                     <Zap size={14} className="fill-white" />
                 </div>
                 <div className="flex items-baseline gap-1">
                    <h3 className="text-2xl font-black">¥325.00</h3>
                    <span className="text-[10px] opacity-80">今日发现</span>
                 </div>
                 <div className="mt-3 bg-white/20 h-1.5 rounded-full overflow-hidden">
                     <div className="bg-white w-[60%] h-full rounded-full"></div>
                 </div>
             </div>
        </div>
    );
};

// Helper Wrapper for Flashcard Sparkline to reuse
const SparklesSparkline = (props: any) => <Sparkline {...props} />;

export default MiniAppRenderer;
