
import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Save, Shuffle, Check, ChevronRight, Upload, Loader, Trash2, Settings, Plus, X, PenTool, Code, Layout, Users, Megaphone, Download, Package, FileCode, Brain, Folder, FileText as FileIcon, ChevronLeft, Zap, Hash } from 'lucide-react';
import { BotConfig } from '../types';
import { GoogleGenAI, Type } from "@google/genai";

interface ConfigScreenProps {
  currentConfig: BotConfig;
  onSave: (config: BotConfig) => void;
  onBack: () => void;
}

interface MarketModule {
  name: string;
  type: 'file' | 'folder';
  desc: string;
  size?: string;
  tags?: string[]; // Added tags for file modules
}

interface MarketItem {
  id: string;
  name: string; // e.g., anthropics/skills
  description: string; // Brief description
  fullDetail: string; // Content to inject into bot memory
  modules: MarketModule[]; // Virtual file system for "Brain" view
  keywords?: string[]; // Core capability tags
}

interface MarketCategory {
  id: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  color: string;
  items: MarketItem[];
}

interface SkillForm {
  name: string;
  description: string;
  trigger: string;
  logic: string;
  requiredParams: string;
  optionalParams: string;
  constraints: string;
  example: string;
}

const MARKET_DATA: MarketCategory[] = [
  {
    id: 'eng',
    title: '1. 工程师类',
    subtitle: 'AI 代理与本地模型库',
    icon: <Code size={20} />,
    color: 'bg-blue-500/20 text-blue-300',
    items: [
      {
        id: 'anthropic-skills',
        name: 'anthropics/skills',
        description: '官方开源的技能规范和常用工具集，支持 MCP 标准。',
        fullDetail: '已集成 Anthropics 官方工具集：包含文件系统操作、Bash 命令执行等标准 MCP 工具接口。',
        keywords: ['MCP Protocol', 'File System Ops', 'Bash Execution', 'Screen Interaction'],
        modules: [
            { name: 'computer_use', type: 'folder', desc: 'Screen interaction module', tags: ['GUI', 'Vision'] },
            { name: 'bash_tool.py', type: 'file', desc: 'Command line interface', size: '12KB', tags: ['Shell', 'Automation'] },
            { name: 'file_system.js', type: 'file', desc: 'Read/Write operations', size: '8KB', tags: ['I/O', 'Node'] },
            { name: 'str_replace.py', type: 'file', desc: 'String manipulation utility', size: '4KB' }
        ]
      },
      {
        id: 'langgraph-agents',
        name: 'jenasuraj/Ai_agents',
        description: '基于 LangGraph 的专业 Agent 集合 (GitHub管理, 市场分析)。',
        fullDetail: '已集成 LangGraph Agent 模板：具备 GitHub 仓库管理、自动化市场调研分析能力。',
        keywords: ['LangGraph', 'GitHub API', 'Web Scraping', 'Market Research'],
        modules: [
            { name: 'workflows', type: 'folder', desc: 'Graph definition files' },
            { name: 'github_agent.py', type: 'file', desc: 'Repo management logic', size: '24KB', tags: ['REST API', 'Git'] },
            { name: 'market_research.py', type: 'file', desc: 'Web scraper & summarizer', size: '18KB', tags: ['BeautifulSoup', 'Analysis'] },
            { name: 'config.json', type: 'file', desc: 'Agent configuration', size: '2KB' }
        ]
      },
      {
        id: 'unsloth-lib',
        name: 'unslothai/unsloth',
        description: '本地微调最快库，提供现成 Python 脚本。',
        fullDetail: '已集成 Unsloth 微调能力：能够快速生成和优化本地模型微调脚本。',
        keywords: ['Model Fine-tuning', 'LoRA Optimization', 'Python Scripts', 'Inference'],
        modules: [
            { name: 'lora_adapters', type: 'folder', desc: 'Pre-trained adapters' },
            { name: 'finetune.py', type: 'file', desc: 'Main training script', size: '35KB', tags: ['PyTorch', 'Training'] },
            { name: 'inference.ipynb', type: 'file', desc: 'Testing notebook', size: '45KB', tags: ['Jupyter', 'Demo'] }
        ]
      }
    ]
  },
  {
    id: 'pm',
    title: '2. 产品经理类',
    subtitle: '提示词模板与逻辑框架',
    icon: <Layout size={20} />,
    color: 'bg-purple-500/20 text-purple-300',
    items: [
      {
        id: 'claude-skills',
        name: 'alirezarezvani/claude-skills',
        description: '87+ CLI 工具：Sprint 计划、Jira 自动化、PRD 生成。',
        fullDetail: '已集成 PM 生产力套件：包含 Sprint 计划生成、Jira 自动化工作流及 Confluence 文档模板。',
        keywords: ['Jira Automation', 'Sprint Planning', 'PRD Generation', 'Confluence Sync'],
        modules: [
            { name: 'templates', type: 'folder', desc: 'Markdown templates' },
            { name: 'jira_sync.sh', type: 'file', desc: 'Jira API integration', size: '6KB', tags: ['Bash', 'API'] },
            { name: 'sprint_planner.md', type: 'file', desc: 'Planning structure', size: '3KB', tags: ['Agile', 'Template'] },
            { name: 'prd_generator.py', type: 'file', desc: 'Requirement generator', size: '15KB', tags: ['Product', 'GenAI'] }
        ]
      },
      {
        id: 'pm-resources',
        name: 'gigikenneth/pm-resources',
        description: 'AI 策略框架、数据分析路径和认证课程清单。',
        fullDetail: '已集成 AI PM 知识库：包含产品策略框架、数据驱动决策路径及行业标准认证流程。',
        keywords: ['Product Strategy', 'Data Analytics', 'Certification Path', 'Frameworks'],
        modules: [
            { name: 'strategy_frameworks.pdf', type: 'file', desc: 'Strategic models', size: '2.4MB' },
            { name: 'data_analytics_path.md', type: 'file', desc: 'Learning path', size: '5KB' },
            { name: 'certifications.json', type: 'file', desc: 'Course list', size: '1KB' }
        ]
      }
    ]
  },
  {
    id: 'mgmt',
    title: '3. 管理层类',
    subtitle: '资源中心与人机协作框架',
    icon: <Users size={20} />,
    color: 'bg-indigo-500/20 text-indigo-300',
    items: [
      {
        id: 'eng-manager',
        name: 'ryanburgess/engineer-manager',
        description: '详尽的软技能库：团队建设、冲突解决、情绪智力。',
        fullDetail: '已集成工程管理知识库：掌握团队建设、冲突解决策略及技术领导力最佳实践。',
        keywords: ['Team Building', 'Conflict Resolution', 'Leadership', 'Hiring Process'],
        modules: [
            { name: 'one_on_one_questions.md', type: 'file', desc: 'Interview guide', size: '4KB' },
            { name: 'career_ladder.xlsx', type: 'file', desc: 'Growth framework', size: '12KB' },
            { name: 'conflict_resolution.pdf', type: 'file', desc: 'HR guide', size: '1.2MB' }
        ]
      },
      {
        id: '500-agents',
        name: 'ashishpatel26/500-AI-Agents',
        description: '500 个行业落地案例与思维导图。',
        fullDetail: '已集成行业落地案例库：访问 500+ AI Agent 商业应用场景及实施思维导图。',
        keywords: ['Industry Use Cases', 'Fintech', 'Healthcare', 'Mindmaps'],
        modules: [
            { name: 'industry_cases', type: 'folder', desc: 'Case studies by sector' },
            { name: 'mindmap_finance.png', type: 'file', desc: 'Fintech use cases', size: '3.5MB' },
            { name: 'mindmap_healthcare.png', type: 'file', desc: 'Health use cases', size: '3.2MB' }
        ]
      }
    ]
  },
  {
    id: 'mkt',
    title: '4. 市场与销售类',
    subtitle: '多模态工具与自动化营销',
    icon: <Megaphone size={20} />,
    color: 'bg-pink-500/20 text-pink-300',
    items: [
      {
        id: 'antigravity',
        name: 'sickn33/antigravity-skills',
        description: '230+ 技能：自动化运营、社交媒体发布、市场调研。',
        fullDetail: '已集成全栈营销工具：具备自动化社交媒体运营、市场调研及多渠道内容分发能力。',
        keywords: ['Marketing Automation', 'Social Media', 'Lead Gen', 'SEO Tools'],
        modules: [
            { name: 'social_automation', type: 'folder', desc: 'Bot scripts' },
            { name: 'twitter_poster.py', type: 'file', desc: 'Auto-tweet script', size: '14KB' },
            { name: 'linkedin_scraper.js', type: 'file', desc: 'Lead generation', size: '22KB' }
        ]
      },
      {
        id: 'synthesia',
        name: 'Synthesia Official',
        description: '视频演示、个性化邮件营销工具指南 (2026版)。',
        fullDetail: '已集成多模态营销助手：支持 AI 视频脚本生成、演示文稿策划及个性化邮件营销策略。',
        keywords: ['Video Generation', 'Email Marketing', 'Avatar Config', 'Scripts'],
        modules: [
            { name: 'video_scripts', type: 'folder', desc: 'Prompt templates' },
            { name: 'email_personalizer.py', type: 'file', desc: 'Cold email logic', size: '11KB' },
            { name: 'avatar_config.json', type: 'file', desc: 'Visual settings', size: '2KB' }
        ]
      }
    ]
  }
];

const AVATAR_PRESETS = [
  'https://img.freepik.com/premium-psd/3d-cartoon-character-avatar-isolated-3d-rendering_235528-554.jpg?w=200',
  'https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?w=200',
  'https://img.freepik.com/free-psd/3d-illustration-business-man-with-glasses_23-2149436194.jpg?w=200',
  'https://img.freepik.com/free-psd/3d-rendering-avatar_23-2150833560.jpg?w=200',
  'https://img.freepik.com/free-psd/3d-illustration-human-avatar-profile_23-2150671142.jpg?w=200',
  'https://img.freepik.com/free-psd/3d-illustration-person-with-glasses_23-2149436190.jpg?w=200',
];

const ConfigScreen: React.FC<ConfigScreenProps> = ({ currentConfig, onSave, onBack }) => {
  const [name, setName] = useState(currentConfig.name);
  const [avatar, setAvatar] = useState(currentConfig.avatar);
  const [previewInstruction, setPreviewInstruction] = useState(currentConfig.systemInstruction);
  
  // Documents State
  const [documents, setDocuments] = useState<string[]>(currentConfig.documents || []);
  const [knowledgeKeywords, setKnowledgeKeywords] = useState<string[]>(currentConfig.knowledgeKeywords || []);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Skill Modal State (Custom Form)
  const [isSkillModalOpen, setIsSkillModalOpen] = useState(false);
  const [skillForm, setSkillForm] = useState<SkillForm>({
    name: '',
    description: '',
    trigger: '',
    logic: '',
    requiredParams: '',
    optionalParams: '',
    constraints: '',
    example: ''
  });

  // Marketplace State
  const [selectedMarketCategory, setSelectedMarketCategory] = useState<MarketCategory | null>(null);
  const [installedSkills, setInstalledSkills] = useState<Set<string>>(new Set(currentConfig.installedSkillIds || []));
  const [installingSkillId, setInstallingSkillId] = useState<string | null>(null);

  // Source View State
  const [isSourceModalOpen, setIsSourceModalOpen] = useState(false);

  // Brain View State
  const [isBrainModalOpen, setIsBrainModalOpen] = useState(false);
  const [viewingSkill, setViewingSkill] = useState<MarketItem | null>(null);

  const handleSave = () => {
    onSave({
      name,
      avatar,
      systemInstruction: previewInstruction,
      documents,
      installedSkillIds: Array.from(installedSkills),
      knowledgeKeywords
    });
  };

  const randomizeAvatar = () => {
    const random = AVATAR_PRESETS[Math.floor(Math.random() * AVATAR_PRESETS.length)];
    setAvatar(random);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const text = await file.text();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `
        You are an expert system architect and knowledge engineer. 
        Analyze the following uploaded knowledge document: "${file.name}".
        
        Task:
        1. Extract the core skills, rules, workflows, or knowledge points.
        2. Identify 3-5 concise, high-value keywords or tags that describe the expertise in this document (e.g., "Python", "Crisis Mgmt", "Agile").
        3. Format the output as a JSON object.

        Document Content (truncated):
        ${text.slice(0, 15000)} 
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
           responseMimeType: 'application/json',
           responseSchema: {
              type: Type.OBJECT,
              properties: {
                 knowledgeSummary: { type: Type.STRING },
                 keywords: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
           }
        }
      });

      const result = JSON.parse(response.text || '{}');
      const newKnowledge = result.knowledgeSummary || `*Processed content of ${file.name}*`;
      const newKeywords = result.keywords || [];

      setPreviewInstruction(prev => {
         const header = `\n\n### Learned Knowledge [${file.name}]\n`;
         return `${prev}${header}${newKnowledge}`;
      });
      
      setDocuments(prev => [...prev, file.name]);
      setKnowledgeKeywords(prev => Array.from(new Set([...prev, ...newKeywords])));

    } catch (error) {
      console.error("Upload failed", error);
      alert("Failed to process document. Please try again.");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSkillSubmit = () => {
    const formattedSkill = `
### Defined Skill: ${skillForm.name || 'Untitled_Skill'}
- **Description**: ${skillForm.description}
- **Trigger**: ${skillForm.trigger}
- **Core Logic**:
${skillForm.logic}
- **Parameters**:
  * Required: ${skillForm.requiredParams}
  * Optional: ${skillForm.optionalParams}
- **Constraints**: ${skillForm.constraints}
- **Few-Shot Example**: ${skillForm.example}
`;
    
    setPreviewInstruction(prev => prev.trim() + "\n" + formattedSkill);
    setIsSkillModalOpen(false);
    // Reset form
    setSkillForm({
        name: '', description: '', trigger: '', logic: '', 
        requiredParams: '', optionalParams: '', constraints: '', example: ''
    });
  };

  const handleMarketInstall = (item: MarketItem) => {
      setInstallingSkillId(item.id);
      
      // Simulate network delay
      setTimeout(() => {
          setPreviewInstruction(prev => {
              const installBlock = `\n\n### Installed Module: ${item.name}\n${item.fullDetail}`;
              return prev + installBlock;
          });
          setInstalledSkills(prev => new Set(prev).add(item.id));
          setInstallingSkillId(null);
      }, 1500);
  };

  // Helper to find installed skill objects
  const getInstalledSkillObjects = () => {
    const allItems = MARKET_DATA.flatMap(cat => cat.items);
    return allItems.filter(item => installedSkills.has(item.id));
  };

  return (
    <div className="w-full h-full bg-black/60 backdrop-blur-3xl flex flex-col relative z-50 animate-fade-in font-sans">
      {/* Header */}
      <div className="px-6 py-4 flex items-center justify-between z-10 shrink-0 border-b border-white/5 bg-white/5">
        <button 
          onClick={onBack}
          className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center shadow-sm text-white active:scale-90 transition-transform border border-white/10"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-lg font-bold text-white tracking-wide">Bot Configuration</h1>
        <div className="flex gap-2">
            <button 
              onClick={() => setIsSourceModalOpen(true)}
              className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center shadow-sm text-blue-400 active:scale-90 transition-transform border border-white/10"
              title="View Source"
            >
              <FileCode size={20} />
            </button>
            <button 
              onClick={() => setIsBrainModalOpen(true)}
              className="w-10 h-10 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center shadow-sm text-white active:scale-90 transition-transform relative border border-white/20"
              title="MyBot Brain"
            >
              <Brain size={20} />
              {installedSkills.size > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[9px] flex items-center justify-center font-bold border border-black">
                    {installedSkills.size}
                </span>
              )}
            </button>
        </div>
      </div>

      {/* Bento Grid Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar">
        <div className="p-4 grid grid-cols-2 gap-3 pb-32">
          
          {/* 1. Identity Card (Full Width) */}
          <div className="col-span-2 bg-white/5 rounded-[32px] p-5 shadow-xl border border-white/10 flex items-center gap-5 relative overflow-hidden backdrop-blur-md">
             <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
             
             <div className="relative group shrink-0">
                <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-white/20 shadow-lg ring-1 ring-white/10">
                    <img src={avatar} alt="Bot Avatar" className="w-full h-full object-cover bg-black/40" />
                </div>
                <button 
                    onClick={randomizeAvatar}
                    className="absolute bottom-0 right-0 bg-white/20 text-white p-1.5 rounded-full shadow-lg backdrop-blur-md hover:bg-white/30 active:scale-90 transition-all border border-white/20"
                >
                    <Shuffle size={12} />
                </button>
             </div>
             
             <div className="flex-1 z-10">
                <label className="text-[10px] font-bold text-white/40 uppercase tracking-wider mb-1 block">Bot Identity</label>
                <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-transparent text-2xl font-bold text-white focus:outline-none placeholder-white/20 border-b border-transparent focus:border-white/20 transition-colors"
                    placeholder="Name"
                />
             </div>
          </div>

          {/* 2. Upload Knowledge (Left Col) */}
          <div className="col-span-1 bg-indigo-500/10 border-2 border-dashed border-indigo-400/30 rounded-[28px] p-4 flex flex-col relative group transition-colors hover:bg-indigo-500/20 hover:border-indigo-400/50 h-40 overflow-hidden">
             <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept=".md,.txt,.json,.csv"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                disabled={isUploading}
             />
             {isUploading ? (
                <div className="flex flex-col items-center justify-center h-full animate-pulse">
                    <Loader size={24} className="text-indigo-400 animate-spin mb-1" />
                    <span className="text-[10px] font-bold text-indigo-300">Analyzing...</span>
                </div>
             ) : knowledgeKeywords.length > 0 ? (
                <div className="flex flex-col h-full w-full relative z-10 pointer-events-none">
                     <div className="flex justify-between items-start mb-2 pointer-events-none">
                        <h3 className="text-xs font-bold text-indigo-300 flex items-center gap-1">
                            <Zap size={10} className="text-indigo-400"/> Learned
                        </h3>
                        <div className="bg-white/10 p-1.5 rounded-full"><Upload size={10} className="text-indigo-300"/></div>
                     </div>
                     <div className="flex-1 flex flex-wrap content-start gap-1.5 overflow-hidden">
                        {knowledgeKeywords.slice(0, 5).map((k, i) => (
                           <span key={i} className="text-[8px] bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 px-1.5 py-0.5 rounded-md shadow-sm font-semibold">
                               {k}
                           </span>
                        ))}
                        {knowledgeKeywords.length > 5 && (
                            <span className="text-[8px] bg-indigo-500/30 text-indigo-200 px-1.5 py-0.5 rounded-md font-bold">
                                +{knowledgeKeywords.length - 5}
                            </span>
                        )}
                     </div>
                     <div className="mt-auto text-[8px] text-indigo-400/80 text-center w-full">
                         {documents.length} docs active
                     </div>
                </div>
             ) : (
                <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="w-10 h-10 bg-white/10 rounded-full shadow-sm flex items-center justify-center text-indigo-300 mb-2 group-hover:scale-110 transition-transform border border-white/5">
                        <Upload size={20} />
                    </div>
                    <h3 className="text-xs font-bold text-indigo-200 leading-tight">Upload Knowledge</h3>
                    <p className="text-[9px] text-indigo-400 mt-1">.md, .txt support</p>
                </div>
             )}
          </div>

          {/* 3. Set Bot / Skill Builder (Right Col) */}
          <div 
             onClick={() => setIsSkillModalOpen(true)}
             className="col-span-1 bg-black/40 rounded-[28px] p-4 flex flex-col justify-between relative overflow-hidden h-40 shadow-lg border border-white/10 group cursor-pointer hover:bg-black/50 transition-colors"
          >
             <div className="flex items-center gap-2 z-10">
                 <div className="p-2 bg-white/10 rounded-lg text-green-400 group-hover:bg-white/15 transition-colors border border-white/5">
                    <Settings size={18} />
                 </div>
                 <span className="text-[10px] font-bold text-white/40 uppercase tracking-wider">Skills</span>
             </div>

             <div className="z-10 mt-2">
                 <h3 className="text-xl font-bold text-white leading-tight">Define<br/>New Skill</h3>
                 <p className="text-[9px] text-gray-400 mt-1">Triggers & Logic</p>
             </div>

             <div className="absolute bottom-3 right-3 bg-green-500 text-white p-2 rounded-full shadow-lg group-hover:scale-110 transition-transform z-20 shadow-green-900/30">
                 <Plus size={16} />
             </div>
             
             <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/10 rounded-full blur-2xl -mr-8 -mt-8 pointer-events-none"></div>
             <div className="absolute bottom-0 left-0 w-16 h-16 bg-blue-500/10 rounded-full blur-xl -ml-5 -mb-5 pointer-events-none"></div>
          </div>

          {/* 4. Skill Acquisition Marketplace */}
          <div className="col-span-2 bg-white/5 rounded-[32px] p-1 shadow-xl border border-white/10 h-[420px] flex flex-col backdrop-blur-md">
             <div className="px-5 py-4 border-b border-white/5 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-white text-sm">Skill Store</h3>
                    <p className="text-[10px] text-white/40">Install open-source agent capabilities</p>
                </div>
                <div className="bg-blue-500/20 text-blue-300 border border-blue-500/30 px-2 py-1 rounded-md text-[10px] font-bold flex items-center gap-1">
                    <Download size={10} />
                    Store
                </div>
             </div>
             
             <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
                {MARKET_DATA.map((category) => (
                    <div 
                        key={category.id} 
                        onClick={() => setSelectedMarketCategory(category)}
                        className="group bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/20 rounded-2xl p-4 cursor-pointer transition-all shadow-sm flex items-center gap-4"
                    >
                        <div className={`w-12 h-12 rounded-xl ${category.color} flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform backdrop-blur-sm border border-white/10`}>
                            {category.icon}
                        </div>
                        <div className="flex-1">
                            <h4 className="font-bold text-white text-sm mb-0.5">{category.title}</h4>
                            <p className="text-[11px] text-white/50 leading-tight">{category.subtitle}</p>
                        </div>
                        <div className="bg-white/10 p-1.5 rounded-full text-white/30 group-hover:text-white transition-colors">
                            <ChevronRight size={16} />
                        </div>
                    </div>
                ))}
                
                {/* Visual Filler */}
                <div className="border-2 border-dashed border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center text-center opacity-30">
                    <Package size={24} className="text-white mb-1" />
                    <span className="text-[10px] font-bold text-white">More coming soon...</span>
                </div>
             </div>
          </div>

        </div>
      </div>

      {/* Footer Floating Action */}
      <div className="absolute bottom-6 left-0 right-0 px-6 z-50 pointer-events-none">
         <button 
            onClick={handleSave}
            className="w-full bg-white text-black font-bold h-14 rounded-2xl shadow-2xl flex items-center justify-center gap-3 pointer-events-auto active:scale-95 transition-transform hover:bg-gray-200"
         >
            <Save size={20} />
            <span>Apply Configuration</span>
         </button>
      </div>

      {/* Manual Skill Definition Modal */}
      {isSkillModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
           <div className="bg-[#1c1c1e] w-full max-w-md rounded-2xl shadow-2xl flex flex-col h-[85vh] animate-scale-in overflow-hidden border border-white/10">
              {/* Modal Header */}
              <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
                 <div>
                    <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
                       <PenTool size={16} className="text-blue-400"/>
                       Define Skill
                    </h2>
                    <p className="text-[10px] text-gray-400">Teach your bot new capabilities</p>
                 </div>
                 <button onClick={() => setIsSkillModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white">
                    <X size={20} />
                 </button>
              </div>
              
              {/* Form Content */}
              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                 {/* Skill Name */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Skill Name <span className="text-gray-600 font-normal">(Action_Object)</span></label>
                    <input 
                      type="text" 
                      placeholder="e.g. search_policy"
                      value={skillForm.name}
                      onChange={e => setSkillForm({...skillForm, name: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 {/* Description */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Description</label>
                    <input 
                      type="text" 
                      placeholder="What does this skill do?"
                      value={skillForm.description}
                      onChange={e => setSkillForm({...skillForm, description: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 {/* Trigger */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Trigger Scene</label>
                    <input 
                      type="text" 
                      placeholder="When user asks..."
                      value={skillForm.trigger}
                      onChange={e => setSkillForm({...skillForm, trigger: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 {/* Core Logic */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Logic Steps</label>
                    <textarea 
                      placeholder="1. Extract keywords; 2. Query DB; 3. Format output."
                      value={skillForm.logic}
                      onChange={e => setSkillForm({...skillForm, logic: e.target.value})}
                      className="w-full h-24 bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors resize-none placeholder-gray-600"
                    />
                 </div>
                 {/* Parameters Group */}
                 <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="block text-xs font-bold text-gray-400 mb-1">Required Params</label>
                        <input 
                          type="text" 
                          placeholder="e.g. city: string"
                          value={skillForm.requiredParams}
                          onChange={e => setSkillForm({...skillForm, requiredParams: e.target.value})}
                          className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 placeholder-gray-600"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-400 mb-1">Optional Params</label>
                        <input 
                          type="text" 
                          placeholder="e.g. limit: 5"
                          value={skillForm.optionalParams}
                          onChange={e => setSkillForm({...skillForm, optionalParams: e.target.value})}
                          className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 placeholder-gray-600"
                        />
                    </div>
                 </div>
                 {/* Constraints */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Constraints</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Do not reveal private data..."
                      value={skillForm.constraints}
                      onChange={e => setSkillForm({...skillForm, constraints: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 {/* Example */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Few-Shot Example</label>
                    <div className="bg-black/20 border border-white/10 rounded-lg p-2">
                        <input 
                          type="text" 
                          placeholder='e.g. "Check weather" -> {"loc": "Beijing"}'
                          value={skillForm.example}
                          onChange={e => setSkillForm({...skillForm, example: e.target.value})}
                          className="w-full bg-transparent text-sm focus:outline-none font-mono text-gray-300 placeholder-gray-600"
                        />
                    </div>
                 </div>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-white/10 bg-white/5">
                 <button 
                    onClick={handleSkillSubmit} 
                    className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-blue-500 active:scale-95 transition-all flex items-center justify-center gap-2"
                 >
                    <Check size={18} />
                    <span>Confirm & Add Skill</span>
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* Marketplace Category Dialog */}
      {selectedMarketCategory && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
           <div className="bg-[#1c1c1e] w-full max-w-sm rounded-3xl shadow-2xl flex flex-col max-h-[70vh] animate-scale-in overflow-hidden border border-white/10">
               {/* Header */}
               <div className={`p-5 ${selectedMarketCategory.color.split(' ')[0]} bg-opacity-20 flex justify-between items-start border-b border-white/5`}>
                   <div className="flex gap-3">
                       <div className="bg-white/10 p-2 rounded-xl backdrop-blur-sm border border-white/10 text-white">
                           {selectedMarketCategory.icon}
                       </div>
                       <div>
                           <h2 className={`font-bold text-lg text-white`}>
                               {selectedMarketCategory.title}
                           </h2>
                           <p className="text-xs opacity-70 mt-1 text-gray-300">{selectedMarketCategory.subtitle}</p>
                       </div>
                   </div>
                   <button 
                    onClick={() => setSelectedMarketCategory(null)}
                    className="bg-black/20 hover:bg-black/40 p-1.5 rounded-full transition-colors text-white"
                   >
                       <X size={18} />
                   </button>
               </div>

               {/* List */}
               <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#1c1c1e]">
                   {selectedMarketCategory.items.map(item => {
                       const isInstalled = installedSkills.has(item.id);
                       const isInstalling = installingSkillId === item.id;

                       return (
                           <div key={item.id} className="border border-white/10 rounded-2xl p-4 hover:bg-white/5 transition-all bg-white/[0.02]">
                               <div className="flex justify-between items-start mb-2">
                                   <h3 className="font-bold text-sm text-white">{item.name}</h3>
                                   {isInstalled ? (
                                       <span className="text-[10px] font-bold text-green-400 bg-green-500/20 px-2 py-0.5 rounded-full flex items-center gap-1 border border-green-500/30">
                                           <Check size={10} /> Installed
                                       </span>
                                   ) : (
                                       <button 
                                        onClick={() => handleMarketInstall(item)}
                                        disabled={isInstalling}
                                        className="text-[10px] font-bold bg-white text-black px-3 py-1.5 rounded-full active:scale-95 transition-transform disabled:opacity-50 flex items-center gap-1 hover:bg-gray-200"
                                       >
                                           {isInstalling ? <Loader size={10} className="animate-spin"/> : <Download size={10} />}
                                           {isInstalling ? 'Installing...' : 'Get'}
                                       </button>
                                   )}
                               </div>
                               <p className="text-xs text-gray-400 leading-relaxed">
                                   {item.description}
                               </p>
                           </div>
                       )
                   })}
               </div>
           </div>
        </div>
      )}

      {/* Source Code Inspector Modal */}
      {isSourceModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-[#1c1c1e] w-full max-w-2xl rounded-2xl shadow-2xl flex flex-col h-[80vh] animate-scale-in overflow-hidden border border-white/10">
                <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
                    <div>
                    <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
                        <FileCode size={16} className="text-blue-400"/>
                        System Instructions
                    </h2>
                    <p className="text-[10px] text-gray-400">Current active brain content (Editable)</p>
                    </div>
                    <button onClick={() => setIsSourceModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white">
                    <X size={20} />
                    </button>
                </div>
                <div className="flex-1 p-0 relative">
                    <textarea 
                    value={previewInstruction}
                    onChange={(e) => setPreviewInstruction(e.target.value)}
                    className="w-full h-full p-5 font-mono text-xs text-green-400 bg-black/40 resize-none focus:outline-none leading-relaxed"
                    spellCheck={false}
                    />
                </div>
                <div className="p-3 border-t border-white/10 bg-white/5 flex justify-end">
                    <button 
                        onClick={() => setIsSourceModalOpen(false)}
                        className="bg-white text-black px-4 py-2 rounded-lg text-xs font-bold hover:bg-gray-200"
                    >
                        Close & Keep Changes
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* MyBot Brain (Skills Inspector) Modal */}
      {isBrainModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-[#1c1c1e] w-full max-w-2xl rounded-2xl shadow-2xl flex flex-col h-[70vh] animate-scale-in overflow-hidden border border-white/10">
                
                {/* Brain Modal Header */}
                <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5 shrink-0">
                    <div className="flex items-center gap-2">
                        {viewingSkill ? (
                             <button 
                                onClick={() => setViewingSkill(null)}
                                className="p-1 hover:bg-white/10 rounded-lg mr-1 transition-colors text-white"
                             >
                                <ChevronLeft size={20} />
                             </button>
                        ) : (
                             <Brain size={20} className="text-white" />
                        )}
                        <div>
                            <h2 className="text-sm font-bold text-white uppercase tracking-wide">
                                {viewingSkill ? viewingSkill.name : 'MyBot Brain'}
                            </h2>
                            <p className="text-[10px] text-gray-400">
                                {viewingSkill ? 'Inspect installed modules' : 'Manage installed skills'}
                            </p>
                        </div>
                    </div>
                    <button onClick={() => { setIsBrainModalOpen(false); setViewingSkill(null); }} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white">
                        <X size={20} />
                    </button>
                </div>
                
                {/* Brain Content */}
                <div className="flex-1 overflow-y-auto bg-black/20 p-5">
                    {viewingSkill ? (
                        /* Detail View: Modules/Files */
                        <div className="space-y-4">
                            <div className="bg-white/5 p-4 rounded-xl border border-white/10 shadow-sm">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Skill Description</h3>
                                <p className="text-sm text-gray-300 leading-relaxed">{viewingSkill.description}</p>
                            </div>

                            {viewingSkill.keywords && (
                                <div className="bg-white/5 p-4 rounded-xl border border-white/10 shadow-sm">
                                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                                       <Zap size={14} className="text-orange-500" /> Capabilities
                                    </h3>
                                    <div className="flex flex-wrap gap-2">
                                        {viewingSkill.keywords.map((kw, i) => (
                                            <span key={i} className="px-3 py-1 bg-blue-500/20 text-blue-300 text-xs font-semibold rounded-full border border-blue-500/30">
                                                {kw}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <div>
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 ml-1">Modules & Files</h3>
                                <div className="bg-white/5 rounded-xl border border-white/10 shadow-sm overflow-hidden">
                                    {viewingSkill.modules.map((mod, idx) => (
                                        <div key={idx} className="flex items-center justify-between p-3 border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors cursor-default">
                                            <div className="flex items-center gap-3">
                                                <div className={`p-2 rounded-lg ${mod.type === 'folder' ? 'bg-blue-500/20 text-blue-400' : 'bg-white/10 text-gray-400'}`}>
                                                    {mod.type === 'folder' ? <Folder size={16} /> : <FileIcon size={16} />}
                                                </div>
                                                <div>
                                                    <div className="flex items-center gap-2">
                                                        <span className="font-mono text-sm text-white font-medium">{mod.name}</span>
                                                        {mod.tags && mod.tags.map((t, ti) => (
                                                            <span key={ti} className="text-[9px] px-1.5 py-0.5 bg-white/10 text-gray-400 rounded-md font-medium">{t}</span>
                                                        ))}
                                                    </div>
                                                    <div className="text-[10px] text-gray-500">{mod.desc}</div>
                                                </div>
                                            </div>
                                            {mod.size && <span className="text-[10px] text-gray-600 font-mono">{mod.size}</span>}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ) : (
                        /* List View: Installed Cards */
                        <div className="grid grid-cols-2 gap-3">
                             {getInstalledSkillObjects().length === 0 ? (
                                 <div className="col-span-2 flex flex-col items-center justify-center py-10 opacity-50">
                                     <Brain size={48} className="text-gray-600 mb-2" strokeWidth={1} />
                                     <p className="text-sm font-bold text-gray-500">No skills installed yet</p>
                                     <p className="text-xs text-gray-600">Visit the store to add capabilities</p>
                                 </div>
                             ) : (
                                getInstalledSkillObjects().map(skill => (
                                    <div 
                                        key={skill.id} 
                                        onClick={() => setViewingSkill(skill)}
                                        className="bg-white/5 p-4 rounded-2xl border border-white/10 shadow-sm hover:shadow-md hover:border-blue-500/30 transition-all cursor-pointer group"
                                    >
                                        <div className="flex justify-between items-start mb-3">
                                            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-gray-400 group-hover:bg-blue-500/20 group-hover:text-blue-400 transition-colors">
                                                <Package size={20} />
                                            </div>
                                            <div className="bg-green-500/20 text-green-400 text-[9px] font-bold px-1.5 py-0.5 rounded border border-green-500/30">
                                                ACTIVE
                                            </div>
                                        </div>
                                        <h3 className="font-bold text-sm text-white mb-1 leading-tight">{skill.name}</h3>
                                        <p className="text-[10px] text-gray-400 line-clamp-2 leading-relaxed">{skill.description}</p>
                                        <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between">
                                            <span className="text-[9px] font-mono text-gray-500">{skill.modules.length} modules</span>
                                            <ChevronRight size={14} className="text-gray-600 group-hover:text-blue-400" />
                                        </div>
                                    </div>
                                ))
                             )}
                        </div>
                    )}
                </div>
            </div>
        </div>
      )}

    </div>
  );
};

export default ConfigScreen;
