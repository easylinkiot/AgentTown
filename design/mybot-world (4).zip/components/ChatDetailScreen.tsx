
import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, MoreHorizontal, Smile, Plus, Wifi, Send, Sparkles, X, Clock, User, Lightbulb, ArrowUp, Briefcase, MessageSquare, Check, PlusCircle } from 'lucide-react';
import { ChatMessage, TaskItem } from '../types';
import { GoogleGenAI, Type } from "@google/genai";

interface ChatDetailScreenProps {
  chat: ChatMessage;
  onBack: () => void;
  onAddTask: (task: TaskItem) => void;
  systemInstruction?: string;
  variant?: 'default' | 'embedded';
}

interface Message {
  id: string;
  senderName?: string;
  senderAvatar: string;
  content: string; 
  type: 'text' | 'voice' | 'image' | 'reply' | 'summary';
  isMe: boolean;
  time?: string;
  voiceDuration?: string;
  replyContext?: string;
}

interface AiContextState {
  mode: 'idle' | 'loading' | 'reply' | 'task' | 'brainstorm' | 'custom';
  data: any;
}

const POWERHOO_MESSAGES: Message[] = [
  {
    id: '1',
    senderName: 'Cathy (厨房业务)',
    senderAvatar: 'https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?w=200',
    content: '这个问题可以先用这个 UI 的配色，目前的颜色对比度不够。',
    type: 'reply',
    replyContext: '李震铭: 开关状态看起来不是很明显',
    isMe: false,
    time: '昨天 10:40 PM'
  },
  {
    id: '2',
    senderName: 'Evan Huang',
    senderAvatar: 'https://img.freepik.com/free-psd/3d-illustration-human-avatar-profile_23-2150671122.jpg?w=200',
    content: '',
    type: 'voice',
    voiceDuration: '4"',
    isMe: false,
    time: '昨天 10:45 PM'
  },
  {
    id: '3',
    senderName: 'Sven',
    senderAvatar: 'https://img.freepik.com/free-psd/3d-illustration-business-man-with-glasses_23-2149436194.jpg?w=200',
    content: '👌，那我更新成这一版的 UI。话说 AI 界面是否该追求极简？',
    type: 'text',
    isMe: false,
  },
  {
    id: '4',
    senderName: '子非鱼',
    senderAvatar: 'https://img.freepik.com/free-psd/3d-illustration-person-with-glasses_23-2149436190.jpg?w=200',
    content: '@Evan Huang 周工邮寄订单先取消，目前看 Powerhoo100 低电量 OTA 无法更新。硬件初创如何处理这种批次故障？',
    type: 'text',
    isMe: false,
    time: '3:30 AM'
  },
  {
    id: '5',
    senderName: '常城',
    senderAvatar: 'https://img.freepik.com/free-psd/3d-rendering-avatar_23-2150833560.jpg?w=200',
    content: '已经取消了。',
    type: 'text',
    isMe: false,
  },
  {
    id: '6',
    senderName: '子非鱼',
    senderAvatar: 'https://img.freepik.com/free-psd/3d-illustration-person-with-glasses_23-2149436190.jpg?w=200',
    content: '👌',
    type: 'text',
    isMe: false,
  },
];

const ChatDetailScreen: React.FC<ChatDetailScreenProps> = ({ chat, onBack, onAddTask, systemInstruction, variant = 'default' }) => {
  const isEmbedded = variant === 'embedded';

  const bubbleTextClass = isEmbedded ? "text-[12px] leading-snug" : "text-[15px] leading-snug";
  const bubblePaddingClass = isEmbedded ? "px-3 py-2 min-h-[32px]" : "px-4 py-2.5 min-h-[42px]";
  const avatarClass = isEmbedded ? "w-8 h-8 rounded-lg" : "w-10 h-10 rounded-[14px]";
  const senderNameClass = isEmbedded ? "text-[9px]" : "text-[11px]";
  const timeClass = isEmbedded ? "text-[9px]" : "text-[10px]";
  const headerTitleClass = isEmbedded ? "text-[13px]" : "text-[17px]";
  const inputClass = isEmbedded ? "text-[12px]" : "text-[15px]";
  const iconScale = isEmbedded ? 0.8 : 1;

  const [messages, setMessages] = useState<Message[]>(() => {
    if (chat.id === 'group_14') return POWERHOO_MESSAGES;
    return [{
      id: 'init',
      senderName: chat.name,
      senderAvatar: chat.avatar,
      content: '你好！我是你的 AI 创业导师。让我们聊聊你的项目吧。',
      type: 'text',
      isMe: false,
      time: '刚刚'
    }];
  });
  
  const [inputValue, setInputValue] = useState('');
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState('');
  const [addedTasks, setAddedTasks] = useState<Set<number>>(new Set());
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [aiContext, setAiContext] = useState<AiContextState>({ mode: 'idle', data: null });

  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isAiThinking]);

  useEffect(() => {
    setAiContext({ mode: 'idle', data: null });
    setCustomPrompt('');
    setAddedTasks(new Set());
  }, [activeMessageId]);

  // AI interaction logic (kept same as previous versions)
  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userText = inputValue;
    setInputValue('');

    const newMessage: Message = {
      id: Date.now().toString(),
      senderAvatar: 'https://img.freepik.com/premium-psd/3d-cartoon-character-avatar-isolated-3d-rendering_235528-554.jpg?w=200', 
      content: userText,
      type: 'text',
      isMe: true,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMessage]);
    setIsAiThinking(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const history = messages.slice(-10).map(m => ({
        role: m.isMe ? 'user' : 'model',
        parts: [{ text: `${m.senderName ? m.senderName + ': ' : ''}${m.content}` }]
      }));
      const finalInstruction = `
        你是一名顶尖的 AI 创业导师，目前在名为“${chat.name}”的群聊中。
        回复规则：1. 使用中文。2. 契合AI创业语境。3. 简短有力(50字内)。
      `;
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [ ...history, { role: 'user', parts: [{ text: userText }] } ],
        config: { systemInstruction: finalInstruction }
      });
      const aiText = response.text || '...';
      const aiReply: Message = {
        id: (Date.now() + 1).toString(),
        senderName: chat.name === 'MyBot' ? chat.name : 'Sven (导师)',
        senderAvatar: chat.avatar,
        content: aiText,
        type: 'text',
        isMe: false,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, aiReply]);
    } catch (error) { console.error("AI Error", error); } finally { setIsAiThinking(false); }
  };

  const handleReplyClick = async (msg: Message) => {
    setAiContext({ mode: 'loading', data: null });
    // Simulate AI for brevity in this snippet
    setTimeout(() => {
        setAiContext({ mode: 'reply', data: ["这个建议不错，值得一试。", "成本控制是关键，怎么落地？", "我们这周开个会讨论下？"] });
    }, 1000);
  };

  // ... other AI handlers similar to before ...

  const handleCustomAiPrompt = async (msg: Message, promptText: string) => {
    setAiContext({ mode: 'custom', data: "AI 导师正在思考: " + promptText });
  };
  const handleSuggestionSelect = (text: string) => { setInputValue(text); setActiveMessageId(null); };

  return (
    <div className={`flex flex-col h-full font-sans relative z-50 animate-fade-in ${isEmbedded ? 'bg-black/80' : 'bg-black/90'}`}>
      
      {/* Glass Header */}
      <div className="absolute top-0 left-0 right-0 z-[60] bg-[#1c1c1e]/70 backdrop-blur-xl border-b border-white/10 flex items-center justify-between px-4 py-3 pb-4">
          <div className="flex items-center gap-3">
             <button onClick={onBack} className="flex items-center text-blue-500 hover:text-blue-400 active:opacity-60 transition-colors">
                <ChevronLeft size={26} strokeWidth={2} />
             </button>
             {isEmbedded && (
                 <div className="w-8 h-8 rounded-full overflow-hidden border border-white/20">
                    <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover"/>
                 </div>
             )}
             <div className="flex flex-col">
                <h1 className={`${headerTitleClass} font-semibold text-white`}>
                    {chat.name}
                </h1>
                {!isEmbedded && <span className="text-[10px] text-gray-400">24 people active</span>}
             </div>
          </div>
          <button className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80">
            <MoreHorizontal size={18} />
          </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar relative z-10 pt-20 pb-24">
        {messages.map((msg, index) => {
          const showTime = msg.time && (index === 0 || messages[index - 1].time !== msg.time);
          return (
            <React.Fragment key={msg.id}>
              {showTime && (
                <div className="flex justify-center my-4">
                  <span className={`${timeClass} text-white/40 font-medium`}>{msg.time}</span>
                </div>
              )}
              
              <div className={`flex flex-col gap-1 ${msg.isMe ? 'items-end' : 'items-start'}`}>
                <div className={`flex gap-3 ${msg.isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                  {!msg.isMe && <img src={msg.senderAvatar} alt={msg.senderName} className={`${avatarClass} object-cover bg-gray-800 shadow-sm`} />}
                  <div className={`flex flex-col max-w-[80%] ${msg.isMe ? 'items-end' : 'items-start'}`}>
                    {!msg.isMe && msg.senderName && (
                      <span className={`${senderNameClass} text-gray-500 mb-1 ml-1`}>{msg.senderName}</span>
                    )}
                    <div className="relative group transition-all duration-300">
                      <div 
                        onClick={(e) => { e.stopPropagation(); setActiveMessageId(activeMessageId === msg.id ? null : msg.id); }}
                        className={`
                          cursor-pointer relative ${bubblePaddingClass} shadow-sm break-words ${bubbleTextClass}
                          ${msg.isMe 
                            ? 'bg-blue-600 text-white rounded-[20px] rounded-br-[4px]' 
                            : 'bg-[#2c2c2e] text-gray-100 rounded-[20px] rounded-bl-[4px] border border-white/5'}
                          ${msg.type === 'voice' ? 'min-w-[80px] flex items-center' : ''}
                          ${activeMessageId === msg.id ? 'ring-2 ring-blue-500/50 scale-[1.02]' : ''}
                        `}
                      >
                        {msg.type === 'text' && <span>{msg.content}</span>}
                        {msg.type === 'reply' && (
                          <div className="flex flex-col">
                            <span>{msg.content}</span>
                            <div className="mt-1.5 pt-1.5 border-t border-white/10 relative opacity-70">
                              <div className={`${timeClass} text-white/80 italic`}>{msg.replyContext}</div>
                            </div>
                          </div>
                        )}
                        {msg.type === 'voice' && (
                          <div className="flex items-center gap-2">
                            <Wifi className="transform rotate-90 text-white/80" size={14 * iconScale} />
                            <span className="font-medium">{msg.voiceDuration}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Context Menu - Glass Style */}
                {activeMessageId === msg.id && (
                    <div className={`w-full max-w-[280px] ${msg.isMe ? 'mr-12' : 'ml-12'} animate-fade-in-up origin-top z-10 mt-2`}>
                        <div className="bg-[#1c1c1e]/90 backdrop-blur-xl rounded-[20px] p-3 flex flex-col gap-3 border border-white/20 shadow-2xl">
                            <div className="flex items-center gap-2 px-3 py-2 bg-black/40 rounded-xl border border-white/10 focus-within:ring-1 focus-within:ring-blue-500 transition-all">
                                <Sparkles size={14} className="text-blue-400 shrink-0" />
                                <input 
                                    className="flex-1 bg-transparent text-[12px] outline-none text-white placeholder-gray-500 min-w-0"
                                    placeholder="Ask AI..."
                                    value={customPrompt}
                                    onChange={(e) => setCustomPrompt(e.target.value)}
                                />
                                <button className={`p-1 rounded-full ${customPrompt.trim() ? 'bg-blue-500 text-white' : 'bg-white/10 text-gray-500'}`}>
                                    <ArrowUp size={12} />
                                </button>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={() => handleReplyClick(msg)} className="flex-1 text-[11px] font-bold text-white bg-white/10 hover:bg-white/20 py-2 rounded-lg transition-colors">Reply</button>
                                <button className="flex-1 text-[11px] font-bold text-white bg-white/10 hover:bg-white/20 py-2 rounded-lg transition-colors">Task</button>
                            </div>
                             {aiContext.mode === 'reply' && aiContext.data && (
                                <div className="space-y-1">
                                    {(aiContext.data as string[]).map((suggestion, idx) => (
                                        <button key={idx} onClick={() => handleSuggestionSelect(suggestion)} className="w-full text-left text-[11px] text-gray-300 bg-white/5 hover:bg-white/10 p-2 rounded-lg border border-white/5 transition-colors">{suggestion}</button>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                )}
              </div>
            </React.Fragment>
          );
        })}
      </div>

      {/* Input Area - Floating Capsule */}
      <div className={`absolute bottom-0 left-0 right-0 bg-[#1c1c1e]/80 backdrop-blur-xl border-t border-white/10 p-2 flex items-end gap-2 z-[60] ${isEmbedded ? 'pb-3' : 'pb-6'}`}>
        <button className="p-2.5 rounded-full bg-gray-800 text-gray-400 hover:text-white transition-colors">
            <Plus size={20} />
        </button>
        <div className="flex-1 bg-[#2c2c2e] rounded-[24px] min-h-[44px] px-4 py-2.5 flex items-center border border-white/10 focus-within:border-white/30 transition-colors">
           <input 
            type="text" 
            className={`w-full bg-transparent outline-none ${inputClass} text-white placeholder-gray-500`} 
            placeholder="iMessage"
            value={inputValue} 
            onChange={(e) => setInputValue(e.target.value)} 
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()} 
           />
           <button className="text-gray-400 hover:text-white ml-2">
               <Smile size={20} />
           </button>
        </div>
        {inputValue.trim() ? (
             <button onClick={handleSendMessage} className="p-2.5 bg-blue-500 text-white rounded-full shadow-lg shadow-blue-500/30 animate-scale-in">
                <ArrowUp size={20} strokeWidth={3} />
             </button>
        ) : (
            <button className="p-2.5 rounded-full bg-gray-800 text-gray-400">
                <Wifi className="transform rotate-90" size={20} />
            </button>
        )}
      </div>
    </div>
  );
};

export default ChatDetailScreen;
    