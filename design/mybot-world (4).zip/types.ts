
// Import React to fix "Cannot find namespace 'React'" error when using React.ReactNode
import React from 'react';

export interface ChatMessage {
  id: string;
  name: string;
  avatar: string;
  message: string;
  time: string;
  unreadCount?: number;
  isVoiceCall?: boolean;
  isSystem?: boolean;
  highlight?: boolean;
}

export interface TownStat {
  label: string;
  value: string;
  icon?: string;
  color?: string;
}

export interface FloatingMenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  position: { top?: string; left?: string; right?: string; bottom?: string };
}

export interface BotConfig {
  name: string;
  avatar: string;
  systemInstruction: string;
  documents: string[]; // Track names of ingested documents
  installedSkillIds: string[]; // Track IDs of installed marketplace skills
  knowledgeKeywords: string[]; // Track extracted key experience/knowledge tags
}

export interface TaskItem {
  id?: string;
  title: string;
  assignee: string;
  priority: 'High' | 'Medium' | 'Low';
  status: 'Pending' | 'In Progress' | 'Done';
}

export interface NPCConfig {
  name: string;
  role: string;
  avatar: string;
  greeting: string;
  skills: string;
  bio: string;
  company: string;
}

export interface LotData {
  id: string;
  x: number;
  y: number;
  label: string;
  visualType: 'red-cottage' | 'blue-villa' | 'dark-cabin' | 'brown-manor' | 'market-stall';
  isMarket?: boolean;
  npc: NPCConfig;
}

// --- Generative UI Types ---

export type MiniAppType = 'news_feed' | 'flashcard' | 'price_tracker' | 'dashboard';

export interface MiniApp {
  id: string;
  title: string;
  icon: string; // Lucide icon name or emoji
  color: string;
  type: MiniAppType;
  description: string;
  content: any; // Dynamic payload based on type
  createdAt: string;
}
