
import React, { useState, useRef, useEffect } from 'react';
import TownSection from './components/TownSection';
import ChatSection from './components/ChatSection';
import ConfigScreen from './components/ConfigScreen';
import ChatDetailScreen from './components/ChatDetailScreen';
import TownMapScreen from './components/TownMapScreen';
import LivingRoomScreen from './components/LivingRoomScreen';
import NeighborProfileModal from './components/NeighborProfileModal';
import MiniAppCreator from './components/MiniAppCreator';
import MiniAppWidget from './components/MiniAppWidget';
import MiniAppRenderer from './components/MiniAppRenderer';
import AddBotModal from './components/AddBotModal'; 
import { BotConfig, TaskItem, ChatMessage, LotData, MiniApp } from './types';
import { CHAT_DATA } from './constants';
import { Plus, Grid, Mic, AudioLines, Image as ImageIcon } from 'lucide-react';

// Generic Draggable Component
interface DraggableItemProps {
    children: React.ReactNode;
    position: {x: number, y: number};
    onDragEnd: (pos: {x: number, y: number}) => void;
    onClick: () => void;
    bounds?: { minX: number, maxX: number, minY: number, maxY: number };
}

const DraggableItem: React.FC<DraggableItemProps> = ({ 
    children, 
    position, 
    onDragEnd, 
    onClick,
    bounds
}) => {
    const [isDragging, setIsDragging] = useState(false);
    const dragStartRef = useRef({ x: 0, y: 0 });
    const localPosRef = useRef(position);
    const [currentPos, setCurrentPos] = useState(position);
    const hasMoved = useRef(false);

    useEffect(() => {
        setCurrentPos(position);
        localPosRef.current = position;
    }, [position]);

    const handlePointerDown = (e: React.PointerEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
        hasMoved.current = false;
        dragStartRef.current = { x: e.clientX, y: e.clientY };
    };

    useEffect(() => {
        const handlePointerMove = (e: PointerEvent) => {
            if (!isDragging) return;
            const dx = e.clientX - dragStartRef.current.x;
            const dy = e.clientY - dragStartRef.current.y;
            
            if (Math.abs(dx) > 3 || Math.abs(dy) > 3) hasMoved.current = true;

            let newX = localPosRef.current.x + dx;
            let newY = localPosRef.current.y + dy;

            // Apply Bounds
            const minX = bounds?.minX ?? 10;
            const maxX = bounds?.maxX ?? window.innerWidth - 60;
            const minY = bounds?.minY ?? 60;
            const maxY = bounds?.maxY ?? window.innerHeight - 80;

            newX = Math.max(minX, Math.min(newX, maxX));
            newY = Math.max(minY, Math.min(newY, maxY));

            setCurrentPos({ x: newX, y: newY });
        };

        const handlePointerUp = (e: PointerEvent) => {
            if (!isDragging) return;
            setIsDragging(false);
            const dx = e.clientX - dragStartRef.current.x;
            const dy = e.clientY - dragStartRef.current.y;
            
            let newX = localPosRef.current.x + dx;
            let newY = localPosRef.current.y + dy;

            const minX = bounds?.minX ?? 10;
            const maxX = bounds?.maxX ?? window.innerWidth - 60;
            const minY = bounds?.minY ?? 60;
            const maxY = bounds?.maxY ?? window.innerHeight - 80;

            newX = Math.max(minX, Math.min(newX, maxX));
            newY = Math.max(minY, Math.min(newY, maxY));

            onDragEnd({ x: newX, y: newY });
        };

        if (isDragging) {
            window.addEventListener('pointermove', handlePointerMove);
            window.addEventListener('pointerup', handlePointerUp);
        }
        return () => {
            window.removeEventListener('pointermove', handlePointerMove);
            window.removeEventListener('pointerup', handlePointerUp);
        };
    }, [isDragging, onDragEnd, bounds]);

    return (
        <div 
            className="absolute z-[60] cursor-move touch-none animate-scale-in"
            style={{ left: currentPos.x, top: currentPos.y }}
            onPointerDown={handlePointerDown}
            onClick={() => { if(!hasMoved.current) onClick(); }}
        >
            {children}
        </div>
    );
};

const App: React.FC = () => {
  // Navigation State
  const [currentView, setCurrentView] = useState<'home' | 'config' | 'chatDetail' | 'townMap' | 'livingRoom'>('home');
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  
  // App-Level State
  const [myHouseType, setMyHouseType] = useState<number>(3); 
  const [selectedNeighbor, setSelectedNeighbor] = useState<LotData | null>(null);
  const [showBotChat, setShowBotChat] = useState(false);
  const [savedTasks, setSavedTasks] = useState<TaskItem[]>([
      { title: "Review UI Prototype", assignee: "Jason", priority: "High", status: "Pending" }
  ]);
  const [miniApps, setMiniApps] = useState<MiniApp[]>([]);
  const [showMiniAppCreator, setShowMiniAppCreator] = useState(false);
  const [activeMiniApp, setActiveMiniApp] = useState<MiniApp | null>(null);
  const [creatorInitialPrompt, setCreatorInitialPrompt] = useState('');
  const [creatorShowExamples, setCreatorShowExamples] = useState(true);

  // Draggable States
  const [miniAppMode, setMiniAppMode] = useState<'expanded' | 'minimized'>('expanded');
  const [miniAppPos, setMiniAppPos] = useState({ x: 20, y: 80 });
  
  const [showAddBotModal, setShowAddBotModal] = useState(false);
  const [botConfig, setBotConfig] = useState<BotConfig>({
    name: 'MyBot',
    avatar: 'https://img.freepik.com/premium-psd/3d-cartoon-character-avatar-isolated-3d-rendering_235528-554.jpg?w=200',
    systemInstruction: 'You are a helpful and friendly digital assistant living in this town.',
    documents: [],
    installedSkillIds: [],
    knowledgeKeywords: [],
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleConfigSave = (newConfig: BotConfig) => {
    setBotConfig(newConfig);
    setCurrentView('home');
  };

  const handleChatClick = (chatId: string) => {
    setSelectedChatId(chatId);
    setCurrentView('chatDetail');
  };

  const handleBotChatClick = () => {
    setShowBotChat(true);
  };

  const handleBackToHome = () => {
    setSelectedChatId(null);
    setCurrentView('home');
  };

  const handleTownMapClick = () => {
    setCurrentView('townMap');
  };

  const handleMyHomeClick = () => {
    setCurrentView('livingRoom');
  };

  const handleAddTask = (task: TaskItem) => {
    setSavedTasks(prev => [task, ...prev]);
  };

  const handleCreateMiniApp = (app: MiniApp) => {
    setMiniApps(prev => [app, ...prev]);
  };

  const handleQuickCreate = (type: string) => {
      if (type === 'news') {
          setCreatorInitialPrompt('生成一个新闻Mini App，每2个小时采集Reddit, Github, 排名前100的美国和中国科技媒体的热点AI新闻。');
      } else if (type === 'price') {
          setCreatorInitialPrompt('针对你收藏的昂跑、LEGO、Lululemon等品牌，在 12 小时内监控全网最低价并自动尝试领取优惠券。');
      } else if (type === 'words') {
          setCreatorInitialPrompt('生成一个英语背单词Mini App，每日随机生成一个高阶词，美式发音，同义词反义词，点击翻面。');
      } else {
          setCreatorInitialPrompt('');
      }
      setCreatorShowExamples(false);
      setShowMiniAppCreator(true);
  };

  const handleOpenCreator = () => {
      setCreatorInitialPrompt('');
      setCreatorShowExamples(true);
      setShowMiniAppCreator(true);
  };

  const handleDeleteMiniApp = (id: string) => {
    setMiniApps(prev => prev.filter(app => app.id !== id));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        // Mock upload behavior
        console.log("Uploaded file:", file.name);
        // Open chat to "show" the upload happened (simulated)
        setShowBotChat(true);
    }
  };

  const getActiveChat = (): ChatMessage | undefined => {
    return CHAT_DATA.find(c => c.id === selectedChatId);
  };

  const activeChat = getActiveChat();

  return (
    // Main Container - Dark Theme Ambient Background
    <div className="min-h-screen bg-black flex justify-center items-center p-0 sm:p-6 md:p-10 font-sans text-white selection:bg-blue-500/30">
      
      {/* Mobile Frame Simulation - Apple Glass Aesthetic */}
      <div 
        className="w-full max-w-[430px] h-[100dvh] sm:h-[900px] sm:rounded-[56px] shadow-[0_0_80px_rgba(0,0,0,0.8)] overflow-hidden relative flex flex-col border-[8px] border-[#1a1a1a] transition-all duration-500 ring-1 ring-white/10"
        style={{
             backgroundColor: '#000000',
        }}
      >
        {/* Abstract Premium Wallpaper */}
        <div className="absolute inset-0 z-0">
             <img 
                src="https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=1000&auto=format&fit=crop" 
                className="w-full h-full object-cover scale-110"
                alt="Abstract Background" 
             />
             <div className="absolute inset-0 bg-black/40 mix-blend-multiply"></div>
             {/* Gradient Overlay for depth */}
             <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/80"></div>
        </div>

        {/* Conditional Rendering Logic */}
        {currentView === 'config' ? (
          <ConfigScreen 
            currentConfig={botConfig}
            onSave={handleConfigSave}
            onBack={() => setCurrentView('home')}
          />
        ) : currentView === 'chatDetail' && activeChat ? (
          <ChatDetailScreen 
            key={activeChat.id} 
            chat={activeChat}
            onBack={handleBackToHome}
            onAddTask={handleAddTask}
          />
        ) : currentView === 'townMap' ? (
          <TownMapScreen 
            onBack={handleBackToHome}
          />
        ) : currentView === 'livingRoom' ? (
          <LivingRoomScreen 
            onBack={handleBackToHome}
            currentHouseType={myHouseType}
            onUpdateHouseType={setMyHouseType}
            onOpenMarket={() => setCurrentView('config')}
          />
        ) : (
          <>
            {/* Home View Content */}
            
            {/* Dynamic Island / Notch */}
            <div className="hidden sm:block absolute top-4 left-1/2 transform -translate-x-1/2 w-[120px] h-[36px] bg-black rounded-full z-50 pointer-events-none shadow-lg border border-white/5 flex items-center justify-center">
                 <div className="w-16 h-16 rounded-full bg-black/50 blur-xl absolute -z-10"></div>
            </div>

            <TownSection 
              myBotConfig={botConfig} 
              myHouseType={myHouseType}
              onConfigClick={() => setCurrentView('config')} 
              onTownMapClick={handleTownMapClick}
              onBotChatClick={handleBotChatClick}
              onMyHomeClick={handleMyHomeClick}
              onNeighborSelect={setSelectedNeighbor}
              onAddBotClick={() => setShowAddBotModal(true)}
            />
            
            {/* Expanded Cards Layer */}
            {miniAppMode === 'expanded' && (
                <div className="absolute top-[16%] left-0 right-0 px-4 z-40 flex items-start justify-center pointer-events-none">
                    <div className="w-full max-w-sm pointer-events-auto transition-all duration-300">
                        <MiniAppWidget 
                            apps={miniApps} 
                            tasks={savedTasks}
                            onOpenApp={setActiveMiniApp} 
                            onOpenCreator={handleOpenCreator}
                            onQuickCreate={handleQuickCreate}
                            onMinimize={() => setMiniAppMode('minimized')}
                            onDeleteApp={handleDeleteMiniApp}
                        />
                    </div>
                </div>
            )}

            {/* Minimized Dashboard Bubble */}
            {miniAppMode === 'minimized' && (
                <DraggableItem 
                    position={miniAppPos}
                    onDragEnd={setMiniAppPos}
                    onClick={() => setMiniAppMode('expanded')}
                    bounds={{ minX: 10, maxX: 370, minY: 60, maxY: 400 }} // Keep in top half
                >
                    <div className="bg-white/10 backdrop-blur-xl p-3.5 rounded-[20px] shadow-2xl border border-white/20 flex items-center justify-center group active:scale-95 transition-transform hover:bg-white/20">
                       <div className="text-white drop-shadow-md">
                          <Grid size={22} />
                       </div>
                       <div className="absolute top-full mt-2 bg-black/60 backdrop-blur-md text-white text-[10px] px-2 py-0.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap border border-white/10">
                           Dashboard
                       </div>
                    </div>
                </DraggableItem>
            )}

            {/* New Search/Prompt Bar - Dark Theme & Scaled Down */}
            <div className="absolute top-[43%] left-0 right-0 px-6 z-50 flex items-center justify-center pointer-events-none animate-fade-in">
                {/* Hidden File Input */}
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleImageUpload} 
                />

                {/* Scaled Container (90%) */}
                <div className="w-full max-w-sm pointer-events-auto transform scale-90 origin-center transition-all duration-300">
                    <div className="bg-[#1c1c1e]/80 backdrop-blur-xl rounded-[36px] p-2 flex items-center gap-2 border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)] ring-1 ring-white/5">
                        
                        {/* Plus Button (Upload) */}
                        <button 
                            onClick={() => fileInputRef.current?.click()}
                            className="w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white border border-white/5 active:scale-95 transition-all shrink-0 group"
                        >
                            <Plus size={24} strokeWidth={2} className="group-hover:text-blue-200 transition-colors" />
                        </button>
                        
                        {/* Input Capsule */}
                        <div 
                            onClick={handleBotChatClick}
                            className="flex-1 h-12 bg-black/20 rounded-full px-4 flex items-center justify-between border border-white/5 hover:border-white/10 cursor-text active:scale-[0.99] transition-all group"
                        >
                            <div className="flex items-center gap-2">
                                <div className="w-0.5 h-4 bg-blue-500 rounded-full animate-pulse"></div>
                                <span className="text-sm font-medium text-white/40 group-hover:text-white/60 transition-colors">Ask anything</span>
                            </div>
                            <div className="flex items-center gap-3 opacity-60">
                                <Mic size={18} className="text-white" />
                                <div className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center">
                                    <AudioLines size={12} className="text-white" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <ChatSection onChatClick={handleChatClick} />
            
            {/* Modals & Overlays */}
            {showBotChat && (
              <div className="absolute top-0 left-0 w-full h-[55%] z-[60] flex items-center justify-center">
                 <div 
                    className="absolute inset-0 bg-black/40 backdrop-blur-md" 
                    onClick={() => setShowBotChat(false)}
                 />
                 <div className="relative w-[92%] h-[90%] shadow-2xl rounded-[32px] overflow-hidden animate-scale-in border border-white/10 bg-[#1c1c1e]/90">
                    <ChatDetailScreen 
                        chat={{
                            id: 'my_bot_embedded',
                            name: botConfig.name,
                            avatar: botConfig.avatar,
                            message: '',
                            time: 'Now'
                        }}
                        onBack={() => setShowBotChat(false)}
                        onAddTask={handleAddTask}
                        systemInstruction={botConfig.systemInstruction}
                        variant="embedded"
                    />
                 </div>
              </div>
            )}
            
            {selectedNeighbor && (
              <NeighborProfileModal 
                  lot={selectedNeighbor} 
                  onClose={() => setSelectedNeighbor(null)} 
              />
            )}

            {showMiniAppCreator && (
              <MiniAppCreator 
                onClose={() => setShowMiniAppCreator(false)}
                onCreated={handleCreateMiniApp}
                initialPrompt={creatorInitialPrompt}
                showExamples={creatorShowExamples}
              />
            )}

            {activeMiniApp && (
              <MiniAppRenderer 
                app={activeMiniApp}
                onClose={() => setActiveMiniApp(null)}
              />
            )}

            {showAddBotModal && (
                <AddBotModal onClose={() => setShowAddBotModal(false)} />
            )}
            
          </>
        )}
        
      </div>
    </div>
  );
};

export default App;
