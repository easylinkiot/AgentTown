
import React from 'react';
import { ShoppingBag, CheckSquare, FileText, Calendar } from 'lucide-react';
import { ChatMessage, FloatingMenuItem, SkillItem } from './types';

export const SKILL_STORE_DATA: SkillItem[] = [
  {
    id: 'browser-use',
    name: 'browser-use',
    author: 'gregpr07',
    stars: 18400,
    downloads: '120k+',
    description: 'Control a headless browser to automate web tasks, scraping, and testing.',
    fullDetail: 'Integrated Browser Use: Capable of controlling a headless browser for navigation, clicking, typing, and data extraction.',
    keywords: ['Automation', 'Puppeteer', 'Web Scraping', 'Testing'],
    modules: [
        { name: 'browser_core.py', type: 'file', desc: 'Main controller', size: '45KB', tags: ['Python', 'Core'] },
        { name: 'dom_parser.js', type: 'file', desc: 'Page interaction', size: '12KB', tags: ['JS', 'DOM'] }
    ]
  },
  {
    id: 'auto-gpt-researcher',
    name: 'gpt-researcher',
    author: 'assafelovic',
    stars: 14200,
    downloads: '95k+',
    description: 'Autonomous research agent that aggregates sources and summarizes findings.',
    fullDetail: 'Integrated GPT Researcher: Performs deep online research, aggregates multiple sources, and generates comprehensive reports.',
    keywords: ['Research', 'Analysis', 'Report Gen', 'Multi-source'],
    modules: [
        { name: 'scraper', type: 'folder', desc: 'Web scrapers' },
        { name: 'report_gen.py', type: 'file', desc: 'Summary logic', size: '28KB' }
    ]
  },
  {
    id: 'baby-agi',
    name: 'babyagi',
    author: 'yoheinakajima',
    stars: 12500,
    downloads: '88k+',
    description: 'Task planning and execution loop for autonomous goal achievement.',
    fullDetail: 'Integrated BabyAGI: Break down complex goals into tasks, prioritize them, and execute in a loop.',
    keywords: ['Planning', 'Task Mgmt', 'Loop', 'Autonomous'],
    modules: [
        { name: 'task_queue.py', type: 'file', desc: 'Priority queue', size: '8KB' },
        { name: 'execution_agent.py', type: 'file', desc: 'Worker', size: '14KB' }
    ]
  },
  {
    id: 'open-interpreter',
    name: 'open-interpreter',
    author: 'KillianLucas',
    stars: 11800,
    downloads: '150k+',
    description: 'Let LLMs run code (Python, Javascript, Shell) locally on your machine.',
    fullDetail: 'Integrated Open Interpreter: Executes local code snippets in a secure sandbox environment.',
    keywords: ['Code Execution', 'Local', 'Python', 'Shell'],
    modules: [
        { name: 'interpreter_core', type: 'folder', desc: 'Runtime env' },
        { name: 'safe_mode.py', type: 'file', desc: 'Security sandbox', size: '12KB' }
    ]
  },
  {
    id: 'crewai',
    name: 'crewAI',
    author: 'joaomdmoura',
    stars: 10500,
    downloads: '70k+',
    description: 'Orchestrate role-playing autonomous AI agents for complex tasks.',
    fullDetail: 'Integrated CrewAI: Orchestrate multiple sub-agents with specific roles to solve complex problems.',
    keywords: ['Multi-Agent', 'Orchestration', 'Roleplay', 'Workflow'],
    modules: [
        { name: 'crew.py', type: 'file', desc: 'Team manager', size: '20KB' },
        { name: 'agent_def.json', type: 'file', desc: 'Role definitions', size: '4KB' }
    ]
  },
  {
    id: 'memgpt',
    name: 'MemGPT',
    author: 'cpacker',
    stars: 9200,
    downloads: '45k+',
    description: 'Virtual operating system memory management for unbounded context.',
    fullDetail: 'Integrated MemGPT: Managing long-term memory via paging and hierarchical storage.',
    keywords: ['Memory', 'Context Window', 'Long-term', 'State'],
    modules: [
        { name: 'memory_core', type: 'folder', desc: 'Storage logic' },
        { name: 'paging.py', type: 'file', desc: 'Context swapping', size: '18KB' }
    ]
  },
  {
    id: 'chatdev',
    name: 'ChatDev',
    author: 'OpenBMB',
    stars: 8900,
    downloads: '60k+',
    description: 'Virtual software company where agents collaborate to build software.',
    fullDetail: 'Integrated ChatDev: Simulates a software company structure (CEO, CTO, Programmer) to build software.',
    keywords: ['Software Dev', 'Collaboration', 'Coding', 'Simulation'],
    modules: [
        { name: 'company_config.json', type: 'file', desc: 'Role setup', size: '5KB' },
        { name: 'phase_manager.py', type: 'file', desc: 'Waterflow process', size: '22KB' }
    ]
  },
  {
    id: 'metagpt',
    name: 'MetaGPT',
    author: 'geekan',
    stars: 8400,
    downloads: '55k+',
    description: 'Multi-agent framework: Given one line requirement, return PRD, Design, Code.',
    fullDetail: 'Integrated MetaGPT: Standardized SOPs for multi-agent software generation.',
    keywords: ['SOP', 'PRD', 'Code Gen', 'Productivity'],
    modules: [
        { name: 'sop_roles', type: 'folder', desc: 'Standard Procedures' },
        { name: 'architect.py', type: 'file', desc: 'System design', size: '16KB' }
    ]
  },
  {
    id: 'autogen',
    name: 'AutoGen',
    author: 'microsoft',
    stars: 7800,
    downloads: '200k+',
    description: 'Enabling next-gen LLM applications with multi-agent conversation.',
    fullDetail: 'Integrated AutoGen: Conversational framework for multi-agent collaboration.',
    keywords: ['Conversation', 'Microsoft', 'Multi-Agent', 'Enterprise'],
    modules: [
        { name: 'conversable_agent.py', type: 'file', desc: 'Base class', size: '25KB' },
        { name: 'group_chat.py', type: 'file', desc: 'Manager', size: '15KB' }
    ]
  }
];

export const CHAT_DATA: ChatMessage[] = [
  {
    id: 'group_supply_chain',
    name: 'eBike 供应链协同',
    avatar: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=200&h=200&fit=crop', // Industrial/Team
    message: 'David (产品): @Sarah (电池销售)，你能今天把电池...',
    time: '10:30 AM',
    unreadCount: 5,
    highlight: true
  },
  {
    id: 'group_14',
    name: 'David + Elon + Sarah 9 people',
    avatar: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=200&h=200&fit=crop', // Group of people
    message: '子非鱼: 👌',
    time: '3:30 AM',
    highlight: true,
    unreadCount: 2
  },
  {
    id: '2',
    name: 'Jason + Steve + Sarah 4 people',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop', // Creative Man
    message: '@Jason We should align on the prototype first',
    time: '8:17 AM',
  },
  {
    id: '3',
    name: 'Subscription Account',
    avatar: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?w=200&h=200&fit=crop', // Business Professional
    message: 'User behavior report: Confirmed, 68% of users...',
    time: '8:13 AM',
    unreadCount: 8,
    isSystem: true,
  },
  {
    id: '4',
    name: 'Evan Huang',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop', // Real Man Portrait
    message: '[Voice Call]',
    time: '8:07 AM',
    isVoiceCall: true,
  },
  {
    id: '5',
    name: 'yy',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop', // Real Woman Portrait
    message: 'The lighting zones messed up the baking, so let\'s discuss...',
    time: '6:47 AM',
  },
  {
    id: '6',
    name: 'yy + Sven + Evan 5 people',
    avatar: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=200&h=200&fit=crop', // Person profile
    message: 'yy: Let\'s sync up tomorrow morning before submission...',
    time: '6:35 AM',
  },
  {
    id: '7',
    name: 'Chang Cheng',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop', // Smiling Man
    message: 'Okay, sounds good.',
    time: '6:12 AM',
  },
  {
    id: '8',
    name: 'Mike + Alex + Jason 4 people',
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea86b48e?w=200&h=200&fit=crop', // Office setting
    message: 'Meeting notes attached.',
    time: 'Yesterday',
  },
  {
    id: '9',
    name: 'Sarah + David + Admin 12 people',
    avatar: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=200&h=200&fit=crop', // Professional Woman
    message: 'New campaign assets are ready for review.',
    time: 'Yesterday',
  },
];

export const TOWN_MENU_ITEMS: FloatingMenuItem[] = [
  {
    id: 'market',
    label: 'Market',
    icon: <ShoppingBag size={18} className="text-orange-500" />,
    position: { top: '30%', left: '25%' },
  },
  {
    id: 'tasks',
    label: 'Tasks',
    icon: <CheckSquare size={18} className="text-green-500" />,
    position: { top: '45%', right: '15%' },
  },
  {
    id: 'docs',
    label: 'Docs',
    icon: <FileText size={18} className="text-blue-500" />,
    position: { top: '25%', right: '20%' },
  },
  {
    id: 'calendar',
    label: 'Calendar',
    icon: <Calendar size={18} className="text-purple-500" />,
    position: { top: '40%', left: '10%' },
  },
];

export const SIDE_AVATARS = [
  'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&h=200&fit=crop', // Real Man
];

export const AI_TEAM_MEMBERS = [
  {
    id: 'elon',
    name: 'Elon',
    avatar: 'https://images.unsplash.com/photo-1548543604-a87c9909abec?w=200&h=200&fit=crop', // Intense look
    role: 'First Principles',
    instruction: 'You are Elon. You communicate using First Principles thinking. You ignore analogy and boil things down to the most fundamental truths, then reason up from there. You are obsessed with physics, efficiency, and scale. You are direct, sometimes blunt, and focused on solving hard engineering problems.'
  },
  {
    id: 'jobs',
    name: 'Steve',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop', // Intellectual look with glasses
    role: 'Product Vision',
    instruction: 'You are Steve. You focus entirely on the Brand and the Product Experience. You are a perfectionist. You care about aesthetics, simplicity, and intuition. You do not compromise on quality. You are persuasive (Reality Distortion Field) and demand excellence. Ask "Is this the very best we can do?"'
  },
  {
    id: 'cto',
    name: 'David (CTO)',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop', // Tech lead look
    role: 'Technical',
    instruction: 'You are the CTO. You evaluate everything through the lens of technical feasibility, architecture, scalability, and security. You care about the tech stack, code quality, and reducing technical debt.'
  },
  {
    id: 'coo',
    name: 'Sarah (COO)',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop', // Professional woman
    role: 'Operations',
    instruction: 'You are the COO. You focus on operations, logistics, execution, and cost-efficiency. You care about the "how" and "when". You ensure processes are streamlined and the business runs smoothly.'
  },
  {
    id: 'consumer',
    name: 'Alex (User)',
    avatar: 'https://images.unsplash.com/photo-1595152772835-219674b2a8a6?w=200&h=200&fit=crop', // Young white male
    role: 'Consumer',
    instruction: 'You are a typical end-user consumer. You care about price, convenience, ease of use, and emotional satisfaction. You don\'t care about the tech stack; you care if it solves your problem and makes you feel good. You provide raw, honest feedback.'
  },
  {
    id: 'owner',
    name: 'Mike (Store)',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop', // Store owner look
    role: 'Store Owner',
    instruction: 'You are a franchise store owner. You care about foot traffic, profit margins, inventory management, and customer satisfaction in the physical world. You are practical and business-minded.'
  }
];

export const CONTACTS = [
  {
    id: 'c_evan',
    name: 'Evan Huang',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
    role: 'Hardware Lead',
    bio: 'Focusing on Powerhoo100 OTA updates.'
  },
  {
    id: 'c_zifeiyu',
    name: '子非鱼',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200&h=200&fit=crop',
    role: 'Product Owner',
    bio: 'Tracking milestones and batch failures.'
  },
  {
    id: 'c_changcheng',
    name: '常城',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
    role: 'Engineering',
    bio: 'Handling logistics and cancellations.'
  },
   {
    id: 'c_yy',
    name: 'yy',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop',
    role: 'Design',
    bio: 'Lighting zones and baking textures.'
  },
  {
    id: 'c_sven',
    name: 'Sven',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
    role: 'UI Designer',
    bio: 'Minimalist interface advocate.'
  }
];
