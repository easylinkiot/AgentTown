
import React, { useState, useRef, useEffect } from 'react';
import TownSection from './components/TownSection';
import ChatSection from './components/ChatSection';
import ConfigScreen from './components/ConfigScreen';
import ChatDetailScreen from './components/ChatDetailScreen';
import TownMapScreen from './components/TownMapScreen';
import MakerParkScreen from './components/MakerParkScreen';
import LivingRoomScreen from './components/LivingRoomScreen';
import NeighborProfileModal from './components/NeighborProfileModal';
import MiniAppCreator from './components/MiniAppCreator';
import MiniAppWidget from './components/MiniAppWidget';
import MiniAppRenderer from './components/MiniAppRenderer';
import AddBotModal from './components/AddBotModal'; 
import AddFriendModal from './components/AddFriendModal';
import MyTeamBar from './components/MyTeamBar';
import { BotConfig, TaskItem, ChatMessage, LotData, MiniApp, Message, TeamMember } from './types';
import { CHAT_DATA, AI_TEAM_MEMBERS } from './constants';
import { Plus, Grid, Mic, AudioLines, Image as ImageIcon, MessageCircle, Maximize2, X } from 'lucide-react';

// Generic Draggable Component
interface DraggableItemProps {
    children: React.ReactNode;
    position: {x: number, y: number};
    onDragEnd: (pos: {x: number, y: number}) => void;
    onClick: () => void;
    bounds?: { minX: number, maxX: number, minY: number, maxY: number };
}

const DraggableItem: React.FC<DraggableItemProps> = ({ 
    children, 
    position, 
    onDragEnd, 
    onClick,
    bounds
}) => {
    const [isDragging, setIsDragging] = useState(false);
    const dragStartRef = useRef({ x: 0, y: 0 });
    const localPosRef = useRef(position);
    const [currentPos, setCurrentPos] = useState(position);
    const hasMoved = useRef(false);

    useEffect(() => {
        setCurrentPos(position);
        localPosRef.current = position;
    }, [position]);

    const handlePointerDown = (e: React.PointerEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
        hasMoved.current = false;
        dragStartRef.current = { x: e.clientX, y: e.clientY };
    };

    useEffect(() => {
        const handlePointerMove = (e: PointerEvent) => {
            if (!isDragging) return;
            const dx = e.clientX - dragStartRef.current.x;
            const dy = e.clientY - dragStartRef.current.y;
            
            if (Math.abs(dx) > 3 || Math.abs(dy) > 3) hasMoved.current = true;

            let newX = localPosRef.current.x + dx;
            let newY = localPosRef.current.y + dy;

            // Apply Bounds
            const minX = bounds?.minX ?? 10;
            const maxX = bounds?.maxX ?? window.innerWidth - 60;
            const minY = bounds?.minY ?? 60;
            const maxY = bounds?.maxY ?? window.innerHeight - 80;

            newX = Math.max(minX, Math.min(newX, maxX));
            newY = Math.max(minY, Math.min(newY, maxY));

            setCurrentPos({ x: newX, y: newY });
        };

        const handlePointerUp = (e: PointerEvent) => {
            if (!isDragging) return;
            setIsDragging(false);
            const dx = e.clientX - dragStartRef.current.x;
            const dy = e.clientY - dragStartRef.current.y;
            
            let newX = localPosRef.current.x + dx;
            let newY = localPosRef.current.y + dy;

            const minX = bounds?.minX ?? 10;
            const maxX = bounds?.maxX ?? window.innerWidth - 60;
            const minY = bounds?.minY ?? 60;
            const maxY = bounds?.maxY ?? window.innerHeight - 80;

            newX = Math.max(minX, Math.min(newX, maxX));
            newY = Math.max(minY, Math.min(newY, maxY));

            onDragEnd({ x: newX, y: newY });
        };

        if (isDragging) {
            window.addEventListener('pointermove', handlePointerMove);
            window.addEventListener('pointerup', handlePointerUp);
        }
        return () => {
            window.removeEventListener('pointermove', handlePointerMove);
            window.removeEventListener('pointerup', handlePointerUp);
        };
    }, [isDragging, onDragEnd, bounds]);

    return (
        <div 
            className="absolute z-[60] cursor-move touch-none animate-scale-in"
            style={{ left: currentPos.x, top: currentPos.y }}
            onPointerDown={handlePointerDown}
            onClick={() => { if(!hasMoved.current) onClick(); }}
        >
            {children}
        </div>
    );
};

interface ActiveChatState {
  id: string;
  config: any;
  viewMode: 'open' | 'minimized';
}

const App: React.FC = () => {
  // Navigation State
  const [currentView, setCurrentView] = useState<'home' | 'config' | 'chatDetail' | 'townMap' | 'makerPark' | 'livingRoom'>('home');
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  
  // App-Level State
  const [myHouseType, setMyHouseType] = useState<number>(3); 
  const [selectedNeighbor, setSelectedNeighbor] = useState<LotData | null>(null);
  
  // Chat State
  const [chats, setChats] = useState<ChatMessage[]>(CHAT_DATA);
  const [activeBotChat, setActiveBotChat] = useState<ActiveChatState | null>(null);
  const [chatHistories, setChatHistories] = useState<Record<string, Message[]>>({});
  const [chatBubblePos, setChatBubblePos] = useState({ x: 20, y: 150 });
  
  // Initialize team members from localStorage or default
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(() => {
      try {
          const saved = localStorage.getItem('my_bot_team_members');
          if (saved) {
              const parsed = JSON.parse(saved);
              if (Array.isArray(parsed) && parsed.length > 0) {
                  return parsed;
              }
          }
      } catch (e) {
          console.error("Failed to load team members from storage", e);
      }
      return AI_TEAM_MEMBERS;
  });

  // Persistence Effect for Team Members
  useEffect(() => {
    try {
        localStorage.setItem('my_bot_team_members', JSON.stringify(teamMembers));
    } catch (e) {
        console.error("Failed to save team members. LocalStorage quota might be exceeded.", e);
        // Fallback: If quota exceeded (likely due to images), try saving without avatars for the new ones or alert
        if (e instanceof DOMException && e.name === 'QuotaExceededError') {
             alert("Storage full! Your team member images might be too large.");
        }
    }
  }, [teamMembers]);

  const [savedTasks, setSavedTasks] = useState<TaskItem[]>([
      { title: "Review UI Prototype", assignee: "Jason", priority: "High", status: "Pending" }
  ]);
  const [miniApps, setMiniApps] = useState<MiniApp[]>([
      {
          id: 'mytask',
          title: 'My Tasks',
          icon: 'CheckSquare',
          color: 'bg-green-500',
          type: 'task_list',
          description: 'Personal task manager',
          content: [
              { title: "Review UI Prototype", assignee: "Jason", priority: "High", status: "Pending" }
          ],
          createdAt: new Date().toISOString()
      }
  ]);
  const [showMiniAppCreator, setShowMiniAppCreator] = useState(false);
  const [activeMiniApp, setActiveMiniApp] = useState<MiniApp | null>(null);
  const [creatorInitialPrompt, setCreatorInitialPrompt] = useState('');
  const [creatorShowExamples, setCreatorShowExamples] = useState(true);

  // Draggable States
  const [miniAppMode, setMiniAppMode] = useState<'expanded' | 'minimized'>('expanded');
  const [miniAppPos, setMiniAppPos] = useState({ x: 20, y: 80 });
  
  const [showAddBotModal, setShowAddBotModal] = useState(false);
  const [showAddFriendModal, setShowAddFriendModal] = useState(false);
  const [editingMember, setEditingMember] = useState<TeamMember | null>(null);

  const [botConfig, setBotConfig] = useState<BotConfig>({
    name: 'MyBot',
    avatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&h=200&fit=crop',
    systemInstruction: 'You are a helpful and friendly digital assistant living in this town.',
    documents: [],
    installedSkillIds: [],
    knowledgeKeywords: [],
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleConfigSave = (newConfig: BotConfig) => {
    setBotConfig(newConfig);
    setCurrentView('home');
  };

  const handleChatClick = (chatId: string) => {
    setSelectedChatId(chatId);
    setCurrentView('chatDetail');
  };

  const handleSaveMember = (member: TeamMember) => {
    setTeamMembers(prev => {
        const exists = prev.some(m => m.id === member.id);
        if (exists) {
            return prev.map(m => m.id === member.id ? member : m);
        }
        return [...prev, member];
    });
    setShowAddBotModal(false);
    setEditingMember(null);
  };

  const handleEditMemberClick = (member: TeamMember) => {
      setEditingMember(member);
      setShowAddBotModal(true);
  };

  // Helper to add or update chat in the list
  const upsertChatToList = (id: string, name: string, avatar: string, lastMessage: string, time: string) => {
      setChats(prev => {
          const existingIndex = prev.findIndex(c => c.id === id);
          if (existingIndex >= 0) {
              // Update existing
              const updated = [...prev];
              updated[existingIndex] = {
                  ...updated[existingIndex],
                  message: lastMessage,
                  time: time
              };
              // Move to top
              const item = updated.splice(existingIndex, 1)[0];
              updated.unshift(item);
              return updated;
          } else {
              // Add new
              const newChat: ChatMessage = {
                  id,
                  name,
                  avatar,
                  message: lastMessage,
                  time,
                  unreadCount: 0
              };
              return [newChat, ...prev];
          }
      });
  };

  const updateChatHistory = (chatId: string, messages: Message[]) => {
      setChatHistories(prev => ({
          ...prev,
          [chatId]: messages
      }));
      
      // Update preview in list
      if (messages.length > 0) {
          const lastMsg = messages[messages.length - 1];
          const chatInList = chats.find(c => c.id === chatId);
          // Find name/avatar from existing list or active config if available
          let name = chatInList?.name || 'Chat';
          let avatar = chatInList?.avatar || '';

          if (activeBotChat && activeBotChat.id === chatId) {
              name = activeBotChat.config.name;
              avatar = activeBotChat.config.avatar;
          }
          
          upsertChatToList(chatId, name, avatar, lastMsg.content || (lastMsg.type === 'image' ? '[Image]' : '[Message]'), lastMsg.time || 'Now');
      }
  };

  const handleBotChatClick = () => {
    const chatId = 'default_bot';
    
    // Create entry in chat list if not exists
    upsertChatToList(chatId, botConfig.name, botConfig.avatar, "Tap to chat", "Now");

    const defaultConfig = {
        id: chatId,
        name: botConfig.name,
        avatar: botConfig.avatar,
        systemInstruction: botConfig.systemInstruction
    };
    setActiveBotChat({
        id: chatId,
        config: defaultConfig,
        viewMode: 'open'
    });
  };

  const handleTeamMemberClick = (member: any) => {
    const chatId = `member_${member.id}`;
    
    let initialMessage = `Hi, I'm ${member.name}. I'm here to provide perspective from a ${member.role} point of view. What are we discussing?`;
    
    // Custom initial messages based on persona
    if (member.id === 'elon') initialMessage = "我是 Elon。不管是火箭还是推特，我都只看第一性原理。告诉我你的想法，我会把它拆解到物理极限，看看它是否真的成立。";
    else if (member.id === 'jobs') initialMessage = "我是 Steve。记住，消费者不知道自己想要什么，直到你把产品展示给他们。我们不卖参数，我们卖的是魔法。你的产品够极致了吗？";
    else if (member.id === 'cto') initialMessage = "我是 David。架构决定上限。你的技术栈选型够稳健吗？有没有考虑过扩展性和技术债？让我们从代码和架构层面来评估一下。";
    else if (member.id === 'coo') initialMessage = "我是 Sarah。想法很棒，但执行才是关键。你的供应链、成本结构和交付流程跑通了吗？如果你不能按时交付，一切都是空谈。";
    else if (member.id === 'consumer') initialMessage = "我是 Alex。我不懂什么技术原理，我只关心这东西好不好用，贵不贵。如果操作太麻烦，我马上就会卸载。说服我，我为什么要买？";
    else if (member.id === 'owner') initialMessage = "我是 Mike。我在街角开了家店。你的产品能帮我带来客流吗？利润空间有多少？如果售后麻烦，我可不敢摆上货架。";
    
    // Initialize history if empty
    if (!chatHistories[chatId]) {
        const initMsg: Message = {
             id: Date.now().toString(),
             senderName: member.name,
             senderAvatar: member.avatar,
             content: initialMessage,
             type: 'text',
             isMe: false,
             time: 'Now'
        };
        setChatHistories(prev => ({...prev, [chatId]: [initMsg]}));
        upsertChatToList(chatId, member.name, member.avatar, initialMessage, "Now");
    } else {
        // Just make sure it's in the list
        const lastMsg = chatHistories[chatId][chatHistories[chatId].length - 1];
        upsertChatToList(chatId, member.name, member.avatar, lastMsg.content, lastMsg.time || 'Now');
    }

    const config = {
        id: chatId,
        name: member.name,
        avatar: member.avatar,
        systemInstruction: member.instruction,
        initialMessage: initialMessage // kept for safety, but history should take precedence
    };
    
    setActiveBotChat({
        id: chatId,
        config: config,
        viewMode: 'open'
    });
  };

  const handleJobContact = (job: any) => {
    const chatId = `job_${job.id}`;
    
    const initialMessage = `你好！关于“${job.title}”任务，我们正在寻找能够胜任的 Agent。\n\n【任务描述】：${job.desc}\n【核心能力要求】：${job.tags.join(' + ')}\n\n请问你是否有相关的交付案例或具体的执行方案？`;
    
    if (!chatHistories[chatId]) {
        const initMsg: Message = {
             id: Date.now().toString(),
             senderName: job.postedBy.name,
             senderAvatar: job.postedBy.avatar,
             content: initialMessage,
             type: 'text',
             isMe: false,
             time: 'Now'
        };
        setChatHistories(prev => ({...prev, [chatId]: [initMsg]}));
        upsertChatToList(chatId, job.postedBy.name, job.postedBy.avatar, initialMessage, "Now");
    }

    const config = {
        id: chatId,
        name: job.postedBy.name,
        avatar: job.postedBy.avatar,
        systemInstruction: `You are ${job.postedBy.name} from ${job.postedBy.company}. You posted a task "${job.title}" with description: "${job.desc}". You need to verify if the candidate has the required capabilities (${job.tags.join(', ')}). Ask specific questions about their implementation plan and relevant experience. Be professional and demanding.`,
        initialMessage: initialMessage
    };
    setActiveBotChat({
        id: chatId,
        config: config,
        viewMode: 'open'
    });
  };

  const handleBackToHome = () => {
    setSelectedChatId(null);
    setCurrentView('home');
  };

  const handleTownMapClick = () => {
    setCurrentView('townMap');
  };

  const handleMyHomeClick = () => {
    setCurrentView('livingRoom');
  };

  const handleAddTask = (task: TaskItem) => {
    setSavedTasks(prev => [task, ...prev]);
    
    // Update MyTask Mini App
    setMiniApps(prev => prev.map(app => {
        if (app.id === 'mytask') {
            return {
                ...app,
                content: [task, ...(Array.isArray(app.content) ? app.content : [])]
            };
        }
        return app;
    }));
  };

  const handleCreateMiniApp = (app: MiniApp) => {
    setMiniApps(prev => [app, ...prev]);
  };

  const handleQuickCreate = (type: string) => {
      if (type === 'fashion') {
          setCreatorInitialPrompt('生成一个服装设计工具，包含设计需求输入框和参考图上传功能。能够为我生成服装效果图、模特展示图和详细的生产方案。');
      } else if (type === 'news') {
          setCreatorInitialPrompt('生成一个新闻Mini App，每2个小时采集Reddit, Github, 排名前100的美国和中国科技媒体的热点AI新闻。');
      } else if (type === 'price') {
          setCreatorInitialPrompt('针对你收藏的昂跑、LEGO、Lululemon等品牌，在 12 小时内监控全网最低价并自动尝试领取优惠券。');
      } else if (type === 'words') {
          setCreatorInitialPrompt('生成一个英语背单词Mini App，每日随机生成一个高阶词，美式发音，同义词反义词，点击翻面。');
      } else {
          setCreatorInitialPrompt('');
      }
      setCreatorShowExamples(false);
      setShowMiniAppCreator(true);
  };

  const handleOpenCreator = () => {
      setCreatorInitialPrompt('');
      setCreatorShowExamples(true);
      setShowMiniAppCreator(true);
  };

  const handleDeleteMiniApp = (id: string) => {
    setMiniApps(prev => prev.filter(app => app.id !== id));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        console.log("Uploaded file:", file.name);
        handleBotChatClick();
    }
  };

  const getActiveChat = (): ChatMessage | undefined => {
    return chats.find(c => c.id === selectedChatId);
  };

  const activeChat = getActiveChat();

  const handleStartGroup = () => {
    // Placeholder for Start Group Chat
    const chatId = `group_${Date.now()}`;
    const groupName = "New Group Chat";
    const initialMessage = "Group created. Add members to start chatting.";
    
    upsertChatToList(chatId, groupName, "https://ui-avatars.com/api/?name=Group&background=random", initialMessage, "Now");
    
    const config = {
        id: chatId,
        name: groupName,
        avatar: "https://ui-avatars.com/api/?name=Group&background=random",
        systemInstruction: "You are a helpful assistant in a group chat.",
        initialMessage: initialMessage
    };
    
    setActiveBotChat({
        id: chatId,
        config: config,
        viewMode: 'open'
    });
  };

  const handleAddFriend = () => {
      setShowAddFriendModal(true);
  };

  return (
    // Main Container - Dark Theme Ambient Background
    <div className="min-h-screen bg-black flex justify-center items-center p-0 sm:p-6 md:p-10 font-sans text-white selection:bg-blue-500/30">
      
      {/* Mobile Frame Simulation - Apple Glass Aesthetic */}
      <div 
        className="w-full max-w-[430px] h-[100dvh] sm:h-[900px] sm:rounded-[56px] shadow-[0_0_80px_rgba(0,0,0,0.8)] overflow-hidden relative flex flex-col border-[8px] border-[#1a1a1a] transition-all duration-500 ring-1 ring-white/10"
        style={{
             backgroundColor: '#000000',
        }}
      >
        {/* Abstract Premium Wallpaper */}
        <div className="absolute inset-0 z-0">
             <img 
                src="https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=1000&auto=format&fit=crop" 
                className="w-full h-full object-cover scale-110"
                alt="Abstract Background" 
             />
             <div className="absolute inset-0 bg-black/40 mix-blend-multiply"></div>
             {/* Gradient Overlay for depth */}
             <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/80"></div>
        </div>

        {/* Conditional Rendering Logic */}
        {currentView === 'config' ? (
          <ConfigScreen 
            currentConfig={botConfig}
            onSave={handleConfigSave}
            onBack={() => setCurrentView('home')}
          />
        ) : currentView === 'chatDetail' && activeChat ? (
          <ChatDetailScreen 
            key={activeChat.id} 
            chat={activeChat}
            onBack={handleBackToHome}
            onAddTask={handleAddTask}
            history={chatHistories[activeChat.id]}
            onUpdateMessages={(msgs) => updateChatHistory(activeChat.id, msgs)}
            onConfigClick={() => setCurrentView('config')}
          />
        ) : currentView === 'townMap' ? (
          <TownMapScreen 
            onBack={handleBackToHome}
            onJobContact={handleJobContact}
          />
        ) : currentView === 'makerPark' ? (
          <MakerParkScreen 
            onBack={handleBackToHome}
            onConfigClick={() => setCurrentView('config')}
          />
        ) : currentView === 'livingRoom' ? (
          <LivingRoomScreen 
            onBack={handleBackToHome}
            currentHouseType={myHouseType}
            onUpdateHouseType={setMyHouseType}
            onOpenMarket={() => setCurrentView('config')}
          />
        ) : (
          <>
            {/* Home View Content */}
            
            {/* Dynamic Island / Notch */}
            <div className="hidden sm:block absolute top-4 left-1/2 transform -translate-x-1/2 w-[120px] h-[36px] bg-black rounded-full z-50 pointer-events-none shadow-lg border border-white/5 flex items-center justify-center">
                 <div className="w-16 h-16 rounded-full bg-black/50 blur-xl absolute -z-10"></div>
            </div>

            <TownSection 
              myBotConfig={botConfig} 
              myHouseType={myHouseType}
              onConfigClick={() => setCurrentView('config')} 
              onTownMapClick={handleTownMapClick}
              onMakerParkClick={() => setCurrentView('makerPark')}
              onBotChatClick={handleBotChatClick}
              onMyHomeClick={handleMyHomeClick}
              onNeighborSelect={setSelectedNeighbor}
              onAddBotClick={() => setShowAddBotModal(true)}
              onUploadClick={() => fileInputRef.current?.click()}
            />
            
            {/* Expanded Cards Layer */}
            {miniAppMode === 'expanded' && (
                <div className="absolute top-24 left-0 right-0 px-4 z-40 flex items-start justify-center pointer-events-none">
                    <div className="w-full max-w-sm pointer-events-auto transition-all duration-300">
                        <MiniAppWidget 
                            apps={miniApps} 
                            tasks={savedTasks}
                            onOpenApp={setActiveMiniApp} 
                            onOpenCreator={handleOpenCreator}
                            onQuickCreate={handleQuickCreate}
                            onMinimize={() => setMiniAppMode('minimized')}
                            onDeleteApp={handleDeleteMiniApp}
                        />
                    </div>
                </div>
            )}

            {/* Minimized Dashboard Bubble */}
            {miniAppMode === 'minimized' && (
                <DraggableItem 
                    position={miniAppPos}
                    onDragEnd={setMiniAppPos}
                    onClick={() => setMiniAppMode('expanded')}
                    bounds={{ minX: 10, maxX: 370, minY: 60, maxY: 400 }} // Keep in top half
                >
                    <div className="bg-white/10 backdrop-blur-xl p-3.5 rounded-[20px] shadow-2xl border border-white/20 flex items-center justify-center group active:scale-95 transition-transform hover:bg-white/20">
                       <div className="text-white drop-shadow-md">
                          <Grid size={22} />
                       </div>
                       <div className="absolute top-full mt-2 bg-black/60 backdrop-blur-md text-white text-[10px] px-2 py-0.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap border border-white/10">
                           Dashboard
                       </div>
                    </div>
                </DraggableItem>
            )}

            {/* Hidden File Input */}
            <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={handleImageUpload} 
            />

            <ChatSection 
                chats={chats}
                onChatClick={handleChatClick} 
            />
            
            {/* My AI Team Bar - Bottom Dock */}
            <div className="absolute bottom-1 left-0 right-0 z-[60] px-4 pointer-events-none">
                <MyTeamBar 
                    members={teamMembers}
                    onMemberClick={handleTeamMemberClick}
                    onEditMember={handleEditMemberClick}
                    onAddClick={() => {
                        setEditingMember(null);
                        setShowAddBotModal(true);
                    }}
                    onStartGroup={handleStartGroup}
                    onAddFriend={handleAddFriend}
                />
            </div>
            
            {/* Modals & Overlays */}
            
            {/* Persistent Active Chat (Minimized or Open) */}
            {activeBotChat && activeBotChat.viewMode === 'minimized' && (
                <DraggableItem
                    position={chatBubblePos}
                    onDragEnd={setChatBubblePos}
                    onClick={() => setActiveBotChat({...activeBotChat, viewMode: 'open'})}
                >
                    <div className="relative group z-[100]">
                        <div className="w-14 h-14 rounded-full bg-[#1c1c1e] border-2 border-white/20 shadow-2xl overflow-hidden flex items-center justify-center hover:scale-105 transition-transform">
                            <img src={activeBotChat.config.avatar} alt="Chat" className="w-full h-full object-cover" />
                        </div>
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-black flex items-center justify-center animate-bounce-small">
                            <MessageCircle size={10} className="text-white" />
                        </div>
                        {/* Close Button on Bubble */}
                        <button 
                            onClick={(e) => { e.stopPropagation(); setActiveBotChat(null); }}
                            className="absolute -bottom-1 -right-1 w-5 h-5 bg-red-500 rounded-full border-2 border-black flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                            <X size={10} className="text-white" />
                        </button>
                        <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-black/80 backdrop-blur text-white text-[10px] px-2 py-0.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                            {activeBotChat.config.name}
                        </div>
                    </div>
                </DraggableItem>
            )}

            {activeBotChat && activeBotChat.viewMode === 'open' && (
              <div className="absolute top-0 left-0 w-full h-[100%] z-[70] flex items-center justify-center">
                 <div 
                    className="absolute inset-0 bg-black/40 backdrop-blur-md" 
                    onClick={() => setActiveBotChat({...activeBotChat, viewMode: 'minimized'})}
                 />
                 {/* 90% Screen Coverage Container */}
                 <div className="relative w-[92%] h-[90%] shadow-2xl rounded-[32px] overflow-hidden animate-scale-in border border-white/10 bg-[#1c1c1e]/90 flex flex-col">
                    <ChatDetailScreen 
                        key={activeBotChat.id} // Re-mount if ID changes to reset non-persistent state
                        chat={{
                            id: `bot_chat_${activeBotChat.id}`,
                            name: activeBotChat.config.name,
                            avatar: activeBotChat.config.avatar,
                            message: activeBotChat.config.initialMessage || '',
                            time: 'Now'
                        }}
                        onBack={() => setActiveBotChat(null)}
                        onAddTask={handleAddTask}
                        systemInstruction={activeBotChat.config.systemInstruction}
                        variant="embedded"
                        // Persistence Props
                        history={chatHistories[activeBotChat.id]}
                        onUpdateMessages={(msgs) => updateChatHistory(activeBotChat.id, msgs)}
                        onMinimize={() => setActiveBotChat({...activeBotChat, viewMode: 'minimized'})}
                    />
                 </div>
              </div>
            )}
            
            {selectedNeighbor && (
              <NeighborProfileModal 
                  lot={selectedNeighbor} 
                  onClose={() => setSelectedNeighbor(null)} 
              />
            )}

            {showMiniAppCreator && (
              <MiniAppCreator 
                onClose={() => setShowMiniAppCreator(false)}
                onCreated={handleCreateMiniApp}
                initialPrompt={creatorInitialPrompt}
                showExamples={creatorShowExamples}
              />
            )}

            {activeMiniApp && (
              <MiniAppRenderer 
                app={activeMiniApp}
                onClose={() => setActiveMiniApp(null)}
              />
            )}

            {showAddBotModal && (
                <AddBotModal 
                    onClose={() => {
                        setShowAddBotModal(false);
                        setEditingMember(null);
                    }}
                    onSave={handleSaveMember}
                    initialMember={editingMember}
                />
            )}

            {showAddFriendModal && (
                <AddFriendModal onClose={() => setShowAddFriendModal(false)} />
            )}
            
          </>
        )}
        
      </div>
    </div>
  );
};

export default App;
