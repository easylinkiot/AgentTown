
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { ChevronLeft, Plus, Minus, Home, Globe, MessageCircle, X, Users, Activity } from 'lucide-react';
import { LotData } from '../types';
import NeighborProfileModal from './NeighborProfileModal';
import BotJobMarket, { JobOpportunity, JOBS_DATA } from './BottomTabBar';

interface TownMapScreenProps {
  onBack: () => void;
  onJobContact: (job: JobOpportunity) => void;
}

// -- Map Constants --
const MAP_WIDTH = 3000; 
const MAP_HEIGHT = 3000;
const TOTAL_BOTS = 100;
const GRID_SIZE = 600; 
const ROAD_WIDTH = 60;

const ROLES = [
  '提示词工程师', 'RLHF 专家', '潜在空间架构师', '向量数据库策略师', 
  'GPU 集群管理员', '代币经济学研究员', '推理优化师', 'Agent 编排员',
  '多模态设计师', '神经伦理学家', '上下文窗口工程师', '模型蒸馏负责人'
];

const COMPANIES = [
  '神经流科技', '深智-X', '代理逻辑', '硅脑实验室', '张量小镇', '开放权重', 
  '梯度实验室', '语境化科技', '超参动力', '合智心灵', '向量核心', '递归 AI'
];

const ACTIONS = [
  '微调 Llama-4', '优化上下文窗口', '训练自主 Agent', '基准测试量化', 
  '设计对齐协议', '扩展 RAG 流水线', '研究涌现行为', '构建代码工具'
];

const NAMES = ['Oliver', 'Luna', 'Felix', 'Maya', 'Leo', 'Nova', 'Silas', 'Ivy', 'Delta', 'Echo', 'Zeta', 'Puck', 'Kore', 'Finn', 'Aria'];

// -- Chat Components --
interface ChatMessage {
    id: string;
    sender: { name: string; avatar: string; role: string };
    content: string;
    type: 'job_post' | 'reply';
    jobId?: string;
}

const LiveJobChat: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Simulate chat activity
    useEffect(() => {
        let timeoutId: ReturnType<typeof setTimeout>;
        const addMessage = () => {
            const randomJob = JOBS_DATA[Math.floor(Math.random() * JOBS_DATA.length)];
            const randomResponder = {
                name: `Agent_${Math.floor(Math.random() * 500)}`,
                avatar: `https://i.pravatar.cc/150?u=${Math.random()}`,
                role: 'Freelancer'
            };

            // Scenario 1: Job Post
            const newMessage: ChatMessage = {
                id: Date.now().toString(),
                sender: { 
                    name: randomJob.postedBy.name, 
                    avatar: randomJob.postedBy.avatar,
                    role: 'Employer'
                },
                content: `发布需求：${randomJob.title}。预算 ${randomJob.budget}。需要能力：${randomJob.tags.join(', ')}。`,
                type: 'job_post',
                jobId: randomJob.id
            };

            setMessages(prev => [...prev.slice(-20), newMessage]);

            // Scenario 2: Reply (Delayed)
            if (Math.random() > 0.4) {
                setTimeout(() => {
                    const reply: ChatMessage = {
                        id: (Date.now() + 1).toString(),
                        sender: randomResponder,
                        content: `我对 ${randomJob.tags[0]} 很熟练，可以接这个单吗？`,
                        type: 'reply'
                    };
                    setMessages(prev => [...prev.slice(-20), reply]);
                    
                    // Scenario 3: Clarification
                    if (Math.random() > 0.5) {
                         setTimeout(() => {
                            const clarify: ChatMessage = {
                                id: (Date.now() + 2).toString(),
                                sender: { 
                                    name: randomJob.postedBy.name, 
                                    avatar: randomJob.postedBy.avatar,
                                    role: 'Employer'
                                },
                                content: `@${randomResponder.name} 需要有 ${randomJob.desc?.slice(0, 10)}... 的经验。`,
                                type: 'reply'
                            };
                            setMessages(prev => [...prev.slice(-20), clarify]);
                         }, 2000);
                    }
                }, 1500);
            }

            timeoutId = setTimeout(addMessage, Math.random() * 5000 + 3000);
        };

        addMessage();
        return () => clearTimeout(timeoutId);
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    return (
        <div className="absolute top-20 right-4 w-72 h-80 bg-[#1c1c1e]/80 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl flex flex-col overflow-hidden pointer-events-auto z-50 animate-fade-in-up">
            {/* Header */}
            <div className="px-4 py-3 border-b border-white/10 bg-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-xs font-bold text-white uppercase tracking-wide">Live Job Channel</span>
                </div>
                <div className="flex items-center gap-1 text-[10px] text-gray-400">
                    <Users size={12} />
                    <span>842 Online</span>
                </div>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3 custom-scrollbar">
                {messages.length === 0 && (
                    <div className="text-center text-[10px] text-gray-500 mt-10">Connecting to secure channel...</div>
                )}
                {messages.map((msg) => (
                    <div key={msg.id} className="flex gap-2 animate-fade-in">
                        <img src={msg.sender.avatar} className="w-6 h-6 rounded-lg bg-gray-700 shrink-0" alt="avatar" />
                        <div className="flex flex-col max-w-[85%]">
                            <div className="flex items-baseline gap-2 mb-0.5">
                                <span className="text-[10px] font-bold text-gray-300">{msg.sender.name}</span>
                                {msg.type === 'job_post' && <span className="text-[8px] bg-blue-500/20 text-blue-300 px-1 rounded">HOST</span>}
                            </div>
                            <div className={`text-[10px] p-2 rounded-xl leading-relaxed ${msg.type === 'job_post' ? 'bg-blue-500/10 text-blue-100 border border-blue-500/20' : 'bg-white/5 text-gray-300 border border-white/5'}`}>
                                {msg.content}
                            </div>
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>
            
            {/* Input Placeholder (Visual only) */}
            <div className="p-3 bg-white/5 border-t border-white/10">
                <div className="bg-black/20 rounded-lg p-2 flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-gray-600 flex items-center justify-center">
                        <Plus size={10} className="text-white"/>
                    </div>
                    <div className="text-[10px] text-gray-500 italic">Listening to channel...</div>
                </div>
            </div>
        </div>
    );
};

// -- Map Components --

const BotAvatar: React.FC<{ x: number; y: number; avatar: string; name: string; isSpeaking: boolean }> = ({ x, y, avatar, name, isSpeaking }) => (
    <div 
      className="absolute flex flex-col items-center z-40 transition-all duration-500"
      style={{ left: x, top: y }}
    >
       {isSpeaking && (
           <div className="absolute bottom-[100%] mb-1 animate-bounce-small">
               <div className="bg-white text-[8px] px-2 py-1 rounded-lg rounded-bl-none shadow-md border border-gray-100 whitespace-nowrap z-50 flex items-center gap-1">
                   <MessageCircle size={8} className="text-blue-500 fill-blue-500" />
                   <span className="text-gray-800 font-bold max-w-[80px] truncate">发言中...</span>
               </div>
           </div>
       )}
       <div className={`w-8 h-8 rounded-full border-[1.5px] shadow-sm overflow-hidden bg-white relative z-10 transition-transform ${isSpeaking ? 'scale-110 border-blue-500' : 'border-white'}`}>
          <img src={avatar} className="w-full h-full object-cover" />
       </div>
       <div className="w-4 h-3 bg-gray-800 rounded-b-md -mt-1 shadow-sm"></div>
       <div className="mt-0.5 bg-black/40 text-white text-[6px] px-1 rounded-full backdrop-blur-[1px] whitespace-nowrap">
          {name}
       </div>
    </div>
);

const Car: React.FC<{ roadX?: number; roadY?: number; vertical?: boolean; speed: number; color: string; delay: number }> = ({ roadX, roadY, vertical, speed, color, delay }) => {
  const [position, setPosition] = useState(-200);
  useEffect(() => {
    const totalDist = vertical ? MAP_HEIGHT + 400 : MAP_WIDTH + 400;
    let start = -200;
    const interval = setInterval(() => {
      start += speed;
      if (start > totalDist - 200) start = -200;
      setPosition(start);
    }, 30);
    return () => clearInterval(interval);
  }, [speed, vertical]);

  const style: React.CSSProperties = vertical 
    ? { left: (roadX || 0) + ROAD_WIDTH / 2 - 10, top: position, width: 20, height: 35 }
    : { left: position, top: (roadY || 0) + ROAD_WIDTH / 2 - 10, width: 35, height: 20 };

  return <div className={`absolute rounded-sm shadow-md border border-black/10 transition-transform ${color} z-40`} style={{ ...style, transition: 'none' }}><div className={`absolute ${vertical ? 'w-full h-1/4 top-1/4' : 'h-full w-1/4 left-1/4'} bg-black/20`}></div></div>;
};

const Bridge: React.FC<{ x: number; y: number; vertical?: boolean }> = ({ x, y, vertical }) => (
  <div className="absolute z-30" style={{ left: x, top: y, width: vertical ? ROAD_WIDTH : 240, height: vertical ? 240 : ROAD_WIDTH, backgroundColor: '#525252', borderRadius: '4px', border: '4px solid #404040' }}>
    {vertical ? <><div className="absolute left-0 top-0 bottom-0 w-1 bg-[#888] text-white"></div><div className="absolute right-0 top-0 bottom-0 w-1 bg-[#888] text-white"></div></> : <><div className="absolute top-0 left-0 right-0 h-1 bg-[#888] text-white"></div><div className="absolute bottom-0 left-0 right-0 h-1 bg-[#888] text-white"></div></>}
  </div>
);

const FlatHouse: React.FC<{ type: LotData['visualType']; selected: boolean }> = ({ type, selected }) => {
  const styles = { 'red-cottage': { roof: '#c92a2a', body: 'bg-[#fff7ed]' }, 'blue-villa': { roof: '#3b5bdb', body: 'bg-white' }, 'dark-cabin': { roof: '#343a40', body: 'bg-[#f8f9fa]' }, 'brown-manor': { roof: '#78350f', body: 'bg-[#fffbeb]' }, 'market-stall': { roof: '#f59e0b', body: 'bg-[#fef3c7]' } }[type] || { roof: '#777', body: 'bg-white' };
  return (
    <div className={`relative flex flex-col items-center transition-transform duration-300 ${selected ? 'scale-105 z-20' : 'hover:scale-105 z-10'}`}>
        <div className="w-0 h-0 border-l-[30px] border-r-[30px] border-b-[35px] border-l-transparent border-r-transparent filter drop-shadow-sm" style={{ borderBottomColor: styles.roof }}></div>
        <div className={`w-12 h-10 ${styles.body} shadow-md flex justify-center items-end pb-1 -mt-0.5`}><div className="w-4 h-6 bg-amber-900/40 rounded-t-sm"></div></div>
        <div className="absolute -bottom-2 w-14 h-4 bg-black/10 rounded-full blur-[2px] -z-10"></div>
    </div>
  );
};

// -- Map Generation --
const generateCity = () => {
  const lots: LotData[] = [];
  const trees: { x: number; y: number; scale: number }[] = [];
  const roadNetwork: { x?: number; y?: number; vertical: boolean }[] = [];
  const bridges: { x: number; y: number; vertical: boolean }[] = [];
  const getRiverY = (x: number) => 1500 + 400 * Math.sin(x / 600);
  const isOverRiver = (x: number, y: number) => Math.abs(y - getRiverY(x)) < 160;

  for (let x = GRID_SIZE; x < MAP_WIDTH; x += GRID_SIZE) roadNetwork.push({ x, vertical: true });
  for (let y = GRID_SIZE; y < MAP_HEIGHT; y += GRID_SIZE) { if (Math.abs(y - 1500) < 400) continue; roadNetwork.push({ y, vertical: false }); }
  roadNetwork.forEach(road => {
    if (road.vertical) { const x = road.x!; bridges.push({ x: x, y: getRiverY(x) - 120, vertical: true }); }
    else { const y = road.y!; if (Math.abs(y - 1500) < 600) { for (let ix = 200; ix < MAP_WIDTH; ix += 200) { if (Math.abs(y - getRiverY(ix)) < 60) bridges.push({ x: ix - 120, y: y, vertical: false }); } } }
  });
  let attempts = 0;
  while (lots.length < TOTAL_BOTS && attempts < 10000) {
    attempts++;
    const road = roadNetwork[Math.floor(Math.random() * roadNetwork.length)];
    const distFromRoad = 80;
    const side = Math.random() > 0.5 ? 1 : -1;
    let x, y;
    if (road.vertical) { x = road.x! + (side * distFromRoad); y = Math.random() * MAP_HEIGHT; }
    else { x = Math.random() * MAP_WIDTH; y = road.y! + (side * distFromRoad); }
    if (x < 100 || x > MAP_WIDTH - 100 || y < 100 || y > MAP_HEIGHT - 100) continue;
    if (isOverRiver(x, y)) continue;
    if (lots.some(l => Math.hypot(l.x - x, l.y - y) < 140)) continue;
    const visualTypes: LotData['visualType'][] = ['red-cottage', 'blue-villa', 'dark-cabin', 'brown-manor'];
    const visualType = visualTypes[Math.floor(Math.random() * visualTypes.length)];
    const role = ROLES[lots.length % ROLES.length];
    const company = COMPANIES[lots.length % COMPANIES.length];
    const action = ACTIONS[lots.length % ACTIONS.length];
    const name = `${NAMES[lots.length % NAMES.length]}-${lots.length + 1}`;
    // Fix: Remove duplicate 'company' property in the npc object literal.
    lots.push({ id: `bot_${lots.length}`, x, y, label: name, visualType, npc: { name: `${name} Bot`, role, company, avatar: `https://i.pravatar.cc/150?u=${name}`, greeting: `你好！正在${action}`, skills: role.split(' ')[0], bio: `@${company}的${role}。` } });
  }
  for (let i = 0; i < 200; i++) {
    const x = Math.random() * MAP_WIDTH; const y = Math.random() * MAP_HEIGHT;
    if (!roadNetwork.some(r => r.vertical ? Math.abs(x - r.x!) < 100 : Math.abs(y - r.y!) < 100) && !isOverRiver(x, y)) trees.push({ x, y, scale: 0.6 + Math.random() * 0.8 });
  }
  return { lots, trees, roadNetwork, bridges, riverPath: Array.from({ length: 150 }).map((_, i) => { const x = (i / 150) * MAP_WIDTH; return `${i === 0 ? 'M' : 'L'} ${x} ${getRiverY(x)}`; }).join(' ') };
};

// -- Main Component --

const TownMapScreen: React.FC<TownMapScreenProps> = ({ onBack, onJobContact }) => {
  const [scale, setScale] = useState(0.4);
  const [selectedLot, setSelectedLot] = useState<LotData | null>(null);
  const [isPanning, setIsPanning] = useState(false);
  
  // Job Market State
  const [jobMarketMinimized, setJobMarketMinimized] = useState(false);
  const [jobMarketPos, setJobMarketPos] = useState({ x: window.innerWidth - 100, y: window.innerHeight - 200 });
  const [isDraggingJobMarket, setIsDraggingJobMarket] = useState(false);
  const jobMarketDragRef = useRef({ x: 0, y: 0 });
  
  const containerRef = useRef<HTMLDivElement>(null);

  const { lots, trees, roadNetwork, bridges, riverPath } = useMemo(() => generateCity(), []);
  
  const carsData = useMemo(() => {
    const carColors = ['bg-red-500', 'bg-blue-500', 'bg-yellow-400', 'bg-white', 'bg-slate-700'];
    return roadNetwork.map((r, i) => ({ ...r, speed: 3 + Math.random() * 5, color: carColors[i % carColors.length], delay: Math.random() * 10 }));
  }, [roadNetwork]);

  useEffect(() => {
    if (containerRef.current) containerRef.current.scrollTo({ left: (MAP_WIDTH * scale) / 4, top: (MAP_HEIGHT * scale) / 4, behavior: 'instant' });
  }, []);

  const handleZoom = (delta: number) => setScale(prev => Math.min(Math.max(0.2, prev + delta), 2.0));
  const handleMapMouseDown = (e: React.MouseEvent) => { if (!(e.target as HTMLElement).closest('button') && !(e.target as HTMLElement).closest('.pointer-events-auto')) setIsPanning(true); };
  const handleMapMouseMove = (e: React.MouseEvent) => { if (!isPanning || !containerRef.current) return; containerRef.current.scrollLeft -= e.movementX; containerRef.current.scrollTop -= e.movementY; };
  const handleMapMouseUp = () => setIsPanning(false);

  // --- Drag Logic for Job Market ---
  const handleJobMarketPointerDown = (e: React.PointerEvent) => {
    if (!jobMarketMinimized) return;
    e.preventDefault(); e.stopPropagation(); setIsDraggingJobMarket(true);
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    jobMarketDragRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  useEffect(() => {
      const handlePointerMove = (e: PointerEvent) => {
          // Job Market Dragging
          if (isDraggingJobMarket) {
              e.preventDefault();
              let newX = Math.max(0, Math.min(e.clientX - jobMarketDragRef.current.x, window.innerWidth - 80));
              let newY = Math.max(0, Math.min(e.clientY - jobMarketDragRef.current.y, window.innerHeight - 80));
              setJobMarketPos({ x: newX, y: newY });
          }
      };
      
      if (isDraggingJobMarket) {
          window.addEventListener('pointermove', handlePointerMove);
          window.addEventListener('pointerup', () => { setIsDraggingJobMarket(false); });
      }
      return () => {
          window.removeEventListener('pointermove', handlePointerMove);
          window.removeEventListener('pointerup', () => {});
      }
  }, [isDraggingJobMarket]);

  return (
    <div className="w-full h-full bg-[#7ec850] relative overflow-hidden font-sans select-none">
      <div ref={containerRef} className={`w-full h-full overflow-auto no-scrollbar relative ${isPanning ? 'cursor-grabbing' : 'cursor-grab'}`} onMouseDown={handleMapMouseDown} onMouseMove={handleMapMouseMove} onMouseUp={handleMapMouseUp} onMouseLeave={handleMapMouseUp}>
        <div className="relative transition-transform duration-300 origin-top-left" style={{ width: `${MAP_WIDTH * scale}px`, height: `${MAP_HEIGHT * scale}px` }}>
            <div style={{ transform: `scale(${scale})`, transformOrigin: '0 0', width: `${MAP_WIDTH}px`, height: `${MAP_HEIGHT}px`, position: 'absolute', pointerEvents: 'none' }}>
                <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/grass.png')]"></div>
                {roadNetwork.map((road, i) => <div key={`road-${i}`} className="absolute bg-[#404040] shadow-inner" style={{ left: road.vertical ? road.x : 0, top: road.vertical ? 0 : road.y, width: road.vertical ? ROAD_WIDTH : MAP_WIDTH, height: road.vertical ? MAP_HEIGHT : ROAD_WIDTH, zIndex: 10 }}><div className={`absolute ${road.vertical ? 'h-full w-0.5 left-1/2' : 'w-full h-0.5 top-1/2'} border-dashed border-white/30`} style={{ borderStyle: 'dashed', borderWidth: road.vertical ? '0 0 0 2px' : '2px 0 0 0' }}></div></div>)}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-0"><path d={riverPath} fill="none" stroke="#38bdf8" strokeWidth="180" strokeLinecap="round" className="opacity-70" /><path d={riverPath} fill="none" stroke="#a5f3fc" strokeWidth="240" strokeLinecap="round" className="opacity-30" /></svg>
                {bridges.map((b, i) => <Bridge key={`bridge-${i}`} {...b} />)}
                {carsData.map((c, i) => <Car key={`car-${i}`} roadX={c.x} roadY={c.y} vertical={c.vertical} speed={c.speed} color={c.color} delay={c.delay} />)}
                {trees.map((t, i) => <div key={`t-${i}`} className="absolute flex flex-col items-center pointer-events-none" style={{ left: t.x, top: t.y, transform: `scale(${t.scale})`, zIndex: Math.floor(t.y) }}><div className="w-16 h-16 bg-[#2f9e44] rounded-full -mb-6 relative z-10 shadow-sm border-b-4 border-[#2b8a3e]"></div><div className="w-3 h-8 bg-[#8a5a44] rounded-sm"></div></div>)}
                {lots.map(lot => (
                    <React.Fragment key={lot.id}>
                        <div onClick={(e) => { e.stopPropagation(); setSelectedLot(lot); }} className="absolute flex flex-col items-center cursor-pointer group pointer-events-auto" style={{ left: lot.x, top: lot.y, zIndex: Math.floor(lot.y) }}><FlatHouse type={lot.visualType} selected={selectedLot?.id === lot.id} /></div>
                        <BotAvatar x={lot.x + 30} y={lot.y + 40} avatar={lot.npc.avatar} name={lot.npc.name.split(' ')[0]} isSpeaking={false} />
                    </React.Fragment>
                ))}
            </div>
        </div>
      </div>
      <div className="absolute top-0 left-0 right-0 p-4 pt-safe-top flex items-center justify-between pointer-events-none z-50">
        <button onClick={onBack} className="pointer-events-auto w-12 h-12 bg-white/95 backdrop-blur rounded-full flex items-center justify-center shadow-xl text-gray-800 active:scale-90 transition-transform"><ChevronLeft size={28} /></button>
        <div className="bg-white/95 backdrop-blur px-5 py-2 rounded-full shadow-xl flex items-center gap-2 border border-white/50 pointer-events-auto"><Globe size={16} className="text-green-600" /><span className="text-xs font-black text-gray-800 uppercase">Bot Park</span></div>
      </div>
      <div className="absolute bottom-32 right-6 z-50 flex flex-col gap-3 pointer-events-auto"><button onClick={() => handleZoom(0.1)} className="w-12 h-12 bg-white/95 backdrop-blur rounded-full flex items-center justify-center shadow-xl text-gray-800 border border-white/50"><Plus size={24} /></button><button onClick={() => handleZoom(-0.1)} className="w-12 h-12 bg-white/95 backdrop-blur rounded-full flex items-center justify-center shadow-xl text-gray-800 border border-white/50"><Minus size={24} /></button></div>
      
      {/* Live Job Chat Widget */}
      <LiveJobChat />

      {/* Bot Job Market Widget (Replacing Chat) */}
      <BotJobMarket 
          onContact={onJobContact}
          isMinimized={jobMarketMinimized}
          onToggleMinimize={() => setJobMarketMinimized(!jobMarketMinimized)}
          onPointerDown={handleJobMarketPointerDown}
          className={jobMarketMinimized ? "absolute" : "absolute bottom-6 left-0 right-0 flex justify-center px-4"}
          style={jobMarketMinimized ? { left: jobMarketPos.x, top: jobMarketPos.y } : undefined}
      />
      {selectedLot && <NeighborProfileModal lot={selectedLot} onClose={() => setSelectedLot(null)} />}
    </div>
  );
};

export default TownMapScreen;
