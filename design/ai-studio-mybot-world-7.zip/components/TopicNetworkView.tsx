import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { X, ZoomIn, ZoomOut, Maximize, Share2 } from 'lucide-react';

interface NetworkNode extends d3.SimulationNodeDatum {
  id: string;
  label: string;
  status: 'discussed' | 'pending';
  group?: number;
}

interface NetworkLink extends d3.SimulationLinkDatum<NetworkNode> {
  source: string | NetworkNode;
  target: string | NetworkNode;
  value?: number;
}

interface TopicNetworkViewProps {
  data: {
    nodes: NetworkNode[];
    links: NetworkLink[];
  };
  onClose: () => void;
}

const TopicNetworkView: React.FC<TopicNetworkViewProps> = ({ data, onClose }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoomLevel, setZoomLevel] = useState(1);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current || !data.nodes.length) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // Clear previous render
    d3.select(svgRef.current).selectAll("*").remove();

    const svg = d3.select(svgRef.current)
      .attr("viewBox", [0, 0, width, height])
      .attr("width", width)
      .attr("height", height);

    // Add a group for the graph content to enable zooming
    const g = svg.append("g");

    // Zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on("zoom", (event) => {
        g.attr("transform", event.transform);
        setZoomLevel(event.transform.k);
      });

    svg.call(zoom);

    // Simulation setup
    const simulation = d3.forceSimulation<NetworkNode>(data.nodes)
      .force("link", d3.forceLink<NetworkNode, NetworkLink>(data.links).id(d => d.id).distance(100))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collide", d3.forceCollide().radius(40));

    // Render Links
    const link = g.append("g")
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(data.links)
      .join("line")
      .attr("stroke-width", d => Math.sqrt(d.value || 1) * 1.5)
      .attr("stroke", "#4b5563"); // Gray-600

    // Render Nodes
    const node = g.append("g")
      .selectAll("g")
      .data(data.nodes)
      .join("g")
      .call(d3.drag<SVGGElement, NetworkNode>()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended));

    // Node Circles
    node.append("circle")
      .attr("r", 8)
      .attr("fill", d => d.status === 'discussed' ? '#3b82f6' : '#374151') // Blue-500 vs Gray-700
      .attr("stroke", d => d.status === 'discussed' ? '#60a5fa' : '#9ca3af')
      .attr("stroke-width", 2)
      .attr("class", "cursor-pointer transition-all duration-300 hover:scale-110");

    // Node Labels (Background for readability)
    node.append("rect")
      .attr("rx", 4)
      .attr("ry", 4)
      .attr("fill", "rgba(0,0,0,0.7)")
      .attr("x", 12)
      .attr("y", -10)
      .attr("width", d => d.label.length * 7 + 10) // Approx width
      .attr("height", 20);

    // Node Labels (Text)
    node.append("text")
      .text(d => d.label)
      .attr("x", 17)
      .attr("y", 4)
      .attr("font-size", "10px")
      .attr("fill", "#e5e7eb") // Gray-200
      .attr("font-weight", "bold")
      .attr("pointer-events", "none");

    // Simulation Tick
    simulation.on("tick", () => {
      link
        .attr("x1", d => (d.source as NetworkNode).x!)
        .attr("y1", d => (d.source as NetworkNode).y!)
        .attr("x2", d => (d.target as NetworkNode).x!)
        .attr("y2", d => (d.target as NetworkNode).y!);

      node
        .attr("transform", d => `translate(${d.x},${d.y})`);
    });

    // Drag functions
    function dragstarted(event: any, d: NetworkNode) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }

    function dragged(event: any, d: NetworkNode) {
      d.fx = event.x;
      d.fy = event.y;
    }

    function dragended(event: any, d: NetworkNode) {
      if (!event.active) simulation.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }

    return () => {
      simulation.stop();
    };
  }, [data]);

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#1c1c1e] w-full max-w-4xl h-[80vh] rounded-[32px] shadow-2xl border border-white/10 flex flex-col overflow-hidden relative animate-scale-in">
        
        {/* Header */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-10 pointer-events-none">
          <div className="bg-black/40 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 pointer-events-auto">
            <h2 className="text-white font-bold text-sm flex items-center gap-2">
              <Share2 size={16} className="text-blue-400" />
              Topic Blueprint
            </h2>
          </div>
          <div className="flex gap-2 pointer-events-auto">
             <div className="bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    <span className="text-[10px] text-gray-300 font-medium">Discussed</span>
                </div>
                <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-gray-600 border border-gray-400"></div>
                    <span className="text-[10px] text-gray-300 font-medium">Pending</span>
                </div>
             </div>
             <button 
                onClick={onClose}
                className="w-9 h-9 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition-colors backdrop-blur-md"
             >
                <X size={20} />
             </button>
          </div>
        </div>

        {/* Graph Container */}
        <div ref={containerRef} className="w-full h-full bg-[#111] relative">
           <svg ref={svgRef} className="w-full h-full cursor-grab active:cursor-grabbing"></svg>
           
           {/* Zoom Controls */}
           <div className="absolute bottom-6 right-6 flex flex-col gap-2">
              <button className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md border border-white/10 transition-colors">
                  <ZoomIn size={20} />
              </button>
              <button className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md border border-white/10 transition-colors">
                  <ZoomOut size={20} />
              </button>
              <button className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md border border-white/10 transition-colors">
                  <Maximize size={20} />
              </button>
           </div>
        </div>

      </div>
    </div>
  );
};

export default TopicNetworkView;
