import React, { useState, useEffect, useRef } from 'react';
import { X, Upload, User as UserIcon, Briefcase, Sparkles, Check, Save, Settings, Plus, PenTool, Download, Loader, Zap, Star, Trash2, FileText as FileIcon, Folder, ChevronLeft, Brain } from 'lucide-react';
import { TeamMember, SkillItem, SkillForm } from '../types';
import { SKILL_STORE_DATA } from '../constants';
import { GoogleGenAI, Type } from "@google/genai";

interface AddBotModalProps {
  onClose: () => void;
  onSave: (member: TeamMember) => void;
  initialMember?: TeamMember | null;
}

const AddBotModal: React.FC<AddBotModalProps> = ({ onClose, onSave, initialMember }) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [instructions, setInstructions] = useState('');
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  // New Features State
  const [documents, setDocuments] = useState<string[]>([]);
  const [knowledgeKeywords, setKnowledgeKeywords] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isSkillModalOpen, setIsSkillModalOpen] = useState(false);
  const [skillForm, setSkillForm] = useState<SkillForm>({
    name: '', description: '', trigger: '', logic: '', 
    requiredParams: '', optionalParams: '', constraints: '', example: ''
  });

  const [installedSkills, setInstalledSkills] = useState<Set<string>>(new Set());
  const [installingSkillId, setInstallingSkillId] = useState<string | null>(null);
  
  const [isBrainModalOpen, setIsBrainModalOpen] = useState(false);
  const [viewingSkill, setViewingSkill] = useState<SkillItem | null>(null);

  // Load initial data if editing
  useEffect(() => {
    if (initialMember) {
      setName(initialMember.name);
      setRole(initialMember.role);
      setInstructions(initialMember.instruction);
      setAvatarPreview(initialMember.avatar);
      setDocuments(initialMember.documents || []);
      setKnowledgeKeywords(initialMember.knowledgeKeywords || []);
      setInstalledSkills(new Set(initialMember.installedSkillIds || []));
    }
  }, [initialMember]);

  const handleSaveAction = () => {
    const newMember: TeamMember = {
        id: initialMember ? initialMember.id : `custom_${Date.now()}`,
        name,
        role,
        avatar: avatarPreview || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&h=200&fit=crop',
        instruction: instructions,
        documents,
        knowledgeKeywords,
        installedSkillIds: Array.from(installedSkills)
    };
    onSave(newMember);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const text = await file.text();
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `
        You are an expert system architect and knowledge engineer. 
        Analyze the following uploaded knowledge document: "${file.name}".
        
        Task:
        1. Extract the core skills, rules, workflows, or knowledge points.
        2. Identify 3-5 concise, high-value keywords or tags that describe the expertise in this document (e.g., "Python", "Crisis Mgmt", "Agile").
        3. Format the output as a JSON object.

        Document Content (truncated):
        ${text.slice(0, 15000)} 
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
           responseMimeType: 'application/json',
           responseSchema: {
              type: Type.OBJECT,
              properties: {
                 knowledgeSummary: { type: Type.STRING },
                 keywords: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
           }
        }
      });

      const result = JSON.parse(response.text || '{}');
      const newKnowledge = result.knowledgeSummary || `*Processed content of ${file.name}*`;
      const newKeywords = result.keywords || [];

      setInstructions(prev => {
         const header = `\n\n### Learned Knowledge [${file.name}]\n`;
         return `${prev}${header}${newKnowledge}`;
      });
      
      setDocuments(prev => [...prev, file.name]);
      setKnowledgeKeywords(prev => Array.from(new Set([...prev, ...newKeywords])));

    } catch (error) {
      console.error("Upload failed", error);
      alert("Failed to process document. Please try again.");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSkillSubmit = () => {
    const formattedSkill = `
### Defined Skill: ${skillForm.name || 'Untitled_Skill'}
- **Description**: ${skillForm.description}
- **Trigger**: ${skillForm.trigger}
- **Core Logic**:
${skillForm.logic}
- **Parameters**:
  * Required: ${skillForm.requiredParams}
  * Optional: ${skillForm.optionalParams}
- **Constraints**: ${skillForm.constraints}
- **Few-Shot Example**: ${skillForm.example}
`;
    
    setInstructions(prev => prev.trim() + "\n" + formattedSkill);
    setIsSkillModalOpen(false);
    setSkillForm({
        name: '', description: '', trigger: '', logic: '', 
        requiredParams: '', optionalParams: '', constraints: '', example: ''
    });
  };

  const handleMarketInstall = (item: SkillItem) => {
      setInstallingSkillId(item.id);
      setTimeout(() => {
          setInstructions(prev => {
              const installBlock = `\n\n### Installed Module: ${item.name}\n${item.fullDetail}`;
              return prev + installBlock;
          });
          setInstalledSkills(prev => new Set(prev).add(item.id));
          setInstallingSkillId(null);
      }, 1000);
  };

  const isEditing = !!initialMember;

  return (
    <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#1c1c1e]/90 backdrop-blur-2xl w-full max-w-lg rounded-[32px] shadow-2xl overflow-hidden animate-scale-in flex flex-col border border-white/10 ring-1 ring-white/5 h-[90vh]">
        
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex justify-between items-center bg-white/5 shrink-0">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles size={20} className="text-blue-400" />
            {isEditing ? 'Edit Profile' : 'Create Bot'}
          </h2>
          <div className="flex gap-2">
            <button 
                onClick={() => setIsBrainModalOpen(true)}
                className="w-8 h-8 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center shadow-sm text-white active:scale-90 transition-transform relative border border-white/20"
                title="MyBot Brain"
            >
                <Brain size={16} />
                {installedSkills.size > 0 && (
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full text-[8px] flex items-center justify-center font-bold border border-black">
                    {installedSkills.size}
                </span>
                )}
            </button>
            <button 
                onClick={onClose}
                className="w-8 h-8 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white/70 transition-colors"
            >
                <X size={20} />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 custom-scrollbar">
          
          {/* Avatar Upload */}
          <div className="flex flex-col items-center gap-3">
             <div className="relative group cursor-pointer">
                 <div className="w-24 h-24 rounded-full bg-white/5 border-2 border-dashed border-white/20 flex items-center justify-center overflow-hidden hover:border-blue-500/50 transition-colors">
                    {avatarPreview ? (
                        <img src={avatarPreview} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                        <UserIcon size={32} className="text-white/20 group-hover:text-white/40" />
                    )}
                 </div>
                 <div className="absolute bottom-0 right-0 p-2 bg-blue-500 rounded-full shadow-lg border border-[#1c1c1e]">
                    <Upload size={14} className="text-white" />
                 </div>
                 <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleImageUpload} accept="image/*" />
             </div>
             <span className="text-[10px] text-gray-500 font-medium">{isEditing ? 'Change Avatar' : 'Upload Avatar'}</span>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">Name</label>
                <div className="bg-black/40 rounded-xl border border-white/10 flex items-center px-3 focus-within:border-blue-500/50 transition-colors">
                    <input 
                        type="text" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Architect Bot"
                        className="w-full bg-transparent h-10 text-sm text-white placeholder-gray-600 outline-none font-medium"
                    />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">Role / Expertise</label>
                <div className="bg-black/40 rounded-xl border border-white/10 flex items-center px-3 focus-within:border-blue-500/50 transition-colors">
                    <Briefcase size={16} className="text-gray-500 mr-2" />
                    <input 
                        type="text" 
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                        placeholder="e.g. Python Backend Developer"
                        className="w-full bg-transparent h-10 text-sm text-white placeholder-gray-600 outline-none font-medium"
                    />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">System Instructions</label>
                <textarea 
                    value={instructions}
                    onChange={(e) => setInstructions(e.target.value)}
                    placeholder="Describe how this bot should behave, its tone, and specific knowledge..."
                    className="w-full bg-black/40 rounded-xl border border-white/10 p-3 text-sm text-white placeholder-gray-600 outline-none min-h-[80px] resize-none focus:border-blue-500/50 transition-colors"
                />
              </div>
          </div>

          {/* Bento Grid for Advanced Config */}
          <div className="grid grid-cols-2 gap-3">
              {/* Upload Knowledge */}
              <div className="col-span-1 bg-indigo-500/10 border-2 border-dashed border-indigo-400/30 rounded-[24px] p-4 flex flex-col relative group transition-colors hover:bg-indigo-500/20 hover:border-indigo-400/50 h-36 overflow-hidden">
                 <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept=".md,.txt,.json,.csv"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                    disabled={isUploading}
                 />
                 {isUploading ? (
                    <div className="flex flex-col items-center justify-center h-full animate-pulse">
                        <Loader size={20} className="text-indigo-400 animate-spin mb-1" />
                        <span className="text-[10px] font-bold text-indigo-300">Analyzing...</span>
                    </div>
                 ) : knowledgeKeywords.length > 0 ? (
                    <div className="flex flex-col h-full w-full relative z-10 pointer-events-none">
                         <div className="flex justify-between items-start mb-2 pointer-events-none">
                            <h3 className="text-xs font-bold text-indigo-300 flex items-center gap-1">
                                <Zap size={10} className="text-indigo-400"/> Learned
                            </h3>
                            <div className="bg-white/10 p-1.5 rounded-full"><Upload size={10} className="text-indigo-300"/></div>
                         </div>
                         <div className="flex-1 flex flex-wrap content-start gap-1.5 overflow-hidden">
                            {knowledgeKeywords.slice(0, 3).map((k, i) => (
                               <span key={i} className="text-[8px] bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 px-1.5 py-0.5 rounded-md shadow-sm font-semibold">
                                   {k}
                               </span>
                            ))}
                            {knowledgeKeywords.length > 3 && (
                                <span className="text-[8px] bg-indigo-500/30 text-indigo-200 px-1.5 py-0.5 rounded-md font-bold">
                                    +{knowledgeKeywords.length - 3}
                                </span>
                            )}
                         </div>
                         <div className="mt-auto text-[8px] text-indigo-400/80 text-center w-full">
                             {documents.length} docs active
                         </div>
                    </div>
                 ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center">
                        <div className="w-8 h-8 bg-white/10 rounded-full shadow-sm flex items-center justify-center text-indigo-300 mb-2 group-hover:scale-110 transition-transform border border-white/5">
                            <Upload size={16} />
                        </div>
                        <h3 className="text-xs font-bold text-indigo-200 leading-tight">Upload Knowledge</h3>
                        <p className="text-[8px] text-indigo-400 mt-1">.md, .txt support</p>
                    </div>
                 )}
              </div>

              {/* Define Skill */}
              <div 
                 onClick={() => setIsSkillModalOpen(true)}
                 className="col-span-1 bg-black/40 rounded-[24px] p-4 flex flex-col justify-between relative overflow-hidden h-36 shadow-lg border border-white/10 group cursor-pointer hover:bg-black/50 transition-colors"
              >
                 <div className="flex items-center gap-2 z-10">
                     <div className="p-1.5 bg-white/10 rounded-lg text-green-400 group-hover:bg-white/15 transition-colors border border-white/5">
                        <Settings size={14} />
                     </div>
                     <span className="text-[9px] font-bold text-white/40 uppercase tracking-wider">Skills</span>
                 </div>

                 <div className="z-10 mt-2">
                     <h3 className="text-sm font-bold text-white leading-tight">Define<br/>New Skill</h3>
                     <p className="text-[8px] text-gray-400 mt-1">Triggers & Logic</p>
                 </div>

                 <div className="absolute bottom-3 right-3 bg-green-500 text-white p-1.5 rounded-full shadow-lg group-hover:scale-110 transition-transform z-20 shadow-green-900/30">
                     <Plus size={14} />
                 </div>
                 
                 <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/10 rounded-full blur-2xl -mr-8 -mt-8 pointer-events-none"></div>
                 <div className="absolute bottom-0 left-0 w-16 h-16 bg-blue-500/10 rounded-full blur-xl -ml-5 -mb-5 pointer-events-none"></div>
              </div>

              {/* Skill Store */}
              <div className="col-span-2 bg-white/5 rounded-[24px] p-1 shadow-xl border border-white/10 h-[300px] flex flex-col backdrop-blur-md">
                 <div className="px-4 py-3 border-b border-white/5 flex justify-between items-center">
                    <div>
                        <h3 className="font-bold text-white text-xs">Skill Store</h3>
                        <p className="text-[9px] text-white/40">Discover trending open-source agents</p>
                    </div>
                    <div className="bg-blue-500/20 text-blue-300 border border-blue-500/30 px-2 py-0.5 rounded-md text-[9px] font-bold flex items-center gap-1">
                        <Star size={8} className="fill-blue-300" />
                        Top Rated
                    </div>
                 </div>
                 
                 <div className="flex-1 overflow-y-auto p-3 space-y-2 no-scrollbar">
                    {SKILL_STORE_DATA.map((skill, index) => {
                        const isInstalled = installedSkills.has(skill.id);
                        const isInstalling = installingSkillId === skill.id;
                        const colors = ['bg-orange-500', 'bg-blue-500', 'bg-purple-500', 'bg-green-500', 'bg-pink-500'];
                        const iconColor = colors[index % colors.length];

                        return (
                            <div key={skill.id} className="bg-white/5 border border-white/5 rounded-xl p-2.5 flex items-center gap-3 hover:bg-white/10 transition-colors group">
                                <div className={`w-8 h-8 rounded-lg ${iconColor} flex items-center justify-center text-white shadow-lg shrink-0`}>
                                    <span className="font-bold text-[10px]">{skill.name.slice(0, 2).toUpperCase()}</span>
                                </div>
                                
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                        <h4 className="text-xs font-bold text-white truncate">{skill.name}</h4>
                                        <div className="flex items-center gap-0.5 text-[8px] text-yellow-400 bg-yellow-400/10 px-1 py-0.5 rounded border border-yellow-400/20">
                                            <Star size={6} className="fill-yellow-400" />
                                            {(skill.stars / 1000).toFixed(1)}k
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 mt-0.5">
                                        <span className="text-[9px] text-gray-400 flex items-center gap-1">
                                            <UserIcon size={8} /> {skill.author}
                                        </span>
                                    </div>
                                    <p className="text-[9px] text-gray-400 mt-0.5 line-clamp-1">{skill.description}</p>
                                </div>

                                <button
                                    onClick={() => !isInstalled && handleMarketInstall(skill)}
                                    disabled={isInstalled || isInstalling}
                                    className={`
                                        px-2 py-1 rounded-full text-[9px] font-bold flex items-center gap-1 transition-all
                                        ${isInstalled 
                                            ? 'bg-green-500/20 text-green-400 border border-green-500/30 cursor-default' 
                                            : 'bg-white text-black hover:bg-gray-200 active:scale-95 shadow-md'
                                        }
                                    `}
                                >
                                    {isInstalling ? (
                                        <Loader size={10} className="animate-spin" />
                                    ) : isInstalled ? (
                                        <>
                                            <Check size={10} />
                                            <span>Added</span>
                                        </>
                                    ) : (
                                        <>
                                            <Download size={10} />
                                            <span>Install</span>
                                        </>
                                    )}
                                </button>
                            </div>
                        );
                    })}
                 </div>
              </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-5 border-t border-white/10 bg-white/5 shrink-0">
            <button 
                className={`w-full font-bold py-3.5 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 ${!name ? 'bg-white/10 text-gray-500 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-500/20 active:scale-95'}`}
                onClick={handleSaveAction}
                disabled={!name}
            >
                {isEditing ? <Save size={18} /> : <Check size={18} />}
                {isEditing ? 'Save Changes' : 'Create Member'}
            </button>
        </div>

      </div>

      {/* Manual Skill Definition Modal */}
      {isSkillModalOpen && (
        <div className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
           <div className="bg-[#1c1c1e] w-full max-w-md rounded-2xl shadow-2xl flex flex-col h-[85vh] animate-scale-in overflow-hidden border border-white/10">
              <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
                 <div>
                    <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
                       <PenTool size={16} className="text-blue-400"/>
                       Define Skill
                    </h2>
                    <p className="text-[10px] text-gray-400">Teach your bot new capabilities</p>
                 </div>
                 <button onClick={() => setIsSkillModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white">
                    <X size={20} />
                 </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Skill Name <span className="text-gray-600 font-normal">(Action_Object)</span></label>
                    <input 
                      type="text" 
                      placeholder="e.g. search_policy"
                      value={skillForm.name}
                      onChange={e => setSkillForm({...skillForm, name: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Description</label>
                    <input 
                      type="text" 
                      placeholder="What does this skill do?"
                      value={skillForm.description}
                      onChange={e => setSkillForm({...skillForm, description: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Trigger Scene</label>
                    <input 
                      type="text" 
                      placeholder="When user asks..."
                      value={skillForm.trigger}
                      onChange={e => setSkillForm({...skillForm, trigger: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Logic Steps</label>
                    <textarea 
                      placeholder="1. Extract keywords; 2. Query DB; 3. Format output."
                      value={skillForm.logic}
                      onChange={e => setSkillForm({...skillForm, logic: e.target.value})}
                      className="w-full h-24 bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors resize-none placeholder-gray-600"
                    />
                 </div>
                 <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="block text-xs font-bold text-gray-400 mb-1">Required Params</label>
                        <input 
                          type="text" 
                          placeholder="e.g. city: string"
                          value={skillForm.requiredParams}
                          onChange={e => setSkillForm({...skillForm, requiredParams: e.target.value})}
                          className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 placeholder-gray-600"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-400 mb-1">Optional Params</label>
                        <input 
                          type="text" 
                          placeholder="e.g. limit: 5"
                          value={skillForm.optionalParams}
                          onChange={e => setSkillForm({...skillForm, optionalParams: e.target.value})}
                          className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 placeholder-gray-600"
                        />
                    </div>
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Constraints</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Do not reveal private data..."
                      value={skillForm.constraints}
                      onChange={e => setSkillForm({...skillForm, constraints: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Few-Shot Example</label>
                    <div className="bg-black/20 border border-white/10 rounded-lg p-2">
                        <input 
                          type="text" 
                          placeholder='e.g. "Check weather" -> {"loc": "Beijing"}'
                          value={skillForm.example}
                          onChange={e => setSkillForm({...skillForm, example: e.target.value})}
                          className="w-full bg-transparent text-sm focus:outline-none font-mono text-gray-300 placeholder-gray-600"
                        />
                    </div>
                 </div>
              </div>

              <div className="p-4 border-t border-white/10 bg-white/5">
                 <button 
                    onClick={handleSkillSubmit} 
                    className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-blue-500 active:scale-95 transition-all flex items-center justify-center gap-2"
                 >
                    <Check size={18} />
                    <span>Confirm & Add Skill</span>
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* MyBot Brain (Skills Inspector) Modal */}
      {isBrainModalOpen && (
        <div className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-[#1c1c1e] w-full max-w-2xl rounded-2xl shadow-2xl flex flex-col h-[70vh] animate-scale-in overflow-hidden border border-white/10">
                <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5 shrink-0">
                    <div className="flex items-center gap-2">
                        {viewingSkill ? (
                             <button 
                                onClick={() => setViewingSkill(null)}
                                className="p-1 hover:bg-white/10 rounded-lg mr-1 transition-colors text-white"
                             >
                                <ChevronLeft size={20} />
                             </button>
                        ) : (
                             <Brain size={20} className="text-white" />
                        )}
                        <div>
                            <h2 className="text-sm font-bold text-white uppercase tracking-wide">
                                {viewingSkill ? viewingSkill.name : 'MyBot Brain'}
                            </h2>
                            <p className="text-[10px] text-gray-400">
                                {viewingSkill ? 'Inspect installed modules' : 'Manage installed skills'}
                            </p>
                        </div>
                    </div>
                    <button onClick={() => { setIsBrainModalOpen(false); setViewingSkill(null); }} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white">
                        <X size={20} />
                    </button>
                </div>
                
                <div className="flex-1 overflow-y-auto bg-black/20 p-5">
                    {viewingSkill ? (
                        <div className="space-y-4">
                            <div className="bg-white/5 p-4 rounded-xl border border-white/10 shadow-sm">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Skill Description</h3>
                                <p className="text-sm text-gray-300 leading-relaxed">{viewingSkill.description}</p>
                            </div>

                            {viewingSkill.keywords && (
                                <div className="bg-white/5 p-4 rounded-xl border border-white/10 shadow-sm">
                                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                                       <Zap size={14} className="text-orange-500" /> Capabilities
                                    </h3>
                                    <div className="flex flex-wrap gap-2">
                                        {viewingSkill.keywords.map((kw, i) => (
                                            <span key={i} className="px-3 py-1 bg-blue-500/20 text-blue-300 text-xs font-semibold rounded-full border border-blue-500/30">
                                                {kw}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <div>
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 ml-1">Modules & Files</h3>
                                <div className="bg-white/5 rounded-xl border border-white/10 shadow-sm overflow-hidden">
                                    {viewingSkill.modules.map((mod, idx) => (
                                        <div key={idx} className="flex items-center justify-between p-3 border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors cursor-default">
                                            <div className="flex items-center gap-3">
                                                <div className={`p-2 rounded-lg ${mod.type === 'folder' ? 'bg-blue-500/20 text-blue-400' : 'bg-white/10 text-gray-400'}`}>
                                                    {mod.type === 'folder' ? <Folder size={16} /> : <FileIcon size={16} />}
                                                </div>
                                                <div>
                                                    <div className="flex items-center gap-2">
                                                        <span className="font-mono text-sm text-white font-medium">{mod.name}</span>
                                                        {mod.tags && mod.tags.map((t, ti) => (
                                                            <span key={ti} className="text-[9px] px-1.5 py-0.5 bg-white/10 text-gray-400 rounded-md font-medium">{t}</span>
                                                        ))}
                                                    </div>
                                                    <div className="text-[10px] text-gray-500">{mod.desc}</div>
                                                </div>
                                            </div>
                                            {mod.size && <span className="text-[10px] text-gray-600 font-mono">{mod.size}</span>}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ) : (
                        installedSkills.size === 0 ? (
                            <div className="flex flex-col items-center justify-center h-full text-gray-500">
                                <Brain size={48} className="mb-4 opacity-20" />
                                <p className="text-sm">No skills installed yet.</p>
                                <p className="text-xs opacity-50 mt-1">Visit the Skill Store to add capabilities.</p>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 gap-3">
                                {SKILL_STORE_DATA.filter(s => installedSkills.has(s.id)).map(skill => (
                                    <div key={skill.id} onClick={() => setViewingSkill(skill)} className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center justify-between hover:bg-white/10 transition-colors cursor-pointer group">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs">
                                                {skill.name.slice(0, 2).toUpperCase()}
                                            </div>
                                            <div>
                                                <h3 className="text-sm font-bold text-white">{skill.name}</h3>
                                                <p className="text-[10px] text-gray-400">{skill.description}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <button 
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    const next = new Set(installedSkills);
                                                    next.delete(skill.id);
                                                    setInstalledSkills(next);
                                                }}
                                                className="p-2 bg-red-500/10 text-red-400 rounded-full hover:bg-red-500/20 transition-colors"
                                                title="Uninstall"
                                            >
                                                <Trash2 size={14} />
                                            </button>
                                            <ChevronLeft size={16} className="text-gray-600 rotate-180 group-hover:text-white transition-colors" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )
                    )}
                </div>
            </div>
        </div>
      )}

    </div>
  );
};

export default AddBotModal;
