import React, { useState } from 'react';
import { Search, Heart, MessageCircle, Share2, ArrowLeft, MoreHorizontal, Filter, Users, DollarSign, ShoppingBag, TrendingUp, CheckCircle, X } from 'lucide-react';

interface MarketItem {
  id: string;
  type: 'Prompt' | 'Skill' | 'Agent' | 'Mini App';
  title: string;
  image: string;
  author: {
    name: string;
    avatar: string;
    role: string;
  };
  price: number;
  rating: number;
  downloads: string;
  description: string;
  longDescription: string;
  tags: string[];
  features: string[];
}

const MARKET_ITEMS: MarketItem[] = [
  // Prompts
  {
    id: 'p1',
    type: 'Prompt',
    title: 'Midjourney V6 Photorealism',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&q=80',
    author: { name: 'ArtAI', avatar: 'https://i.pravatar.cc/150?u=20', role: 'Prompt Engineer' },
    price: 4.99,
    rating: 4.9,
    downloads: '12k',
    description: 'Generate hyper-realistic portraits with cinematic lighting.',
    longDescription: 'This master prompt is optimized for Midjourney V6 to produce indistinguishable-from-reality portraits. It includes parameters for lighting, camera lenses, and film stocks. Perfect for stock photography, character design, and advertising.',
    tags: ['Midjourney', 'Photography', 'Art'],
    features: ['Cinematic Lighting', '8k Resolution', 'Camera Controls', 'Style LoRAs']
  },
  {
    id: 'p2',
    type: 'Prompt',
    title: 'GPT-4 Code Refactor',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&q=80',
    author: { name: 'DevGuru', avatar: 'https://i.pravatar.cc/150?u=21', role: 'Senior Dev' },
    price: 9.99,
    rating: 4.8,
    downloads: '8.5k',
    description: 'Clean, optimize, and document your code automatically.',
    longDescription: 'Stop wasting time on technical debt. This system prompt turns GPT-4 into a senior code reviewer. It identifies anti-patterns, suggests performance optimizations, and writes JSDoc/Docstrings for every function.',
    tags: ['Coding', 'Productivity', 'GPT-4'],
    features: ['Clean Code', 'Documentation', 'Optimization', 'Bug Detection']
  },
  // Skills
  {
    id: 's1',
    type: 'Skill',
    title: 'Python Data Analysis',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&q=80',
    author: { name: 'DataWiz', avatar: 'https://i.pravatar.cc/150?u=22', role: 'Data Scientist' },
    price: 19.99,
    rating: 4.7,
    downloads: '5k',
    description: 'Equip your bot with Pandas and Matplotlib capabilities.',
    longDescription: 'This skill module allows your AI agent to execute Python code for data analysis. It can read CSV/Excel files, clean data, perform statistical analysis, and generate visualization charts on the fly.',
    tags: ['Python', 'Data', 'Visualization'],
    features: ['Pandas Support', 'Chart Generation', 'Statistical Models', 'Auto-Cleaning']
  },
  {
    id: 's2',
    type: 'Skill',
    title: 'Web Search & Scrape',
    image: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=600&q=80',
    author: { name: 'NetRunner', avatar: 'https://i.pravatar.cc/150?u=23', role: 'Full Stack' },
    price: 14.99,
    rating: 4.6,
    downloads: '15k',
    description: 'Give your agent real-time internet access.',
    longDescription: 'A robust skill for browsing the web. It handles Google searches, scrapes page content, summarizes articles, and bypasses basic anti-bot measures to get you the information you need.',
    tags: ['Web', 'Search', 'Automation'],
    features: ['Google Search', 'Content Extraction', 'Summarization', 'Source Citing']
  },
  // Agents
  {
    id: 'a1',
    type: 'Agent',
    title: 'Travel Planner Agent',
    image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=600&q=80',
    author: { name: 'Wanderlust', avatar: 'https://i.pravatar.cc/150?u=24', role: 'Travel Expert' },
    price: 29.99,
    rating: 4.9,
    downloads: '3k',
    description: 'Your personal AI travel concierge.',
    longDescription: 'This autonomous agent plans your entire trip. Tell it your budget and dates, and it will find flights, book hotels, create daily itineraries, and even make restaurant reservations. It integrates with Expedia and Airbnb APIs.',
    tags: ['Travel', 'Lifestyle', 'Planning'],
    features: ['Flight Booking', 'Itinerary Gen', 'Budget Tracking', 'Local Tips']
  },
  {
    id: 'a2',
    type: 'Agent',
    title: 'Research Assistant',
    image: 'https://images.unsplash.com/photo-1456324504439-367cee13d656?w=600&q=80',
    author: { name: 'ScholarAI', avatar: 'https://i.pravatar.cc/150?u=25', role: 'Researcher' },
    price: 49.99,
    rating: 4.8,
    downloads: '2.2k',
    description: 'Deep dive into any topic with academic rigor.',
    longDescription: 'An agent designed for students and academics. It searches Google Scholar, arXiv, and JSTOR to find relevant papers, summarizes key findings, and generates a literature review with proper citations.',
    tags: ['Education', 'Research', 'Academic'],
    features: ['Paper Search', 'Citation Gen', 'Summary', 'Fact Checking']
  },
  // Mini Apps
  {
    id: 'm1',
    type: 'Mini App',
    title: 'Daily Habit Tracker',
    image: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=600&q=80',
    author: { name: 'LifeHacker', avatar: 'https://i.pravatar.cc/150?u=26', role: 'Indie Hacker' },
    price: 2.99,
    rating: 4.5,
    downloads: '20k',
    description: 'A minimal app to build better habits.',
    longDescription: 'Track your daily habits with this beautiful, lightweight mini-app. Features streak tracking, detailed analytics, and motivational notifications. Runs directly in your AI OS dashboard.',
    tags: ['Productivity', 'Health', 'Lifestyle'],
    features: ['Streak Tracking', 'Dark Mode', 'Analytics', 'Reminders']
  },
  {
    id: 'm2',
    type: 'Mini App',
    title: 'Pomodoro Focus',
    image: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?w=600&q=80',
    author: { name: 'FocusFlow', avatar: 'https://i.pravatar.cc/150?u=27', role: 'Productivity' },
    price: 0.99,
    rating: 4.7,
    downloads: '35k',
    description: 'Boost productivity with the Pomodoro technique.',
    longDescription: 'A simple yet powerful timer app. Customize your work/break intervals, track your focus hours, and block distracting notifications while the timer is running.',
    tags: ['Productivity', 'Tools', 'Focus'],
    features: ['Custom Timer', 'Stats', 'Lo-Fi Music', 'Task Sync']
  }
];

const TAGS = ['All', 'Prompt', 'Skill', 'Agent', 'Mini App'];

interface MakerParkScreenProps {
  onBack: () => void;
  onConfigClick: () => void;
}

const ItemDetailView: React.FC<{ item: MarketItem; onBack: () => void; onConfigClick: () => void }> = ({ item, onBack, onConfigClick }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'reviews' | 'author'>('overview');

  return (
    <div className="w-full h-full bg-black text-white overflow-y-auto no-scrollbar flex flex-col animate-fade-in relative">
      
      {/* Hero Section with Parallax-like effect */}
      <div className="relative w-full h-[45vh] shrink-0">
        <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
        
        {/* Navbar Overlay */}
        <div className="absolute top-0 left-0 right-0 p-4 pt-safe-top flex justify-between items-center z-20">
          <button onClick={onBack} className="w-10 h-10 rounded-full bg-black/20 backdrop-blur-xl flex items-center justify-center border border-white/10 hover:bg-white/20 transition-colors active:scale-95">
            <ArrowLeft size={20} />
          </button>
          <div className="flex gap-2">
            <button className="w-10 h-10 rounded-full bg-black/20 backdrop-blur-xl flex items-center justify-center border border-white/10 hover:bg-white/20 transition-colors active:scale-95">
              <Share2 size={20} />
            </button>
            <button className="w-10 h-10 rounded-full bg-black/20 backdrop-blur-xl flex items-center justify-center border border-white/10 hover:bg-white/20 transition-colors active:scale-95">
              <MoreHorizontal size={20} />
            </button>
          </div>
        </div>

        {/* Title & Author */}
        <div className="absolute bottom-0 left-0 right-0 p-6 z-10">
          <div className="flex items-center gap-2 mb-3">
            <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-blue-500 text-white uppercase tracking-wider shadow-lg">
              {item.type}
            </span>
            {item.tags.slice(0, 2).map(tag => (
              <span key={tag} className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-white/10 backdrop-blur-md border border-white/10 uppercase tracking-wider shadow-lg">
                {tag}
              </span>
            ))}
          </div>
          <h1 className="text-3xl md:text-5xl font-black mb-3 leading-tight drop-shadow-lg tracking-tight">{item.title}</h1>
          <div className="flex items-center gap-3 bg-black/30 backdrop-blur-md p-2 rounded-full w-fit border border-white/5 pr-4">
            <img src={item.author.avatar} alt={item.author.name} className="w-8 h-8 rounded-full border border-white/20" />
            <div>
              <p className="text-xs font-bold text-white">{item.author.name}</p>
              <p className="text-[10px] text-gray-300">{item.author.role}</p>
            </div>
            <button className="ml-2 px-3 py-1 bg-white text-black text-[10px] font-bold rounded-full hover:bg-gray-200 transition-colors">
              Follow
            </button>
          </div>
        </div>
      </div>

      {/* Sticky Tabs */}
      <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-white/10 px-4 shadow-2xl">
        <div className="flex gap-8 overflow-x-auto no-scrollbar">
          {[
            { id: 'overview', label: 'Overview', icon: <CheckCircle size={14} /> },
            { id: 'reviews', label: 'Reviews', icon: <MessageCircle size={14} /> },
            { id: 'author', label: 'Author', icon: <Users size={14} /> },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-4 text-sm font-bold border-b-2 transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === tab.id 
                  ? 'border-white text-white' 
                  : 'border-transparent text-gray-500 hover:text-gray-300'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="p-6 pb-32 max-w-3xl mx-auto w-full min-h-[50vh]">
        
        {activeTab === 'overview' && (
          <div className="space-y-8 animate-fade-in-up">
            {/* Stats Card */}
            <div className="grid grid-cols-3 gap-4">
                <div className="bg-[#1c1c1e] p-4 rounded-2xl border border-white/10 text-center">
                    <div className="flex justify-center mb-2 text-yellow-400"><Heart size={20} fill="currentColor" /></div>
                    <div className="text-2xl font-black text-white">{item.rating}</div>
                    <div className="text-[10px] text-gray-500 uppercase font-bold">Rating</div>
                </div>
                <div className="bg-[#1c1c1e] p-4 rounded-2xl border border-white/10 text-center">
                    <div className="flex justify-center mb-2 text-blue-400"><ShoppingBag size={20} /></div>
                    <div className="text-2xl font-black text-white">{item.downloads}</div>
                    <div className="text-[10px] text-gray-500 uppercase font-bold">Downloads</div>
                </div>
                <div className="bg-[#1c1c1e] p-4 rounded-2xl border border-white/10 text-center">
                    <div className="flex justify-center mb-2 text-green-400"><DollarSign size={20} /></div>
                    <div className="text-2xl font-black text-white">${item.price}</div>
                    <div className="text-[10px] text-gray-500 uppercase font-bold">Price</div>
                </div>
            </div>

            {/* Description */}
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <span className="w-1 h-6 bg-blue-500 rounded-full"></span>
                Description
              </h2>
              <p className="text-gray-300 leading-relaxed text-base font-light">
                {item.longDescription}
              </p>
            </div>
            
            {/* Features Grid */}
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <span className="w-1 h-6 bg-purple-500 rounded-full"></span>
                Features
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {item.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-black/40 flex items-center justify-center border border-white/10 text-white">
                        <CheckCircle size={18} className="text-blue-400" />
                    </div>
                    <span className="text-sm font-bold text-gray-200">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
            <div className="text-center py-20 text-gray-500">
                <MessageCircle size={48} className="mx-auto mb-4 opacity-50" />
                <p>No reviews yet.</p>
            </div>
        )}

        {activeTab === 'author' && (
             <div className="text-center py-20 text-gray-500">
                <Users size={48} className="mx-auto mb-4 opacity-50" />
                <p>More from {item.author.name} coming soon.</p>
            </div>
        )}

      </div>

      {/* Floating Action Bar (Bottom) */}
      <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 w-[90%] max-w-md bg-[#1c1c1e]/80 backdrop-blur-2xl border border-white/10 p-2 rounded-[24px] shadow-[0_20px_40px_rgba(0,0,0,0.6)] flex items-center justify-between z-40 ring-1 ring-white/5">
        <div className="flex items-center gap-3 px-4">
           <div className="flex flex-col">
              <span className="text-[10px] text-gray-400 uppercase tracking-wider font-bold">Total</span>
              <div className="flex items-baseline gap-1">
                  <span className="text-xl font-black text-white">${item.price}</span>
              </div>
           </div>
        </div>
        <button className="bg-white text-black px-8 py-3.5 rounded-[20px] font-black text-sm hover:bg-gray-200 transition-all shadow-lg active:scale-95 transform flex items-center gap-2">
          {item.price > 0 ? 'Buy Now' : 'Get Free'} <ArrowLeft size={16} className="rotate-180" />
        </button>
      </div>

    </div>
  );
};

const MakerParkScreen: React.FC<MakerParkScreenProps> = ({ onBack, onConfigClick }) => {
  const [activeTag, setActiveTag] = useState('All');
  const [selectedItem, setSelectedItem] = useState<MarketItem | null>(null);

  const filteredItems = activeTag === 'All' 
    ? MARKET_ITEMS 
    : MARKET_ITEMS.filter(item => item.type === activeTag || item.tags.includes(activeTag));

  if (selectedItem) {
    return <ItemDetailView item={selectedItem} onBack={() => setSelectedItem(null)} onConfigClick={onConfigClick} />;
  }

  return (
    <div className="w-full h-full bg-black text-white overflow-hidden flex flex-col">
      {/* Header */}
      <div className="px-4 py-3 flex items-center gap-3 bg-black/80 backdrop-blur-md z-10 border-b border-white/10">
        <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft size={24} />
        </button>
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search for prompts, skills, agents..." 
            className="w-full bg-[#1c1c1e] text-white pl-10 pr-4 py-2.5 rounded-full border-none focus:ring-2 focus:ring-white/20 outline-none text-sm font-medium"
          />
        </div>
        <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
          <Filter size={24} />
        </button>
      </div>

      {/* Tags */}
      <div className="px-4 py-2 flex gap-2 overflow-x-auto no-scrollbar bg-black/80 backdrop-blur-md z-10 pb-4">
        {TAGS.map(tag => (
          <button
            key={tag}
            onClick={() => setActiveTag(tag)}
            className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-colors ${
              activeTag === tag 
                ? 'bg-white text-black' 
                : 'bg-[#1c1c1e] text-gray-300 hover:bg-[#2c2c2e]'
            }`}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Masonry Grid */}
      <div className="flex-1 overflow-y-auto px-2 pb-20 no-scrollbar">
        <div className="columns-2 md:columns-3 lg:columns-4 gap-2 space-y-2">
          {filteredItems.map((item) => (
            <div key={item.id} className="break-inside-avoid mb-2 group relative" onClick={() => setSelectedItem(item)}>
              <div className="bg-[#1c1c1e] rounded-xl overflow-hidden shadow-lg hover:shadow-white/5 transition-all duration-300 cursor-pointer">
                {/* Image */}
                <div className="relative overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors"></div>
                  
                  {/* Type Badge */}
                  <div className="absolute top-2 left-2">
                     <span className="px-2 py-1 rounded-md text-[10px] font-bold bg-black/50 backdrop-blur-md text-white border border-white/10 uppercase tracking-wider">
                        {item.type}
                     </span>
                  </div>

                  {/* Overlay Actions */}
                  <div className="absolute top-2 right-2 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                     <button 
                        onClick={(e) => { e.stopPropagation(); }}
                        className="p-2 bg-red-500 rounded-full text-white shadow-lg hover:scale-110 transition-transform"
                     >
                        <Heart size={16} fill="white" />
                     </button>
                     <button 
                        onClick={(e) => { e.stopPropagation(); }}
                        className="p-2 bg-white/20 backdrop-blur-md rounded-full text-white shadow-lg hover:bg-white/40 transition-colors"
                     >
                        <MoreHorizontal size={16} />
                     </button>
                  </div>
                  
                  {/* Bottom Gradient for Text Readability */}
                  <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-black/80 to-transparent opacity-60"></div>
                </div>

                {/* Content */}
                <div className="p-3">
                  <h3 className="text-sm font-bold text-gray-100 mb-1 leading-tight">{item.title}</h3>
                  
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-1.5">
                      <img src={item.author.avatar} alt={item.author.name} className="w-5 h-5 rounded-full bg-gray-700" />
                      <span className="text-[10px] text-gray-400 font-medium">{item.author.name}</span>
                    </div>
                    <div className="flex items-center gap-1 text-gray-500">
                      <span className="text-xs font-bold text-white">${item.price}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MakerParkScreen;
