
import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Save, Shuffle, Check, ChevronRight, Upload, Loader, Trash2, Settings, Plus, X, PenTool, Code, Layout, Users, Megaphone, Download, Package, FileCode, Brain, Folder, FileText as FileIcon, ChevronLeft, Zap, Hash, Star, GitFork, User } from 'lucide-react';
import { BotConfig } from '../types';
import { GoogleGenAI, Type } from "@google/genai";

interface ConfigScreenProps {
  currentConfig: BotConfig;
  onSave: (config: BotConfig) => void;
  onBack: () => void;
}

interface MarketModule {
  name: string;
  type: 'file' | 'folder';
  desc: string;
  size?: string;
  tags?: string[]; // Added tags for file modules
}

interface SkillItem {
  id: string;
  name: string; 
  description: string; 
  author: string;
  stars: number;
  downloads: string;
  fullDetail: string; // Content to inject into bot memory
  modules: MarketModule[]; // Virtual file system for "Brain" view
  keywords?: string[]; // Core capability tags
}

interface SkillForm {
  name: string;
  description: string;
  trigger: string;
  logic: string;
  requiredParams: string;
  optionalParams: string;
  constraints: string;
  example: string;
}

// Mock Data based on popular open-source skills
const SKILL_STORE_DATA: SkillItem[] = [
  {
    id: 'browser-use',
    name: 'browser-use',
    author: 'gregpr07',
    stars: 18400,
    downloads: '120k+',
    description: 'Control a headless browser to automate web tasks, scraping, and testing.',
    fullDetail: 'Integrated Browser Use: Capable of controlling a headless browser for navigation, clicking, typing, and data extraction.',
    keywords: ['Automation', 'Puppeteer', 'Web Scraping', 'Testing'],
    modules: [
        { name: 'browser_core.py', type: 'file', desc: 'Main controller', size: '45KB', tags: ['Python', 'Core'] },
        { name: 'dom_parser.js', type: 'file', desc: 'Page interaction', size: '12KB', tags: ['JS', 'DOM'] }
    ]
  },
  {
    id: 'auto-gpt-researcher',
    name: 'gpt-researcher',
    author: 'assafelovic',
    stars: 14200,
    downloads: '95k+',
    description: 'Autonomous research agent that aggregates sources and summarizes findings.',
    fullDetail: 'Integrated GPT Researcher: Performs deep online research, aggregates multiple sources, and generates comprehensive reports.',
    keywords: ['Research', 'Analysis', 'Report Gen', 'Multi-source'],
    modules: [
        { name: 'scraper', type: 'folder', desc: 'Web scrapers' },
        { name: 'report_gen.py', type: 'file', desc: 'Summary logic', size: '28KB' }
    ]
  },
  {
    id: 'baby-agi',
    name: 'babyagi',
    author: 'yoheinakajima',
    stars: 12500,
    downloads: '88k+',
    description: 'Task planning and execution loop for autonomous goal achievement.',
    fullDetail: 'Integrated BabyAGI: Break down complex goals into tasks, prioritize them, and execute in a loop.',
    keywords: ['Planning', 'Task Mgmt', 'Loop', 'Autonomous'],
    modules: [
        { name: 'task_queue.py', type: 'file', desc: 'Priority queue', size: '8KB' },
        { name: 'execution_agent.py', type: 'file', desc: 'Worker', size: '14KB' }
    ]
  },
  {
    id: 'open-interpreter',
    name: 'open-interpreter',
    author: 'KillianLucas',
    stars: 11800,
    downloads: '150k+',
    description: 'Let LLMs run code (Python, Javascript, Shell) locally on your machine.',
    fullDetail: 'Integrated Open Interpreter: Executes local code snippets in a secure sandbox environment.',
    keywords: ['Code Execution', 'Local', 'Python', 'Shell'],
    modules: [
        { name: 'interpreter_core', type: 'folder', desc: 'Runtime env' },
        { name: 'safe_mode.py', type: 'file', desc: 'Security sandbox', size: '12KB' }
    ]
  },
  {
    id: 'crewai',
    name: 'crewAI',
    author: 'joaomdmoura',
    stars: 10500,
    downloads: '70k+',
    description: 'Orchestrate role-playing autonomous AI agents for complex tasks.',
    fullDetail: 'Integrated CrewAI: Orchestrate multiple sub-agents with specific roles to solve complex problems.',
    keywords: ['Multi-Agent', 'Orchestration', 'Roleplay', 'Workflow'],
    modules: [
        { name: 'crew.py', type: 'file', desc: 'Team manager', size: '20KB' },
        { name: 'agent_def.json', type: 'file', desc: 'Role definitions', size: '4KB' }
    ]
  },
  {
    id: 'memgpt',
    name: 'MemGPT',
    author: 'cpacker',
    stars: 9200,
    downloads: '45k+',
    description: 'Virtual operating system memory management for unbounded context.',
    fullDetail: 'Integrated MemGPT: Managing long-term memory via paging and hierarchical storage.',
    keywords: ['Memory', 'Context Window', 'Long-term', 'State'],
    modules: [
        { name: 'memory_core', type: 'folder', desc: 'Storage logic' },
        { name: 'paging.py', type: 'file', desc: 'Context swapping', size: '18KB' }
    ]
  },
  {
    id: 'chatdev',
    name: 'ChatDev',
    author: 'OpenBMB',
    stars: 8900,
    downloads: '60k+',
    description: 'Virtual software company where agents collaborate to build software.',
    fullDetail: 'Integrated ChatDev: Simulates a software company structure (CEO, CTO, Programmer) to build software.',
    keywords: ['Software Dev', 'Collaboration', 'Coding', 'Simulation'],
    modules: [
        { name: 'company_config.json', type: 'file', desc: 'Role setup', size: '5KB' },
        { name: 'phase_manager.py', type: 'file', desc: 'Waterflow process', size: '22KB' }
    ]
  },
  {
    id: 'metagpt',
    name: 'MetaGPT',
    author: 'geekan',
    stars: 8400,
    downloads: '55k+',
    description: 'Multi-agent framework: Given one line requirement, return PRD, Design, Code.',
    fullDetail: 'Integrated MetaGPT: Standardized SOPs for multi-agent software generation.',
    keywords: ['SOP', 'PRD', 'Code Gen', 'Productivity'],
    modules: [
        { name: 'sop_roles', type: 'folder', desc: 'Standard Procedures' },
        { name: 'architect.py', type: 'file', desc: 'System design', size: '16KB' }
    ]
  },
  {
    id: 'autogen',
    name: 'AutoGen',
    author: 'microsoft',
    stars: 7800,
    downloads: '200k+',
    description: 'Enabling next-gen LLM applications with multi-agent conversation.',
    fullDetail: 'Integrated AutoGen: Conversational framework for multi-agent collaboration.',
    keywords: ['Conversation', 'Microsoft', 'Multi-Agent', 'Enterprise'],
    modules: [
        { name: 'conversable_agent.py', type: 'file', desc: 'Base class', size: '25KB' },
        { name: 'group_chat.py', type: 'file', desc: 'Manager', size: '15KB' }
    ]
  }
];

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
  'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=200&h=200&fit=crop',
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop',
  'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&h=200&fit=crop',
  'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop',
];

const ConfigScreen: React.FC<ConfigScreenProps> = ({ currentConfig, onSave, onBack }) => {
  const [name, setName] = useState(currentConfig.name);
  const [avatar, setAvatar] = useState(currentConfig.avatar);
  const [previewInstruction, setPreviewInstruction] = useState(currentConfig.systemInstruction);
  
  // Documents State
  const [documents, setDocuments] = useState<string[]>(currentConfig.documents || []);
  const [knowledgeKeywords, setKnowledgeKeywords] = useState<string[]>(currentConfig.knowledgeKeywords || []);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Skill Modal State (Custom Form)
  const [isSkillModalOpen, setIsSkillModalOpen] = useState(false);
  const [skillForm, setSkillForm] = useState<SkillForm>({
    name: '',
    description: '',
    trigger: '',
    logic: '',
    requiredParams: '',
    optionalParams: '',
    constraints: '',
    example: ''
  });

  // Marketplace State
  const [installedSkills, setInstalledSkills] = useState<Set<string>>(new Set(currentConfig.installedSkillIds || []));
  const [installingSkillId, setInstallingSkillId] = useState<string | null>(null);

  // Source View State
  const [isSourceModalOpen, setIsSourceModalOpen] = useState(false);

  // Brain View State
  const [isBrainModalOpen, setIsBrainModalOpen] = useState(false);
  const [viewingSkill, setViewingSkill] = useState<SkillItem | null>(null);

  const handleSave = () => {
    onSave({
      name,
      avatar,
      systemInstruction: previewInstruction,
      documents,
      installedSkillIds: Array.from(installedSkills),
      knowledgeKeywords
    });
  };

  const randomizeAvatar = () => {
    const random = AVATAR_PRESETS[Math.floor(Math.random() * AVATAR_PRESETS.length)];
    setAvatar(random);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const text = await file.text();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `
        You are an expert system architect and knowledge engineer. 
        Analyze the following uploaded knowledge document: "${file.name}".
        
        Task:
        1. Extract the core skills, rules, workflows, or knowledge points.
        2. Identify 3-5 concise, high-value keywords or tags that describe the expertise in this document (e.g., "Python", "Crisis Mgmt", "Agile").
        3. Format the output as a JSON object.

        Document Content (truncated):
        ${text.slice(0, 15000)} 
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
           responseMimeType: 'application/json',
           responseSchema: {
              type: Type.OBJECT,
              properties: {
                 knowledgeSummary: { type: Type.STRING },
                 keywords: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
           }
        }
      });

      const result = JSON.parse(response.text || '{}');
      const newKnowledge = result.knowledgeSummary || `*Processed content of ${file.name}*`;
      const newKeywords = result.keywords || [];

      setPreviewInstruction(prev => {
         const header = `\n\n### Learned Knowledge [${file.name}]\n`;
         return `${prev}${header}${newKnowledge}`;
      });
      
      setDocuments(prev => [...prev, file.name]);
      setKnowledgeKeywords(prev => Array.from(new Set([...prev, ...newKeywords])));

    } catch (error) {
      console.error("Upload failed", error);
      alert("Failed to process document. Please try again.");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSkillSubmit = () => {
    const formattedSkill = `
### Defined Skill: ${skillForm.name || 'Untitled_Skill'}
- **Description**: ${skillForm.description}
- **Trigger**: ${skillForm.trigger}
- **Core Logic**:
${skillForm.logic}
- **Parameters**:
  * Required: ${skillForm.requiredParams}
  * Optional: ${skillForm.optionalParams}
- **Constraints**: ${skillForm.constraints}
- **Few-Shot Example**: ${skillForm.example}
`;
    
    setPreviewInstruction(prev => prev.trim() + "\n" + formattedSkill);
    setIsSkillModalOpen(false);
    // Reset form
    setSkillForm({
        name: '', description: '', trigger: '', logic: '', 
        requiredParams: '', optionalParams: '', constraints: '', example: ''
    });
  };

  const handleMarketInstall = (item: SkillItem) => {
      setInstallingSkillId(item.id);
      
      // Simulate network delay
      setTimeout(() => {
          setPreviewInstruction(prev => {
              const installBlock = `\n\n### Installed Module: ${item.name}\n${item.fullDetail}`;
              return prev + installBlock;
          });
          setInstalledSkills(prev => new Set(prev).add(item.id));
          setInstallingSkillId(null);
      }, 1000);
  };

  // Helper to find installed skill objects
  const getInstalledSkillObjects = () => {
    return SKILL_STORE_DATA.filter(item => installedSkills.has(item.id));
  };

  return (
    <div className="w-full h-full bg-black/60 backdrop-blur-3xl flex flex-col relative z-50 animate-fade-in font-sans">
      {/* Header */}
      <div className="px-6 py-4 flex items-center justify-between z-10 shrink-0 border-b border-white/5 bg-white/5">
        <button 
          onClick={onBack}
          className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center shadow-sm text-white active:scale-90 transition-transform border border-white/10"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-lg font-bold text-white tracking-wide">Bot Configuration</h1>
        <div className="flex gap-2">
            <button 
              onClick={() => setIsSourceModalOpen(true)}
              className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center shadow-sm text-blue-400 active:scale-90 transition-transform border border-white/10"
              title="View Source"
            >
              <FileCode size={20} />
            </button>
            <button 
              onClick={() => setIsBrainModalOpen(true)}
              className="w-10 h-10 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center shadow-sm text-white active:scale-90 transition-transform relative border border-white/20"
              title="MyBot Brain"
            >
              <Brain size={20} />
              {installedSkills.size > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[9px] flex items-center justify-center font-bold border border-black">
                    {installedSkills.size}
                </span>
              )}
            </button>
        </div>
      </div>

      {/* Bento Grid Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar">
        <div className="p-4 grid grid-cols-2 gap-3 pb-32">
          
          {/* 1. Identity Card (Full Width) */}
          <div className="col-span-2 bg-white/5 rounded-[32px] p-5 shadow-xl border border-white/10 flex items-center gap-5 relative overflow-hidden backdrop-blur-md">
             <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
             
             <div className="relative group shrink-0">
                <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-white/20 shadow-lg ring-1 ring-white/10">
                    <img src={avatar} alt="Bot Avatar" className="w-full h-full object-cover bg-black/40" />
                </div>
                <button 
                    onClick={randomizeAvatar}
                    className="absolute bottom-0 right-0 bg-white/20 text-white p-1.5 rounded-full shadow-lg backdrop-blur-md hover:bg-white/30 active:scale-90 transition-all border border-white/20"
                >
                    <Shuffle size={12} />
                </button>
             </div>
             
             <div className="flex-1 z-10">
                <label className="text-[10px] font-bold text-white/40 uppercase tracking-wider mb-1 block">Bot Identity</label>
                <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-transparent text-2xl font-bold text-white focus:outline-none placeholder-white/20 border-b border-transparent focus:border-white/20 transition-colors"
                    placeholder="Name"
                />
             </div>
          </div>

          {/* 2. Upload Knowledge (Left Col) */}
          <div className="col-span-1 bg-indigo-500/10 border-2 border-dashed border-indigo-400/30 rounded-[28px] p-4 flex flex-col relative group transition-colors hover:bg-indigo-500/20 hover:border-indigo-400/50 h-40 overflow-hidden">
             <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept=".md,.txt,.json,.csv"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                disabled={isUploading}
             />
             {isUploading ? (
                <div className="flex flex-col items-center justify-center h-full animate-pulse">
                    <Loader size={24} className="text-indigo-400 animate-spin mb-1" />
                    <span className="text-[10px] font-bold text-indigo-300">Analyzing...</span>
                </div>
             ) : knowledgeKeywords.length > 0 ? (
                <div className="flex flex-col h-full w-full relative z-10 pointer-events-none">
                     <div className="flex justify-between items-start mb-2 pointer-events-none">
                        <h3 className="text-xs font-bold text-indigo-300 flex items-center gap-1">
                            <Zap size={10} className="text-indigo-400"/> Learned
                        </h3>
                        <div className="bg-white/10 p-1.5 rounded-full"><Upload size={10} className="text-indigo-300"/></div>
                     </div>
                     <div className="flex-1 flex flex-wrap content-start gap-1.5 overflow-hidden">
                        {knowledgeKeywords.slice(0, 5).map((k, i) => (
                           <span key={i} className="text-[8px] bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 px-1.5 py-0.5 rounded-md shadow-sm font-semibold">
                               {k}
                           </span>
                        ))}
                        {knowledgeKeywords.length > 5 && (
                            <span className="text-[8px] bg-indigo-500/30 text-indigo-200 px-1.5 py-0.5 rounded-md font-bold">
                                +{knowledgeKeywords.length - 5}
                            </span>
                        )}
                     </div>
                     <div className="mt-auto text-[8px] text-indigo-400/80 text-center w-full">
                         {documents.length} docs active
                     </div>
                </div>
             ) : (
                <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="w-10 h-10 bg-white/10 rounded-full shadow-sm flex items-center justify-center text-indigo-300 mb-2 group-hover:scale-110 transition-transform border border-white/5">
                        <Upload size={20} />
                    </div>
                    <h3 className="text-xs font-bold text-indigo-200 leading-tight">Upload Knowledge</h3>
                    <p className="text-[9px] text-indigo-400 mt-1">.md, .txt support</p>
                </div>
             )}
          </div>

          {/* 3. Set Bot / Skill Builder (Right Col) */}
          <div 
             onClick={() => setIsSkillModalOpen(true)}
             className="col-span-1 bg-black/40 rounded-[28px] p-4 flex flex-col justify-between relative overflow-hidden h-40 shadow-lg border border-white/10 group cursor-pointer hover:bg-black/50 transition-colors"
          >
             <div className="flex items-center gap-2 z-10">
                 <div className="p-2 bg-white/10 rounded-lg text-green-400 group-hover:bg-white/15 transition-colors border border-white/5">
                    <Settings size={18} />
                 </div>
                 <span className="text-[10px] font-bold text-white/40 uppercase tracking-wider">Skills</span>
             </div>

             <div className="z-10 mt-2">
                 <h3 className="text-xl font-bold text-white leading-tight">Define<br/>New Skill</h3>
                 <p className="text-[9px] text-gray-400 mt-1">Triggers & Logic</p>
             </div>

             <div className="absolute bottom-3 right-3 bg-green-500 text-white p-2 rounded-full shadow-lg group-hover:scale-110 transition-transform z-20 shadow-green-900/30">
                 <Plus size={16} />
             </div>
             
             <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/10 rounded-full blur-2xl -mr-8 -mt-8 pointer-events-none"></div>
             <div className="absolute bottom-0 left-0 w-16 h-16 bg-blue-500/10 rounded-full blur-xl -ml-5 -mb-5 pointer-events-none"></div>
          </div>

          {/* 4. Skill Store (Refactored List View) */}
          <div className="col-span-2 bg-white/5 rounded-[32px] p-1 shadow-xl border border-white/10 h-[500px] flex flex-col backdrop-blur-md">
             <div className="px-5 py-4 border-b border-white/5 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-white text-sm">Skill Store</h3>
                    <p className="text-[10px] text-white/40">Discover trending open-source agents</p>
                </div>
                <div className="bg-blue-500/20 text-blue-300 border border-blue-500/30 px-2 py-1 rounded-md text-[10px] font-bold flex items-center gap-1">
                    <Star size={10} className="fill-blue-300" />
                    Top Rated
                </div>
             </div>
             
             <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
                {SKILL_STORE_DATA.map((skill, index) => {
                    const isInstalled = installedSkills.has(skill.id);
                    const isInstalling = installingSkillId === skill.id;
                    // Generate a color based on index
                    const colors = ['bg-orange-500', 'bg-blue-500', 'bg-purple-500', 'bg-green-500', 'bg-pink-500'];
                    const iconColor = colors[index % colors.length];

                    return (
                        <div key={skill.id} className="bg-white/5 border border-white/5 rounded-2xl p-3 flex items-center gap-3 hover:bg-white/10 transition-colors group">
                            {/* Icon */}
                            <div className={`w-10 h-10 rounded-xl ${iconColor} flex items-center justify-center text-white shadow-lg shrink-0`}>
                                <span className="font-bold text-xs">{skill.name.slice(0, 2).toUpperCase()}</span>
                            </div>
                            
                            {/* Content */}
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                    <h4 className="text-sm font-bold text-white truncate">{skill.name}</h4>
                                    <div className="flex items-center gap-0.5 text-[9px] text-yellow-400 bg-yellow-400/10 px-1.5 py-0.5 rounded border border-yellow-400/20">
                                        <Star size={8} className="fill-yellow-400" />
                                        {(skill.stars / 1000).toFixed(1)}k
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 mt-0.5">
                                    <span className="text-[10px] text-gray-400 flex items-center gap-1">
                                        <User size={10} /> {skill.author}
                                    </span>
                                </div>
                                <p className="text-[10px] text-gray-400 mt-1 line-clamp-1">{skill.description}</p>
                            </div>

                            {/* Action Button */}
                            <button
                                onClick={() => !isInstalled && handleMarketInstall(skill)}
                                disabled={isInstalled || isInstalling}
                                className={`
                                    px-3 py-1.5 rounded-full text-[10px] font-bold flex items-center gap-1.5 transition-all
                                    ${isInstalled 
                                        ? 'bg-green-500/20 text-green-400 border border-green-500/30 cursor-default' 
                                        : 'bg-white text-black hover:bg-gray-200 active:scale-95 shadow-md'
                                    }
                                `}
                            >
                                {isInstalling ? (
                                    <Loader size={12} className="animate-spin" />
                                ) : isInstalled ? (
                                    <>
                                        <Check size={12} />
                                        <span>Added</span>
                                    </>
                                ) : (
                                    <>
                                        <Download size={12} />
                                        <span>Install</span>
                                    </>
                                )}
                            </button>
                        </div>
                    );
                })}
             </div>
          </div>

        </div>
      </div>

      {/* Footer Floating Action */}
      <div className="absolute bottom-6 left-0 right-0 px-6 z-50 pointer-events-none">
         <button 
            onClick={handleSave}
            className="w-full bg-white text-black font-bold h-14 rounded-2xl shadow-2xl flex items-center justify-center gap-3 pointer-events-auto active:scale-95 transition-transform hover:bg-gray-200"
         >
            <Save size={20} />
            <span>Apply Configuration</span>
         </button>
      </div>

      {/* Manual Skill Definition Modal */}
      {isSkillModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
           <div className="bg-[#1c1c1e] w-full max-w-md rounded-2xl shadow-2xl flex flex-col h-[85vh] animate-scale-in overflow-hidden border border-white/10">
              {/* Modal Header */}
              <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
                 <div>
                    <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
                       <PenTool size={16} className="text-blue-400"/>
                       Define Skill
                    </h2>
                    <p className="text-[10px] text-gray-400">Teach your bot new capabilities</p>
                 </div>
                 <button onClick={() => setIsSkillModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white">
                    <X size={20} />
                 </button>
              </div>
              
              {/* Form Content */}
              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                 {/* Skill Name */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Skill Name <span className="text-gray-600 font-normal">(Action_Object)</span></label>
                    <input 
                      type="text" 
                      placeholder="e.g. search_policy"
                      value={skillForm.name}
                      onChange={e => setSkillForm({...skillForm, name: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 {/* Description */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Description</label>
                    <input 
                      type="text" 
                      placeholder="What does this skill do?"
                      value={skillForm.description}
                      onChange={e => setSkillForm({...skillForm, description: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 {/* Trigger */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Trigger Scene</label>
                    <input 
                      type="text" 
                      placeholder="When user asks..."
                      value={skillForm.trigger}
                      onChange={e => setSkillForm({...skillForm, trigger: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 {/* Core Logic */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Logic Steps</label>
                    <textarea 
                      placeholder="1. Extract keywords; 2. Query DB; 3. Format output."
                      value={skillForm.logic}
                      onChange={e => setSkillForm({...skillForm, logic: e.target.value})}
                      className="w-full h-24 bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors resize-none placeholder-gray-600"
                    />
                 </div>
                 {/* Parameters Group */}
                 <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="block text-xs font-bold text-gray-400 mb-1">Required Params</label>
                        <input 
                          type="text" 
                          placeholder="e.g. city: string"
                          value={skillForm.requiredParams}
                          onChange={e => setSkillForm({...skillForm, requiredParams: e.target.value})}
                          className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 placeholder-gray-600"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-400 mb-1">Optional Params</label>
                        <input 
                          type="text" 
                          placeholder="e.g. limit: 5"
                          value={skillForm.optionalParams}
                          onChange={e => setSkillForm({...skillForm, optionalParams: e.target.value})}
                          className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 placeholder-gray-600"
                        />
                    </div>
                 </div>
                 {/* Constraints */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Constraints</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Do not reveal private data..."
                      value={skillForm.constraints}
                      onChange={e => setSkillForm({...skillForm, constraints: e.target.value})}
                      className="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                    />
                 </div>
                 {/* Example */}
                 <div>
                    <label className="block text-xs font-bold text-gray-400 mb-1">Few-Shot Example</label>
                    <div className="bg-black/20 border border-white/10 rounded-lg p-2">
                        <input 
                          type="text" 
                          placeholder='e.g. "Check weather" -> {"loc": "Beijing"}'
                          value={skillForm.example}
                          onChange={e => setSkillForm({...skillForm, example: e.target.value})}
                          className="w-full bg-transparent text-sm focus:outline-none font-mono text-gray-300 placeholder-gray-600"
                        />
                    </div>
                 </div>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-white/10 bg-white/5">
                 <button 
                    onClick={handleSkillSubmit} 
                    className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg hover:bg-blue-500 active:scale-95 transition-all flex items-center justify-center gap-2"
                 >
                    <Check size={18} />
                    <span>Confirm & Add Skill</span>
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* Source Code Inspector Modal */}
      {isSourceModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-[#1c1c1e] w-full max-w-2xl rounded-2xl shadow-2xl flex flex-col h-[80vh] animate-scale-in overflow-hidden border border-white/10">
                <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
                    <div>
                    <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
                        <FileCode size={16} className="text-blue-400"/>
                        System Instructions
                    </h2>
                    <p className="text-[10px] text-gray-400">Current active brain content (Editable)</p>
                    </div>
                    <button onClick={() => setIsSourceModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white">
                    <X size={20} />
                    </button>
                </div>
                <div className="flex-1 p-0 relative">
                    <textarea 
                    value={previewInstruction}
                    onChange={(e) => setPreviewInstruction(e.target.value)}
                    className="w-full h-full p-5 font-mono text-xs text-green-400 bg-black/40 resize-none focus:outline-none leading-relaxed"
                    spellCheck={false}
                    />
                </div>
                <div className="p-3 border-t border-white/10 bg-white/5 flex justify-end">
                    <button 
                        onClick={() => setIsSourceModalOpen(false)}
                        className="bg-white text-black px-4 py-2 rounded-lg text-xs font-bold hover:bg-gray-200"
                    >
                        Close & Keep Changes
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* MyBot Brain (Skills Inspector) Modal */}
      {isBrainModalOpen && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-[#1c1c1e] w-full max-w-2xl rounded-2xl shadow-2xl flex flex-col h-[70vh] animate-scale-in overflow-hidden border border-white/10">
                
                {/* Brain Modal Header */}
                <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5 shrink-0">
                    <div className="flex items-center gap-2">
                        {viewingSkill ? (
                             <button 
                                onClick={() => setViewingSkill(null)}
                                className="p-1 hover:bg-white/10 rounded-lg mr-1 transition-colors text-white"
                             >
                                <ChevronLeft size={20} />
                             </button>
                        ) : (
                             <Brain size={20} className="text-white" />
                        )}
                        <div>
                            <h2 className="text-sm font-bold text-white uppercase tracking-wide">
                                {viewingSkill ? viewingSkill.name : 'MyBot Brain'}
                            </h2>
                            <p className="text-[10px] text-gray-400">
                                {viewingSkill ? 'Inspect installed modules' : 'Manage installed skills'}
                            </p>
                        </div>
                    </div>
                    <button onClick={() => { setIsBrainModalOpen(false); setViewingSkill(null); }} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/50 hover:text-white">
                        <X size={20} />
                    </button>
                </div>
                
                {/* Brain Content */}
                <div className="flex-1 overflow-y-auto bg-black/20 p-5">
                    {viewingSkill ? (
                        /* Detail View: Modules/Files */
                        <div className="space-y-4">
                            <div className="bg-white/5 p-4 rounded-xl border border-white/10 shadow-sm">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Skill Description</h3>
                                <p className="text-sm text-gray-300 leading-relaxed">{viewingSkill.description}</p>
                            </div>

                            {viewingSkill.keywords && (
                                <div className="bg-white/5 p-4 rounded-xl border border-white/10 shadow-sm">
                                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                                       <Zap size={14} className="text-orange-500" /> Capabilities
                                    </h3>
                                    <div className="flex flex-wrap gap-2">
                                        {viewingSkill.keywords.map((kw, i) => (
                                            <span key={i} className="px-3 py-1 bg-blue-500/20 text-blue-300 text-xs font-semibold rounded-full border border-blue-500/30">
                                                {kw}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <div>
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 ml-1">Modules & Files</h3>
                                <div className="bg-white/5 rounded-xl border border-white/10 shadow-sm overflow-hidden">
                                    {viewingSkill.modules.map((mod, idx) => (
                                        <div key={idx} className="flex items-center justify-between p-3 border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors cursor-default">
                                            <div className="flex items-center gap-3">
                                                <div className={`p-2 rounded-lg ${mod.type === 'folder' ? 'bg-blue-500/20 text-blue-400' : 'bg-white/10 text-gray-400'}`}>
                                                    {mod.type === 'folder' ? <Folder size={16} /> : <FileIcon size={16} />}
                                                </div>
                                                <div>
                                                    <div className="flex items-center gap-2">
                                                        <span className="font-mono text-sm text-white font-medium">{mod.name}</span>
                                                        {mod.tags && mod.tags.map((t, ti) => (
                                                            <span key={ti} className="text-[9px] px-1.5 py-0.5 bg-white/10 text-gray-400 rounded-md font-medium">{t}</span>
                                                        ))}
                                                    </div>
                                                    <div className="text-[10px] text-gray-500">{mod.desc}</div>
                                                </div>
                                            </div>
                                            {mod.size && <span className="text-[10px] text-gray-600 font-mono">{mod.size}</span>}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ) : (
                        /* List View: Installed Cards */
                        <div className="grid grid-cols-2 gap-3">
                             {getInstalledSkillObjects().length === 0 ? (
                                 <div className="col-span-2 flex flex-col items-center justify-center py-10 opacity-50">
                                     <Brain size={48} className="text-gray-600 mb-2" strokeWidth={1} />
                                     <p className="text-sm font-bold text-gray-500">No skills installed yet</p>
                                     <p className="text-xs text-gray-600">Visit the store to add capabilities</p>
                                 </div>
                             ) : (
                                getInstalledSkillObjects().map(skill => (
                                    <div 
                                        key={skill.id} 
                                        onClick={() => setViewingSkill(skill)}
                                        className="bg-white/5 p-4 rounded-2xl border border-white/10 shadow-sm hover:shadow-md hover:border-blue-500/30 transition-all cursor-pointer group"
                                    >
                                        <div className="flex justify-between items-start mb-3">
                                            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-gray-400 group-hover:bg-blue-500/20 group-hover:text-blue-400 transition-colors">
                                                <Package size={20} />
                                            </div>
                                            <div className="bg-green-500/20 text-green-400 text-[9px] font-bold px-1.5 py-0.5 rounded border border-green-500/30">
                                                ACTIVE
                                            </div>
                                        </div>
                                        <h3 className="font-bold text-sm text-white mb-1 leading-tight">{skill.name}</h3>
                                        <p className="text-[10px] text-gray-400 line-clamp-2 leading-relaxed">{skill.description}</p>
                                        <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between">
                                            <span className="text-[9px] font-mono text-gray-500">{skill.modules.length} modules</span>
                                            <ChevronRight size={14} className="text-gray-600 group-hover:text-blue-400" />
                                        </div>
                                    </div>
                                ))
                             )}
                        </div>
                    )}
                </div>
            </div>
        </div>
      )}

    </div>
  );
};

export default ConfigScreen;
