import React from 'react';
import { FloatingMenuItem } from '../types';

interface FloatingButtonProps {
  item: FloatingMenuItem;
}

const FloatingButton: React.FC<FloatingButtonProps> = ({ item }) => {
  return (
    <button
      className="absolute flex items-center gap-2 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-200 z-10 animate-fade-in-up"
      style={item.position}
    >
      <div className="flex items-center justify-center">
        {item.icon}
      </div>
      <span className="text-sm font-semibold text-gray-800">{item.label}</span>
    </button>
  );
};

export default FloatingButton;
