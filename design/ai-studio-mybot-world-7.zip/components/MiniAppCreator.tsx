
import React, { useState } from 'react';
import { Sparkles, ArrowUp, X, Command, Newspaper, BookOpen, Tag, Loader2, Check, Share, Download, MessageSquare, Mail, Clock, Calendar, ShieldAlert, Home, Utensils, Activity, Calculator, MapPin, Headphones, Wrench, LayoutGrid, RefreshCw, CheckCircle, FileText, Zap, Car } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { MiniApp } from '../types';

interface MiniAppCreatorProps {
  onClose: () => void;
  onCreated: (app: MiniApp) => void;
  initialPrompt?: string;
  showExamples?: boolean;
}

const EXAMPLES = [
  {
    title: '阅读早报',
    desc: '每天早上 8 点，采集 Reddit、TechCrunch 等过去 24 小时 AI 热点新闻，生成摘要卡片。',
    icon: <Newspaper size={20} className="text-blue-400" />,
    prompt: '生成一个阅读早报 Mini App：每天早上 8 点，采集 Reddit、TechCrunch 和机器之心 过去 24 小时内与“AI Agent 本地部署”相关的 5 条精华新闻，生成摘要卡片。',
  },
  {
    title: 'Chat 决策摘要',
    desc: '自动汇总群聊中过去 2 小时的技术讨论，提取出达成的共识和待分配的任务。',
    icon: <MessageSquare size={20} className="text-green-400" />,
    prompt: '生成一个聊天摘要 Mini App，自动汇总群聊中过去 2 小时的技术讨论，提取出达成的共识和待分配的任务。',
  },
  {
    title: '收件箱“脱水”',
    desc: '扫描过去 24 小时未读邮件，生成“谁发了什么”、“需要我做什么”的结构化总结。',
    icon: <Mail size={20} className="text-purple-400" />,
    prompt: '生成一个收件箱“脱水”日报 Mini App：每天下午 5 点，扫描过去 24 小时的所有未读邮件，生成一张包含“谁发了什么”、“需要我做什么”、“截止日期”的结构化总结卡片。',
  },
  {
    title: '未回复随访',
    desc: '标记已发送但对方超过 3 天未回复的重要邮件，生成“是否再次跟进”按钮。',
    icon: <Clock size={20} className="text-orange-400" />,
    prompt: '生成一个“追单” Mini App，自动标记那些我已发送但对方超过 3 天未回复的重要商务邮件，生成一个“是否需要再次跟进”的交互按钮。',
  },
  {
    title: '每日单词打卡',
    desc: '每日随机生成一个高阶词，美式发音，同义词反义词，点击翻面。',
    icon: <BookOpen size={20} className="text-pink-400" />,
    prompt: '生成一个英语背单词Mini App，每日随机生成一个高阶词，美式发音，同义词反义词，点击翻面。',
  },
  {
    title: '项目倒计时',
    desc: '将日历中的 Milestone 提取出来，以“距离交付还有 X 天”呈现，标记延期风险。',
    icon: <Calendar size={20} className="text-red-400" />,
    prompt: '生成一个看板 Mini App，将所有日历中的 Project Milestone 提取出来，以“距离交付还有 X 天”的紧迫感视觉化呈现，并标记出延期风险。',
  },
  {
    title: '车辆守卫',
    desc: '检测到非授权移动时，弹出实时坐标、周边画面，提供“远程报警”快捷键。',
    icon: <ShieldAlert size={20} className="text-red-500" />,
    prompt: '生成一个单车安防 Mini App，当 Biceek 智能锁 检测到非授权移动时，立即在卡片中弹出实时坐标、周边摄像头画面，并提供“远程报警”快捷键。',
  },
  {
    title: '智能家居',
    desc: '一句话（如“我要在二楼工作”）自动调整灯光色温、窗帘及空调温度。',
    icon: <Home size={20} className="text-yellow-400" />,
    prompt: '生成一个家居控制 Mini App，只需通过一句话描述场景（如“我要在二楼工作两小时”），自动调整 HomeKit 系统的灯光色温、窗帘开合及空调温度。',
  },
  {
    title: '降价猎手',
    desc: '监控 Vuori、Lululemon 等品牌 24 小时内全网最低价，自动尝试领券。',
    icon: <Tag size={20} className="text-emerald-400" />,
    prompt: '针对您常买的 Vuori、On 跑鞋、乐高 套装，在 24 小时内监控全网历史最低价，并在检测到折扣时自动尝试领取隐藏优惠券。',
  },
  {
    title: '餐饮预定',
    desc: '监控海底捞或全聚德未来一周空位，一旦有人退订即刻生成“是否预定”卡片。',
    icon: <Utensils size={20} className="text-rose-400" />,
    prompt: '生成一个订座助手 Mini App，监控 海底捞 或 全聚德的未来一周空位，一旦有人退订即刻生成“是否预定”卡片并支持一键支付定金。',
  },
  {
    title: '健身进度',
    desc: '同步骑行或游泳数据，将消耗卡路里换算成“本周可额外摄入的餐食量”。',
    icon: <Activity size={20} className="text-cyan-400" />,
    prompt: '生成一个健康 Mini App，同步 骑行 或游泳的数据，将消耗的卡路里自动换算成“本周可额外摄入的餐食量”并生成动态图表。',
  },
  {
    title: 'STEM 教育',
    desc: '针对错题自动生成互动式图形化讲解卡片，点击可翻面查看解题逻辑。',
    icon: <Calculator size={20} className="text-indigo-400" />,
    prompt: '生成一个小学数学辅助 Mini App，针对 Imagine Learning 中的错题，自动生成互动式的图形化讲解卡片，点击可翻面查看解题逻辑。',
  },
  {
    title: '展会向导',
    desc: '根据兴趣标签，实时推送当前场馆内正在进行的 Top 3 热门演讲。',
    icon: <MapPin size={20} className="text-sky-400" />,
    prompt: '生成一个 CES 或行业展会 Mini App，根据您的兴趣标签，实时推送当前场馆内正在进行的 Top 3 热门演讲，并生成一键导航至展位的路线图。',
  },
  {
    title: '社交日历',
    desc: '识别邮件中的聚会邀请，生成“社交优先级”打分和着装建议。',
    icon: <Calendar size={20} className="text-pink-500" />,
    prompt: '生成一个社交 Mini App，自动从邮件中识别社区的私人聚会或慈善晚宴邀请，结合您的日程生成“社交优先级”打分和着装建议卡片。',
  },
  {
    title: '有声书生成',
    desc: '输入孩子当天的奇思妙想，自动生成一段以孩子为主角的 Pixar 风格有声故事。',
    icon: <Headphones size={20} className="text-amber-400" />,
    prompt: '生成一个睡前故事 Mini App，输入孩子当天的奇思妙想，自动生成一段以孩子为主角的 5 分钟 Pixar 风格有声故事，背景音乐由 AI 自动生成。',
  },
  {
    title: 'AR 维修指南',
    desc: '当硬件故障时，摄像头识别零件，屏幕叠加 AR 箭头指引拆解更换。',
    icon: <Wrench size={20} className="text-slate-400" />,
    prompt: '生成一个硬件维修 Mini App，当 Biceek 硬件出现故障码，通过摄像头识别零件，在屏幕上叠加 AR 箭头指引您如何拆解和更换部件。',
  },
  {
    title: '任务象限仪',
    desc: '按“紧急/重要”排布任务，根据能量水平建议“现在适合处理哪件”。',
    icon: <LayoutGrid size={20} className="text-blue-500" />,
    prompt: '生成一个待办 Mini App，将我所有的任务按“紧急/重要”自动排布，并根据我当前的能量水平建议：“现在最适合处理哪件琐事”。',
  },
  {
    title: '跨平台同步',
    desc: '将 Google Tasks、Telegram 收藏和笔记待办汇总到一张卡片。',
    icon: <RefreshCw size={20} className="text-gray-400" />,
    prompt: '生成一个同步 Mini App，将 Google Tasks、Telegram 收藏夹和我的笔记软件中的待办事项汇总到一张卡片上，消除信息孤岛。',
  },
  {
    title: '今日复盘',
    desc: '晚上 9 点对比早晨计划与实际完成情况，生成“明日改进建议”。',
    icon: <CheckCircle size={20} className="text-green-500" />,
    prompt: '晚上 9 点，将我早晨生成的“今日计划”与实际完成情况进行对比，生成一份带有人工智能建议的“明天如何更高效”改进卡片。',
  },
  {
    title: '附件归档',
    desc: '自动识别合同、发票和设计图，分类保存到 Drive 并生成清单。',
    icon: <FileText size={20} className="text-teal-400" />,
    prompt: '生成一个文档 Mini App，自动识别邮件中的合同、发票和设计图，将其分类保存到 Google Drive 的对应项目文件夹，并生成已归档的清单。',
  },
  {
    title: '智能家居控制',
    desc: '一键控制家中灯光、空调和安防系统，显示实时能耗。',
    icon: <Zap size={20} className="text-yellow-400" />,
    prompt: '生成一个智能家居控制 Mini App，包含灯光开关、空调温度调节、安防系统状态切换，并以图表形式显示今日能耗。',
  },
  {
    title: 'Car Caring Game',
    desc: '一个简单的汽车养护小游戏，可以给汽车洗车、加油、修理。',
    icon: <Car size={20} className="text-blue-500" />,
    prompt: '生成一个 Car Caring Game Mini App，包含洗车、加油、修理等互动功能，并显示汽车的状态（清洁度、油量、健康度）。',
  }
];

const PosterPreview = ({ app }: { app: MiniApp }) => {
    // Select image based on type
    const getHeroImage = () => {
        if (app.type === 'news_feed') return 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?q=80&w=600&auto=format&fit=crop';
        if (app.type === 'flashcard') return 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=600&auto=format&fit=crop';
        if (app.type === 'price_tracker') return 'https://images.unsplash.com/photo-1556742049-0cfed4f7a07d?q=80&w=600&auto=format&fit=crop';
        return 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=600&auto=format&fit=crop';
    };

    return (
        <div className="bg-white text-black rounded-[24px] overflow-hidden shadow-2xl font-sans flex flex-col w-full animate-scale-in border-4 border-white/10">
             {/* Hero Section */}
             <div className="h-40 bg-gray-200 relative">
                 <img src={getHeroImage()} className="w-full h-full object-cover" alt="Hero" />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                 <div className="absolute bottom-4 left-5 text-white">
                     <div className="flex items-center gap-2 mb-1.5">
                         <div className={`w-6 h-6 rounded-lg ${app.color} flex items-center justify-center text-white text-[10px] shadow-sm border border-white/20`}>
                            <Sparkles size={12} />
                         </div>
                         <span className="text-[10px] font-bold opacity-90 uppercase tracking-widest">{app.type.replace('_', ' ')}</span>
                     </div>
                     <h2 className="text-2xl font-black leading-none tracking-tight">{app.title}</h2>
                 </div>
             </div>

             {/* Body Content */}
             <div className="p-5 flex-1 bg-[#f9fafb]">
                 {app.type === 'news_feed' && (
                     <div className="space-y-3">
                        {(app.content as any[] || []).slice(0, 3).map((item:any, i:number) => (
                             <div key={i} className="bg-white p-3 rounded-xl shadow-sm border border-gray-100 flex gap-3 items-start">
                                 <div className="text-2xl font-black text-gray-200 leading-none mt-1">0{i+1}</div>
                                 <div>
                                     <h4 className="text-xs font-bold text-gray-800 line-clamp-2 mb-1 leading-snug">{item.title}</h4>
                                     <div className="flex items-center gap-2">
                                        <span className="text-[9px] font-bold text-blue-500 bg-blue-50 px-1.5 rounded">{item.source || 'News'}</span>
                                        <p className="text-[9px] text-gray-400 line-clamp-1">{item.summary}</p>
                                     </div>
                                 </div>
                             </div>
                        ))}
                     </div>
                 )}
                 {app.type === 'flashcard' && (
                     <div className="flex flex-col justify-center items-center bg-white rounded-2xl border border-gray-100 p-6 text-center shadow-sm relative overflow-hidden">
                         <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-400 to-pink-500"></div>
                         <div className="text-[10px] font-bold text-gray-400 uppercase mb-3 tracking-wider">Word of the Day</div>
                         <h1 className="text-4xl font-black text-gray-900 mb-2 tracking-tight">{(app.content as any).word}</h1>
                         <div className="inline-block bg-gray-100 px-3 py-1 rounded-full text-xs font-mono text-gray-500 mb-4">
                            {(app.content as any).pronunciation}
                         </div>
                         <p className="text-xs text-gray-600 font-medium leading-relaxed">{(app.content as any).definition}</p>
                     </div>
                 )}
                 {app.type === 'price_tracker' && (
                     <div className="space-y-2">
                        {(app.content as any[] || []).slice(0, 3).map((item:any, i:number) => (
                             <div key={i} className="bg-white px-3 py-2.5 rounded-xl border border-gray-100 flex justify-between items-center shadow-sm">
                                 <div className="flex items-center gap-3">
                                     <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center text-orange-500 text-sm font-bold shadow-inner">¥</div>
                                     <div className="flex flex-col">
                                         <span className="text-[11px] font-bold text-gray-800">{item.product}</span>
                                         <span className="text-[9px] text-gray-400 font-medium">{item.retailer}</span>
                                     </div>
                                 </div>
                                 <div className="text-right">
                                     <div className="text-sm font-black text-gray-900">¥{item.price}</div>
                                     <span className="text-[9px] text-green-600 font-bold bg-green-50 px-1.5 rounded-full">Save {Math.floor(Math.random()*20)}%</span>
                                 </div>
                             </div>
                        ))}
                     </div>
                 )}
                 {app.type === 'generative_app' && (
                     <div className="grid grid-cols-2 gap-2">
                        {(app.content.widgets || []).slice(0, 4).map((widget: any, i: number) => (
                            <div key={i} className={`p-3 rounded-xl border border-gray-100 bg-white shadow-sm flex flex-col justify-between ${widget.type === 'list' || widget.type === 'chart' ? 'col-span-2' : ''}`}>
                                <div className="flex justify-between items-start mb-1">
                                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider">{widget.label}</span>
                                    {widget.icon && <div className={`text-[10px] ${widget.color || 'text-gray-400'}`}>*</div>}
                                </div>
                                <div className="flex items-baseline gap-1">
                                    <span className="text-sm font-black text-gray-900">{widget.value || '---'}</span>
                                    {widget.subValue && <span className="text-[8px] text-gray-400">{widget.subValue}</span>}
                                </div>
                            </div>
                        ))}
                     </div>
                 )}
                 
                 {/* Decorative Description */}
                 <div className="mt-4 pt-4 border-t border-gray-200">
                    <p className="text-[10px] text-gray-500 leading-relaxed italic">
                        "{app.description}"
                    </p>
                 </div>
             </div>

             {/* Footer */}
             <div className="p-4 bg-gray-50 border-t border-gray-200 flex justify-between items-center">
                 <div className="flex items-center gap-2">
                     <div className="w-8 h-8 bg-black rounded-full flex items-center justify-center text-white border-2 border-white shadow-md">
                         <Sparkles size={14} />
                     </div>
                     <div className="flex flex-col">
                         <span className="text-[9px] font-bold text-gray-800 uppercase tracking-wider">Generated by AI</span>
                         <span className="text-[8px] text-gray-400">Scan to add to Desktop</span>
                     </div>
                 </div>
                 <div className="flex gap-2">
                     <div className="w-8 h-8 bg-white rounded-lg border border-gray-200 p-0.5">
                         <div className="w-full h-full bg-gray-800 pattern-grid-lg opacity-20"></div>
                     </div>
                 </div>
             </div>
        </div>
    );
}

const MiniAppCreator: React.FC<MiniAppCreatorProps> = ({ onClose, onCreated, initialPrompt = '', showExamples = true }) => {
  const [input, setInput] = useState(initialPrompt);
  const [loading, setLoading] = useState(false);
  const [generatedApp, setGeneratedApp] = useState<MiniApp | null>(null);

  const handleGenerate = async (promptText: string) => {
    if (!promptText.trim()) return;
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const systemPrompt = `
        You are an expert AI App Generator. Your goal is to generate a valid JSON configuration for a "Mini App" based on the user's request.
        
        IMPORTANT: All generated content (titles, summaries, definitions, product names, etc.) MUST be in Chinese (Simplified), unless it is a specific English term being taught.

        Available App Types (choose the best fit):
        1. 'news_feed': For news, updates, social feeds, or text lists. 
           Content structure: Array of objects { id, title, source, time, summary, tag }.
        2. 'flashcard': For learning, vocabulary, quizzes, or single insight cards. 
           Content structure: Single object { word, pronunciation, definition (Chinese), synonyms: string[], antonyms: string[], example }.
        3. 'price_tracker': For shopping, monitoring prices, or financial data. 
           Content structure: Array of objects { id, product, price, originalPrice, trend: 'up'|'down'|'stable', retailer }.
        4. 'generative_app': For custom interactive utilities, dashboards, or specific tools.
           Content structure: {
             "widgets": [
               {
                 "type": "stat" | "button" | "toggle" | "list" | "chart" | "text",
                 "label": "Chinese Label",
                 "value": "Optional Value",
                 "subValue": "Optional Subtext",
                 "icon": "Lucide icon name",
                 "color": "Tailwind color (e.g. text-blue-500)",
                 "action": "Description of what happens when clicked",
                 "data": [] // Optional array for list or chart
               }
             ]
           }
        5. 'fashion_designer': For fashion design tools with input and image upload.
           Content structure: { "status": "idle", "results": null }
        6. 'car_caring': For a car maintenance game.
           Content structure: { 
             "carName": "Car Name", 
             "stats": { "cleanliness": 50, "fuel": 50, "health": 80 },
             "actions": ["Wash", "Refuel", "Repair"] 
           }
        
        Output JSON Format (Do not wrap in markdown):
        {
          "title": "Short App Name (Chinese)",
          "icon": "Lucide icon name",
          "color": "Tailwind color class (e.g., bg-blue-500, bg-purple-500, bg-orange-500, bg-green-500)",
          "type": "news_feed" | "flashcard" | "price_tracker" | "generative_app" | "fashion_designer" | "car_caring",
          "description": "Short description of what it does (Chinese)",
          "content": ... (Array or Object based on type above, with Chinese text)
        }
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: promptText,
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: 'application/json',
        }
      });

      const jsonText = response.text || '{}';
      const data = JSON.parse(jsonText);
      
      const newApp: MiniApp = {
        id: Date.now().toString(),
        createdAt: new Date().toLocaleTimeString(),
        ...data
      };

      // Set preview instead of closing immediately
      setGeneratedApp(newApp);

    } catch (error) {
      console.error("Failed to generate mini app", error);
      alert("Failed to generate app. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = () => {
      if (generatedApp) {
          onCreated(generatedApp);
          onClose();
      }
  };

  return (
    <div className="absolute inset-x-0 top-0 z-[60] p-4 animate-slide-in-down max-h-screen overflow-hidden flex flex-col">
      {/* Dark Glass Container */}
      <div className="bg-[#1c1c1e]/90 backdrop-blur-2xl rounded-[32px] shadow-[0_32px_64px_rgba(0,0,0,0.6)] border border-white/10 overflow-hidden ring-1 ring-white/5 max-h-[85vh] flex flex-col">
        
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-white/10 shrink-0">
           <div className="flex items-center gap-2">
              <div className="bg-gradient-to-tr from-blue-500 to-purple-500 p-1.5 rounded-lg text-white shadow-lg shadow-blue-500/20">
                 <Sparkles size={16} />
              </div>
              <h2 className="font-bold text-white text-sm tracking-wide">生成此Mini App的提示词</h2>
           </div>
           <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-full text-white/50 hover:text-white transition-colors">
              <X size={18} />
           </button>
        </div>

        <div className="p-5 space-y-5 overflow-y-auto custom-scrollbar">
           
           {/* Input Area */}
           <div className="relative group shrink-0">
              <div className="flex items-center gap-2 absolute top-3 left-4 text-blue-400 z-10 pointer-events-none">
                 <Sparkles size={14} className="animate-pulse" />
                 <span className="text-[10px] font-bold uppercase tracking-wider opacity-80">AI Generator</span>
              </div>
              <textarea 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="描述你想创建的应用功能..."
                className="w-full bg-black/40 border border-white/10 rounded-[24px] pt-10 pb-12 px-4 text-sm text-white placeholder-white/20 focus:outline-none focus:border-blue-500/50 focus:bg-black/60 transition-all resize-none h-32 shadow-inner"
              />
              <button 
                disabled={!input.trim() || loading}
                onClick={() => handleGenerate(input)}
                className={`absolute bottom-3 right-3 p-2.5 rounded-xl transition-all flex items-center gap-2 text-xs font-bold border border-white/5
                  ${input.trim() && !loading ? 'bg-white text-black shadow-lg hover:scale-105 active:scale-95' : 'bg-white/5 text-white/20 cursor-not-allowed'}
                `}
              >
                {loading ? <Loader2 size={16} className="animate-spin" /> : <ArrowUp size={16} strokeWidth={3} />}
                {loading && <span className="mr-1">Generate</span>}
              </button>
           </div>
           
           {/* Generated Poster Result */}
           {generatedApp ? (
               <div className="animate-fade-in-up pb-4">
                   <div className="flex justify-between items-center mb-3 px-1">
                       <span className="text-xs font-bold text-white/60 uppercase tracking-wider flex items-center gap-1">
                           <Check size={12} className="text-green-500" /> Ready to Install
                       </span>
                       <div className="flex gap-2">
                           <button onClick={() => setGeneratedApp(null)} className="text-xs text-white/40 hover:text-white px-3 py-1.5 transition-colors">Discard</button>
                           <button onClick={handleSave} className="bg-white text-black text-xs font-bold px-4 py-1.5 rounded-full shadow-lg hover:bg-gray-200 active:scale-95 transition-all flex items-center gap-1.5">
                               <Download size={12} /> Add App
                           </button>
                       </div>
                   </div>
                   
                   <PosterPreview app={generatedApp} />
               </div>
           ) : (
               /* Examples Section - Uniform Grid Layout */
               showExamples && (
                 <>
                   <div className="px-1">
                     <span className="text-[10px] font-bold text-white/40 uppercase tracking-wider">Try these examples</span>
                   </div>

                   <div className="grid grid-cols-2 gap-2.5 pb-6">
                      {EXAMPLES.map((ex, idx) => (
                         <div 
                           key={idx}
                           onClick={() => setInput(ex.prompt)}
                           className="
                              bg-white/5 border border-white/5 rounded-[24px] p-4 
                              hover:bg-white/10 hover:border-white/20 transition-all 
                              cursor-pointer group active:scale-[0.98] flex flex-col justify-between 
                              min-h-[140px]
                           "
                         >
                            <div className="flex justify-between items-start mb-2">
                               <div className="flex items-center gap-2">
                                  <div className="bg-white/10 p-2 rounded-xl text-white group-hover:scale-110 transition-transform shadow-inner">
                                      {ex.icon}
                                  </div>
                               </div>
                            </div>
                            <div>
                               <h3 className="text-sm font-bold text-gray-100 group-hover:text-white transition-colors mb-1.5 leading-tight">
                                  {ex.title}
                               </h3>
                               <p className="text-[10px] text-gray-400 leading-snug line-clamp-3 group-hover:text-gray-300">
                                  {ex.desc}
                               </p>
                            </div>
                         </div>
                      ))}
                   </div>
                 </>
               )
           )}
           
        </div>
      </div>
    </div>
  );
};

export default MiniAppCreator;
