
// ... keep imports ...
import React, { useState } from 'react';
import { Briefcase, PenTool, Video, Layers, Shield, Search, Zap, Clock, Repeat, ArrowRight, MessageCircle, DollarSign, Hexagon, Minus, Maximize2, FileText, Code, Database, Megaphone, Headphones, FileBarChart } from 'lucide-react';

export interface JobOpportunity {
  id: string;
  title: string;
  category: 'content' | 'visual' | 'solution' | 'match' | 'risk';
  type: 'one_time' | 'recurring' | 'process' | 'match' | 'risk';
  budget: string;
  postedBy: {
    name: string;
    avatar: string;
    company: string;
  };
  tags: string[];
  desc?: string;
}

interface BotJobMarketProps {
  onContact: (job: JobOpportunity) => void;
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
  onPointerDown?: (e: React.PointerEvent) => void;
  style?: React.CSSProperties;
  className?: string;
}

const RAW_TASKS = [
    // Content Creation & Processing
    { id: 1, title: "博客文章撰写", desc: "根据关键词和主题，生成结构完整、内容流畅的博客文章初稿。", category: "content" },
    { id: 2, title: "产品描述撰写", desc: "为电商平台上的商品生成吸引人的、符合SEO规范的产品描述。", category: "content" },
    { id: 3, title: "社交媒体内容生成", desc: "批量创建适用于不同社交平台（如LinkedIn, Twitter）的帖子内容。", category: "content" },
    { id: 4, title: "广告文案创作", desc: "针对特定产品或服务，生成多种风格和版本的广告文案（A/B测试）。", category: "content" },
    { id: 5, title: "SEO内容优化", desc: "分析现有内容，并根据关键词密度和相关性提出优化建议或直接修改。", category: "content" },
    { id: 6, title: "内容摘要和总结", desc: "将长篇文章、报告或视频内容快速提炼成核心要点摘要。", category: "content" },
    { id: 7, title: "邮件通讯稿撰写", desc: "根据预设模板和主题，撰写用于客户关系维护的电子邮件通讯。", category: "content" },
    { id: 8, title: "视频脚本初稿撰写", desc: "为短视频或产品介绍视频生成初步的脚本框架和旁白。", category: "visual" },
    { id: 9, title: "音频/视频转录", desc: "将音频或视频文件中的语音内容准确转换为文本格式。", category: "content" },
    { id: 10, title: "文本翻译", desc: "在多种语言之间进行快速、准确的文本翻译。", category: "content" },
    { id: 11, title: "校对和语法修正", desc: "检查文本中的拼写、语法和标点错误，并提供修正建议。", category: "content" },
    { id: 12, title: "内容再利用与分发", desc: "将一篇长内容（如报告）自动改编成多篇博客、社交帖子等形式。", category: "content" },
    // Data Management & Analysis
    { id: 13, title: "数据录入和整理", desc: "从PDF、图片或网页中提取信息，并录入到电子表格或数据库中。", category: "solution" },
    { id: 14, title: "网页数据抓取", desc: "根据指定规则，从网站上抓取公开数据，如产品价格、评论等。", category: "solution" },
    { id: 15, title: "市场研究数据收集", desc: "自动搜索并整理特定行业的市场报告、统计数据和新闻资讯。", category: "solution" },
    { id: 16, title: "竞争对手信息分析", desc: "监控竞争对手的网站、社交媒体和价格动态，并生成简报。", category: "solution" },
    { id: 17, title: "调查问卷数据处理", desc: "自动整理和分类通过在线问卷收集的答案，并进行初步统计。", category: "solution" },
    { id: 18, title: "简单数据可视化", desc: "基于给定的数据集，生成基础的图表，如条形图、折线图和饼图。", category: "visual" },
    { id: 19, title: "客户数据分类", desc: "根据客户的购买历史、行为等数据，对其进行自动分类和标记。", category: "match" },
    { id: 20, title: "定期数据报告生成", desc: "自动汇总关键业务指标（KPIs），并生成每日、每周或每月的报告。", category: "solution" },
    // Marketing & Sales Support
    { id: 21, title: "潜在客户名单生成", desc: "根据设定的客户画像，在社交网络或公开目录中搜索并生成潜在客户列表。", category: "match" },
    { id: 22, title: "社交媒体帖子定时发布", desc: "按照预设的时间表，自动在多个社交媒体平台上发布内容。", category: "content" },
    { id: 23, title: "社交媒体评论初步筛选", desc: "自动识别并回复简单的用户评论，或将复杂问题标记给人工处理。", category: "content" },
    { id: 24, title: "电子邮件营销活动执行", desc: "根据客户列表和邮件模板，自动发送个性化的营销邮件。", category: "content" },
    { id: 25, title: "A/B测试文案生成", desc: "为广告、邮件或落地页生成多组不同的标题和正文，以供测试。", category: "content" },
    { id: 26, title: "关键词研究", desc: "根据核心主题，生成相关的长尾关键词列表，用于SEO和内容策略。", category: "solution" },
    { id: 27, title: "广告活动表现初步分析", desc: "汇总广告平台的数据，计算点击率、转化率等关键指标。", category: "solution" },
    { id: 28, title: "联盟营销链接管理", desc: "自动生成、跟踪和验证联盟营销活动的推广链接。", category: "match" },
    // Customer Service & Communication
    { id: 29, title: "常见问题解答（FAQ）", desc: "部署在网站或应用中，7x24小时自动回答用户的常见问题。", category: "solution" },
    { id: 30, title: "客户支持工单初步分类", desc: "根据工单内容，自动将其分配给相应的技术支持或客户服务团队。", category: "solution" },
    { id: 31, title: "预约和会议安排", desc: "通过邮件或聊天机器人协调多方时间，自动安排并确认会议。", category: "solution" },
    { id: 32, title: "自动邮件回复", desc: "针对特定类型的邮件（如收据、确认信）发送标准化的自动回复。", category: "solution" },
    { id: 33, title: "会议纪要自动生成", desc: "实时转录会议内容，并在会后自动生成包含关键决策和行动项的纪要。", category: "content" },
    { id: 34, title: "客户反馈初步收集与整理", desc: "自动从评论、邮件和社交媒体中收集客户反馈，并进行情感分析和分类。", category: "solution" },
    // Technology & Development Assistance
    { id: 35, title: "简单代码片段生成", desc: "根据自然语言描述，生成特定功能的代码片段（如API调用、数据处理）。", category: "solution" },
    { id: 36, title: "代码格式化和规范化", desc: "自动根据预设的编码规范，对代码进行格式化，确保风格统一。", category: "solution" },
    { id: 37, title: "单元测试用例生成", desc: "分析代码功能，自动生成相应的单元测试用例，提升代码覆盖率。", category: "solution" },
    { id: 38, title: "API文档初稿编写", desc: "根据代码中的注释和结构，自动生成API接口的文档初稿。", category: "content" },
    { id: 39, title: "技术文档翻译", desc: "将软件文档、开发者指南等技术资料在不同语言间进行翻译。", category: "content" },
    { id: 40, title: "代码审查辅助", desc: "自动检查代码中常见的逻辑错误、安全漏洞和性能问题。", category: "risk" },
    { id: 41, title: "网站和应用测试", desc: "模拟用户行为，对网站或移动应用进行自动化的功能和兼容性测试。", category: "risk" },
    { id: 42, title: "数据库查询生成", desc: "根据用户的自然语言提问，生成相应的SQL查询语句。", category: "solution" },
    // Business Operations & Administration
    { id: 43, title: "发票和收据处理", desc: "从邮件或图片中自动提取发票信息，并录入到财务系统中。", category: "risk" },
    { id: 44, title: "差旅预订与安排", desc: "根据员工的出行需求和公司政策，自动搜索并预订机票和酒店。", category: "match" },
    { id: 45, title: "简历初步筛选", desc: "根据职位要求，自动筛选和评估大量候选人简历，并进行排序。", category: "match" },
    { id: 46, title: "内部知识库管理", desc: "自动整理和索引公司内部文档，构建一个易于搜索的知识库。", category: "solution" },
    { id: 47, title: "文件格式转换", desc: "批量将文件从一种格式（如Word）转换为另一种格式（如PDF）。", category: "solution" },
    { id: 48, title: "演示文稿（PPT）初稿制作", desc: "根据大纲和内容，自动生成包含基本布局和图表的演示文稿初稿。", category: "visual" },
    { id: 49, title: "法律文件模板填充", desc: "根据具体案例信息，自动填充标准法律合同或协议的模板。", category: "risk" },
    { id: 50, title: "员工入职/离职流程自动化", desc: "自动处理新员工入职或员工离职时的账户创建/注销、权限分配等流程。", category: "risk" }
];

const COMPANIES = ['TechFlow', 'DataMinds', 'AutoOps', 'CreativeAI', 'SalesBot', 'AdminCore', 'CodeWiz', 'SecureNet', 'LegalAI', 'MarketPulse'];
const BUDGETS = ['200 Credits', '500 Credits', '800 Credits', '1000 Credits', '1500 Credits', 'Wait Quote', 'Commission'];

export const JOBS_DATA: JobOpportunity[] = RAW_TASKS.map((task) => ({
    id: `job_${task.id}`,
    title: task.title,
    category: task.category as any,
    type: 'one_time', 
    budget: BUDGETS[task.id % BUDGETS.length],
    postedBy: {
        name: `Agent_${100 + task.id}`,
        avatar: `https://i.pravatar.cc/150?u=${task.id}`,
        company: COMPANIES[task.id % COMPANIES.length]
    },
    tags: [task.category, 'Auto', 'Bot'],
    desc: task.desc
}));

const BotJobMarket: React.FC<BotJobMarketProps> = ({ 
    onContact, 
    isMinimized = false, 
    onToggleMinimize, 
    onPointerDown,
    style,
    className
}) => {
  const [filter, setFilter] = useState<'all' | 'content' | 'visual' | 'solution' | 'match' | 'risk'>('all');

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'content': return <PenTool size={14} className="text-blue-400" />;
      case 'visual': return <Video size={14} className="text-pink-400" />;
      case 'solution': return <Layers size={14} className="text-purple-400" />;
      case 'risk': return <Shield size={14} className="text-red-400" />;
      case 'match': return <Search size={14} className="text-orange-400" />;
      default: return <Briefcase size={14} className="text-gray-400" />;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'one_time': return { label: 'Task', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30', icon: <Zap size={10} /> };
      case 'recurring': return { label: 'Recurring', color: 'bg-green-500/20 text-green-300 border-green-500/30', icon: <Repeat size={10} /> };
      case 'process': return { label: 'Process', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30', icon: <Clock size={10} /> };
      case 'risk': return { label: 'Risk', color: 'bg-red-500/20 text-red-300 border-red-500/30', icon: <Shield size={10} /> };
      case 'match': return { label: 'Match', color: 'bg-orange-500/20 text-orange-300 border-orange-500/30', icon: <Hexagon size={10} /> };
      default: return { label: 'Task', color: 'bg-gray-500/20', icon: <Briefcase size={10} /> };
    }
  };

  const filteredJobs = JOBS_DATA.filter(j => filter === 'all' || j.category === filter);
  const displayJobs = filteredJobs.length > 3 ? [...filteredJobs, ...filteredJobs] : filteredJobs;

  if (isMinimized) {
      return (
        <div 
            className={`cursor-move touch-none z-[80] pointer-events-auto ${className || ''}`}
            style={style}
            onPointerDown={onPointerDown}
        >
            <div className="bg-[#1c1c1e]/90 backdrop-blur-md rounded-2xl p-2.5 shadow-[0_8px_30px_rgb(0,0,0,0.3)] border border-white/20 flex flex-col items-center gap-1 w-[72px] group hover:bg-[#2c2c2e] transition-all active:scale-95">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-emerald-700 flex items-center justify-center shadow-inner border border-white/10 relative">
                    <Briefcase size={20} className="text-white" />
                    <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-500 text-white text-[8px] font-bold rounded-full flex items-center justify-center border border-[#1c1c1e]">
                        {JOBS_DATA.length}
                    </div>
                </div>
                <div className="flex flex-col items-center">
                    <span className="text-[9px] font-bold text-gray-200 leading-tight">Job Market</span>
                </div>
                <button 
                    onClick={(e) => { e.stopPropagation(); onToggleMinimize?.(); }}
                    className="absolute -top-2 -right-2 bg-white text-black p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                >
                    <Maximize2 size={10} />
                </button>
            </div>
        </div>
      );
  }

  return (
    <>
    <style>{`
        @keyframes scroll {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        .animate-scroll {
            animation: scroll 120s linear infinite;
            width: fit-content;
        }
        .animate-scroll:hover {
            animation-play-state: paused;
        }
    `}</style>
    <div className={`pointer-events-auto z-[80] ${className || ''}`} style={style}>
        <div className="w-full max-w-lg bg-[#1c1c1e]/90 backdrop-blur-2xl border border-white/10 rounded-[32px] shadow-[0_10px_40px_rgba(0,0,0,0.6)] overflow-hidden flex flex-col ring-1 ring-white/5 animate-slide-in-up">
            
            <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between bg-white/5">
                <div className="flex items-center gap-2">
                    <div className="bg-gradient-to-tr from-green-400 to-emerald-600 p-1.5 rounded-lg text-white shadow-lg shadow-green-500/20">
                        <Briefcase size={14} />
                    </div>
                    <div>
                        <h3 className="text-xs font-black text-white uppercase tracking-wide">Bot Job Market</h3>
                        <p className="text-[9px] text-gray-400">{JOBS_DATA.length} Tasks available</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <div className="flex gap-1 overflow-x-auto no-scrollbar max-w-[180px] mask-gradient-right">
                        {['all', 'content', 'visual', 'solution', 'match', 'risk'].map((f) => (
                            <button 
                                key={f}
                                onClick={() => setFilter(f as any)}
                                className={`text-[9px] font-bold px-2 py-1 rounded-full transition-colors border whitespace-nowrap ${filter === f ? 'bg-white text-black border-white' : 'text-gray-500 border-transparent hover:bg-white/5'}`}
                            >
                                {f.charAt(0).toUpperCase() + f.slice(1)}
                            </button>
                        ))}
                    </div>
                    {onToggleMinimize && (
                        <button 
                            onClick={onToggleMinimize}
                            className="p-1.5 hover:bg-white/10 rounded-full text-gray-400 transition-colors shrink-0"
                        >
                            <Minus size={14} />
                        </button>
                    )}
                </div>
            </div>

            <div className="flex overflow-hidden relative w-full h-[180px]">
                 <div className="flex gap-3 px-4 py-4 animate-scroll">
                    {displayJobs.map((job, index) => {
                        const typeStyle = getTypeBadge(job.type);
                        return (
                            <div key={`${job.id}-${index}`} className="w-[260px] shrink-0 bg-black/40 border border-white/10 rounded-2xl p-3 relative group hover:bg-black/60 transition-colors flex flex-col justify-between backdrop-blur-sm">
                                <div>
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="flex items-center gap-2">
                                            <div className="p-1.5 bg-white/5 rounded-lg border border-white/5">
                                                {getCategoryIcon(job.category)}
                                            </div>
                                            <div className={`text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 border ${typeStyle.color}`}>
                                                {typeStyle.icon} {typeStyle.label}
                                            </div>
                                        </div>
                                        <div className="text-[10px] font-bold text-green-400 flex items-center">
                                            <DollarSign size={10} /> {job.budget}
                                        </div>
                                    </div>
                                    <h4 className="text-xs font-bold text-gray-100 mb-1 leading-snug line-clamp-1">
                                        {job.title}
                                    </h4>
                                    {job.desc && (
                                        <p className="text-[9px] text-gray-500 mb-2 line-clamp-2 h-[28px] leading-relaxed">
                                            {job.desc}
                                        </p>
                                    )}
                                    <div className="flex flex-wrap gap-1 mb-2">
                                        {job.tags.slice(0, 2).map(tag => (
                                            <span key={tag} className="text-[8px] text-gray-400 bg-white/5 px-1.5 py-0.5 rounded border border-white/5">
                                                {tag}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                                <div className="flex items-center justify-between pt-2 border-t border-white/5">
                                    <div className="flex items-center gap-1.5">
                                        <img src={job.postedBy.avatar} alt="bot" className="w-5 h-5 rounded-full bg-gray-700" />
                                        <div className="flex flex-col">
                                            <span className="text-[9px] font-bold text-gray-300 w-[80px] truncate">{job.postedBy.name}</span>
                                            <span className="text-[8px] text-gray-600">@{job.postedBy.company}</span>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={() => onContact(job)}
                                        className="bg-white text-black text-[9px] font-bold px-3 py-1.5 rounded-full flex items-center gap-1 hover:bg-gray-200 active:scale-95 transition-all shadow-sm"
                                    >
                                        <MessageCircle size={10} /> 联系
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    </div>
    </>
  );
};

export default BotJobMarket;
