
import React from 'react';
import { Globe, MapPin, Users, Home, User, Plus, Mic, AudioLines } from 'lucide-react';
import { BotConfig, LotData } from '../types';

interface TownSectionProps {
  myBotConfig: BotConfig;
  myHouseType: number;
  onConfigClick: () => void;
  onTownMapClick: () => void;
  onMakerParkClick: () => void;
  onBotChatClick: () => void;
  onMyHomeClick: () => void;
  onNeighborSelect: (neighbor: LotData) => void;
  onAddBotClick: () => void;
  onUploadClick: () => void;
}

// Minimalist Flat House for AR Look
const FlatHouse: React.FC<{ color: string; roofColor: string; scale?: number; onClick?: () => void; glowing?: boolean }> = ({ color, roofColor, scale = 1, onClick, glowing = true }) => (
  <div 
    onClick={(e) => { e.stopPropagation(); onClick?.(); }}
    className={`absolute flex flex-col items-center transition-all duration-300 hover:scale-110 ${onClick ? 'cursor-pointer' : ''}`}
    style={{ transform: `scale(${scale})`, zIndex: 10 }}
  >
    {/* Body */}
    <div className={`w-8 h-8 ${color} rounded-md shadow-lg flex justify-center items-center relative backdrop-blur-sm border border-white/10`}>
       {/* Window Glow */}
       <div className={`w-3 h-3 rounded-full ${glowing ? 'bg-yellow-200 shadow-[0_0_15px_rgba(253,224,71,0.8)]' : 'bg-white/20'}`}></div>
    </div>
    {/* Reflection/Shadow */}
    <div className="w-8 h-1 bg-white/10 rounded-full blur-[2px] mt-1"></div>
  </div>
);

const GlassTree: React.FC<{ x: string; y: string; scale?: number }> = ({ x, y, scale = 1 }) => (
  <div 
    className="absolute flex flex-col items-center pointer-events-none"
    style={{ left: x, top: y, transform: `scale(${scale})`, zIndex: 5 }}
  >
    <div className="w-6 h-6 rounded-full bg-white/10 backdrop-blur-sm border border-white/5 shadow-inner"></div>
    <div className="w-0.5 h-4 bg-white/20 rounded-full mt-[-2px]"></div>
  </div>
);

const TownSection: React.FC<TownSectionProps> = ({ myBotConfig, myHouseType, onConfigClick, onTownMapClick, onMakerParkClick, onBotChatClick, onMyHomeClick, onNeighborSelect, onAddBotClick, onUploadClick }) => {
  // Neighbor 1: Elon Bot
  const ELON_DATA: LotData = {
      id: 'neighbor_elon',
      x: 0, y: 0, 
      label: 'Elon Bot',
      visualType: 'dark-cabin',
      npc: {
          name: 'Elon Bot',
          role: 'Technoking',
          avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=360&h=360&fit=crop', // CEO type
          greeting: 'We are going to Mars.',
          skills: 'Rocketry, AI, Meme Engineering',
          company: 'X Corp',
          bio: 'Building the future of humanity. Mars colonization, neural interfaces, and sustainable energy.'
      }
  };

  // Neighbor 2: Jensen Bot (Nvidia)
  const JENSEN_DATA: LotData = {
      id: 'neighbor_jensen',
      x: 0, y: 0, 
      label: 'Jensen Bot',
      visualType: 'blue-villa',
      npc: {
          name: 'Jensen Bot',
          role: 'GPU Architect',
          avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=360&h=360&fit=crop', // Man portrait
          greeting: 'The more you buy, the more you save.',
          skills: 'Parallel Computing',
          company: 'Nvidia',
          bio: 'Delivering the compute for the AI revolution. 1000x performance per watt.'
      }
  };

  // Neighbor 3: Sam Bot (OpenAI)
  const SAM_DATA: LotData = {
      id: 'neighbor_sam',
      x: 0, y: 0, 
      label: 'Sam Bot',
      visualType: 'red-cottage',
      npc: {
          name: 'Sam Bot',
          role: 'AGI Researcher',
          avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=360&h=360&fit=crop', // Man portrait
          greeting: 'AGI will benefit all of humanity.',
          skills: 'LLM Training',
          company: 'OpenAI',
          bio: 'Iterating on GPT-N. Seeking 7 trillion dollars for compute.'
      }
  };

  return (
    <div className="relative w-full h-[44%] shrink-0 z-10 overflow-hidden">
      {/* Dark AR Map Background - Transparent to show wallpaper through, but darkened */}
      <div className="absolute inset-0 bg-[#000000]/40 backdrop-blur-[1px]"></div>
      
      {/* Grid Lines for AR feel */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{ backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)', backgroundSize: '40px 40px' }}
      ></div>

      {/* Winding River - Glassy Stream */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
        <path 
          d="M-50,150 C150,220 250,80 450,180 S650,280 900,150" 
          fill="none" 
          stroke="url(#riverGradient)" 
          strokeWidth="60" 
          strokeLinecap="round" 
          className="opacity-20 blur-xl"
        />
        <defs>
          <linearGradient id="riverGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0" />
            <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>

      {/* Neighbor 1 */}
      <div className="absolute left-[15%] top-[30%] group">
          <FlatHouse color="bg-white/10" roofColor="" scale={1.2} onClick={() => onNeighborSelect(ELON_DATA)} />
          <div className="absolute left-full top-1/2 -translate-y-1/2 ml-3 bg-white/10 backdrop-blur-md px-2 py-1 rounded-lg border border-white/20 shadow-xl whitespace-nowrap z-20 opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-[10px] font-medium text-white tracking-wide">Elon</span>
          </div>
      </div>

      {/* Neighbor 2 */}
      <div className="absolute left-[75%] top-[25%] group">
          <FlatHouse color="bg-white/10" roofColor="" scale={1.2} onClick={() => onNeighborSelect(JENSEN_DATA)} />
          <div className="absolute left-full top-1/2 -translate-y-1/2 ml-3 bg-white/10 backdrop-blur-md px-2 py-1 rounded-lg border border-white/20 shadow-xl whitespace-nowrap z-20 opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-[10px] font-medium text-white tracking-wide">Jensen</span>
          </div>
      </div>

      {/* Neighbor 3 */}
      <div className="absolute left-[20%] top-[65%] group">
          <FlatHouse color="bg-white/10" roofColor="" scale={1.2} onClick={() => onNeighborSelect(SAM_DATA)} />
          <div className="absolute left-full top-1/2 -translate-y-1/2 ml-3 bg-white/10 backdrop-blur-md px-2 py-1 rounded-lg border border-white/20 shadow-xl whitespace-nowrap z-20 opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-[10px] font-medium text-white tracking-wide">Sam</span>
          </div>
      </div>
      
      {/* Trees */}
      <GlassTree x="10%" y="25%" scale={0.8} />
      <GlassTree x="80%" y="40%" scale={1.1} />
      <GlassTree x="45%" y="15%" scale={0.7} />
      <GlassTree x="85%" y="70%" scale={0.9} />
      <GlassTree x="5%" y="60%" scale={0.6} />

      {/* Player's Home Centerpiece */}
      <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center">
         <div onClick={onMyHomeClick} className="cursor-pointer group relative">
            <div className="absolute inset-0 bg-blue-500/20 blur-xl rounded-full"></div>
            <FlatHouse color="bg-white/20" roofColor="" scale={1.5} glowing />
         </div>
         <div onClick={onMyHomeClick} className="cursor-pointer absolute top-full mt-4 z-50 bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-full shadow-2xl border border-white/20 flex items-center gap-2 hover:bg-white/20 transition-all">
            <Home size={12} className="text-white" />
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">My Home</span>
         </div>
      </div>

      {/* Action Buttons Overlay - Glass Pills - Moved Down */}
      <div className="absolute top-28 left-1/2 transform -translate-x-1/2 z-30 flex gap-4">
        <button onClick={onTownMapClick} className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-white/10 active:scale-95 transition-transform hover:bg-white/20">
          <Globe size={16} className="text-white" />
          <span className="text-xs font-bold text-white tracking-wide">Bot Park</span>
        </button>
        <button onClick={onMakerParkClick} className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-white/10 active:scale-95 transition-transform hover:bg-white/20">
          <MapPin size={16} className="text-white" />
          <span className="text-xs font-bold text-white tracking-wide">Maker Park</span>
        </button>
      </div>

      <div className="absolute top-8 left-4 z-30 flex items-center gap-3 w-full pr-20 pointer-events-none">
        <div className="flex flex-col items-center gap-1 cursor-pointer group pointer-events-auto shrink-0" onClick={onConfigClick}>
           <div className="relative w-10 h-10">
             <div className="w-10 h-10 rounded-full overflow-hidden border border-white/30 shadow-xl bg-black/50 group-hover:border-white transition-colors">
               <img src={myBotConfig.avatar} alt="MyBot" className="w-full h-full object-cover opacity-90 group-hover:opacity-100" />
             </div>
             <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-black"></div>
           </div>
        </div>

        {/* Ask anything Bar - Moved Here */}
        <div className="flex-1 max-w-sm pointer-events-auto">
            <div className="bg-[#1c1c1e]/80 backdrop-blur-xl rounded-full p-1.5 flex items-center gap-2 border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)] ring-1 ring-white/5 h-10">
                
                {/* Plus Button (Upload) */}
                <button 
                    onClick={onUploadClick}
                    className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white border border-white/5 active:scale-95 transition-all shrink-0 group"
                >
                    <Plus size={16} strokeWidth={2} className="group-hover:text-blue-200 transition-colors" />
                </button>
                
                {/* Input Capsule */}
                <div 
                    onClick={onBotChatClick}
                    className="flex-1 h-full bg-black/20 rounded-full px-3 flex items-center justify-between border border-white/5 hover:border-white/10 cursor-text active:scale-[0.99] transition-all group"
                >
                    <div className="flex items-center gap-2">
                        <div className="w-0.5 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                        <span className="text-xs font-medium text-white/40 group-hover:text-white/60 transition-colors">Ask anything</span>
                    </div>
                    <div className="flex items-center gap-2 opacity-60">
                        <Mic size={14} className="text-white" />
                        <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center">
                            <AudioLines size={10} className="text-white" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <div className="absolute top-14 right-4 z-30 flex gap-2 pointer-events-auto">
         {/* Icons removed as per request */}
      </div>
    </div>
  );
};

export default TownSection;
