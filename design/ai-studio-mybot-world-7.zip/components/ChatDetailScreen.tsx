
import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, MoreHorizontal, Smile, Plus, Wifi, Send, Sparkles, X, Clock, User, Lightbulb, ArrowUp, Briefcase, MessageSquare, Check, PlusCircle, UserPlus, Search, Users, Minus, Loader2, CheckSquare, Network, ListChecks, Globe } from 'lucide-react';
import { ChatMessage, TaskItem, Message } from '../types';
import { AI_TEAM_MEMBERS, CONTACTS } from '../constants';
import { GoogleGenAI, Type } from "@google/genai";
import TopicNetworkView from './TopicNetworkView';
import FollowUpTimelineView, { FollowUpItem } from './FollowUpTimelineView';

interface ChatDetailScreenProps {
  chat: ChatMessage;
  onBack: () => void;
  onAddTask: (task: TaskItem) => void;
  systemInstruction?: string;
  variant?: 'default' | 'embedded';
  // Props for persistence & minimize
  history?: Message[];
  onUpdateMessages?: (msgs: Message[]) => void;
  onMinimize?: () => void;
  onConfigClick?: () => void;
}

interface AiContextState {
  mode: 'idle' | 'loading' | 'reply' | 'task' | 'brainstorm' | 'custom';
  data: any;
}

const POWERHOO_MESSAGES: Message[] = [
  {
    id: '1',
    senderName: 'Cathy (厨房业务)',
    senderAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop',
    content: '这个问题可以先用这个 UI 的配色，目前的颜色对比度不够。',
    type: 'reply',
    replyContext: '李震铭: 开关状态看起来不是很明显',
    isMe: false,
    time: '昨天 10:40 PM'
  },
  {
    id: '2',
    senderName: 'Evan Huang',
    senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
    content: '',
    type: 'voice',
    voiceDuration: '4"',
    isMe: false,
    time: '昨天 10:45 PM'
  },
  {
    id: '3',
    senderName: 'Sven',
    senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
    content: '👌，那我更新成这一版的 UI。话说 AI 界面是否该追求极简？',
    type: 'text',
    isMe: false,
  },
  {
    id: '4',
    senderName: '子非鱼',
    senderAvatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200&h=200&fit=crop',
    content: '@Evan Huang 周工邮寄订单先取消，目前看 Powerhoo100 低电量 OTA 无法更新。硬件初创如何处理这种批次故障？',
    type: 'text',
    isMe: false,
    time: '3:30 AM'
  },
  {
    id: '5',
    senderName: '常城',
    senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
    content: '已经取消了。',
    type: 'text',
    isMe: false,
  },
  {
    id: '6',
    senderName: '子非鱼',
    senderAvatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200&h=200&fit=crop',
    content: '👌',
    type: 'text',
    isMe: false,
    time: '3:30 AM'
  },
];

const SUPPLY_CHAIN_MESSAGES_DATA = {
  zh: [
    {
      id: 'sc_1',
      senderName: '陈总 (门店老板)',
      senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop',
      content: '团队好，"CityCruiser" 的预售远超预期。我们需要首批 200 台在周五前到达上海仓库。',
      type: 'text',
      isMe: false,
      time: '昨天 4:00 PM'
    },
    {
      id: 'sc_2',
      senderName: 'David (产品)',
      senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      content: '太棒了！我们正在全力推进组装线。不过，我们还在等最后一批电池。',
      type: 'text',
      isMe: false,
      time: '昨天 4:15 PM'
    },
    {
      id: 'sc_3',
      senderName: 'Sarah (电池销售)',
      senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop',
      content: 'David，陈总，你们好。由于 48V 电池包的新安全认证，稍微耽搁了一下。但好消息是，刚刚通过了检测。',
      type: 'text',
      isMe: false,
      time: '昨天 4:30 PM'
    },
    {
      id: 'sc_4',
      senderName: 'Mike (电机技术)',
      senderAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop',
      content: '确认一下，新的 BMS 固件兼容我们的 M500 电机对吧？我们不想再出现上次那样的同步问题。',
      type: 'text',
      isMe: false,
      time: '昨天 5:00 PM'
    },
    {
      id: 'sc_5',
      senderName: 'Sarah (电池销售)',
      senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop',
      content: '是的 Mike，上周我们和你的团队测试过了。完全兼容。',
      type: 'reply',
      replyContext: 'Mike (电机技术): 确认一下，新的 BMS 固件...',
      isMe: false,
      time: '昨天 5:10 PM'
    },
    {
      id: 'sc_6',
      senderName: 'David (产品)',
      senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      content: '@Sarah (电池销售)，你能今天把电池直接发到组装厂吗？',
      type: 'text',
      isMe: false,
      time: '10:30 AM'
    }
  ],
  en: [
    {
      id: 'sc_1',
      senderName: 'Mr. Chen (Store Owner)',
      senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop',
      content: 'Hey team, the pre-orders for the "CityCruiser" are exceeding expectations. We need the first batch of 200 units in our Shanghai warehouse by Friday.',
      type: 'text',
      isMe: false,
      time: 'Yesterday 4:00 PM'
    },
    {
      id: 'sc_2',
      senderName: 'David (Product)',
      senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      content: 'That\'s great news! We are pushing the assembly line. However, we are waiting for the final batch of batteries.',
      type: 'text',
      isMe: false,
      time: 'Yesterday 4:15 PM'
    },
    {
      id: 'sc_3',
      senderName: 'Sarah (Battery Sales)',
      senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop',
      content: 'Hi David, Mr. Chen. We had a slight delay due to the new safety certification for the 48V packs. But good news, they just passed inspection.',
      type: 'text',
      isMe: false,
      time: 'Yesterday 4:30 PM'
    },
    {
      id: 'sc_4',
      senderName: 'Mike (Motor Tech)',
      senderAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop',
      content: 'Just to confirm, the new BMS firmware is compatible with our M500 motors, right? We don\'t want any sync issues like last time.',
      type: 'text',
      isMe: false,
      time: 'Yesterday 5:00 PM'
    },
    {
      id: 'sc_5',
      senderName: 'Sarah (Battery Sales)',
      senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop',
      content: 'Yes Mike, we tested it with your team last week. It\'s fully compatible.',
      type: 'reply',
      replyContext: 'Mike (Motor Tech): Just to confirm, the new BMS firmware...',
      isMe: false,
      time: 'Yesterday 5:10 PM'
    },
    {
      id: 'sc_6',
      senderName: 'David (Product)',
      senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      content: '@Sarah (Battery Sales), can you ship the batteries directly to the assembly plant today?',
      type: 'text',
      isMe: false,
      time: '10:30 AM'
    }
  ],
  de: [
    {
      id: 'sc_1',
      senderName: 'Herr Chen (Ladenbesitzer)',
      senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop',
      content: 'Hallo Team, die Vorbestellungen für den "CityCruiser" übertreffen die Erwartungen. Wir brauchen die erste Charge von 200 Einheiten bis Freitag in unserem Lager in Shanghai.',
      type: 'text',
      isMe: false,
      time: 'Gestern 16:00'
    },
    {
      id: 'sc_2',
      senderName: 'David (Produkt)',
      senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      content: 'Das sind großartige Neuigkeiten! Wir treiben die Montagelinie voran. Wir warten jedoch noch auf die letzte Charge Batterien.',
      type: 'text',
      isMe: false,
      time: 'Gestern 16:15'
    },
    {
      id: 'sc_3',
      senderName: 'Sarah (Batterievertrieb)',
      senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop',
      content: 'Hallo David, Herr Chen. Wir hatten eine leichte Verzögerung aufgrund der neuen Sicherheitszertifizierung für die 48V-Packs. Aber gute Nachrichten, sie haben die Inspektion gerade bestanden.',
      type: 'text',
      isMe: false,
      time: 'Gestern 16:30'
    },
    {
      id: 'sc_4',
      senderName: 'Mike (Motortechnik)',
      senderAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop',
      content: 'Nur zur Bestätigung, die neue BMS-Firmware ist mit unseren M500-Motoren kompatibel, oder? Wir wollen keine Synchronisierungsprobleme wie beim letzten Mal.',
      type: 'text',
      isMe: false,
      time: 'Gestern 17:00'
    },
    {
      id: 'sc_5',
      senderName: 'Sarah (Batterievertrieb)',
      senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop',
      content: 'Ja Mike, wir haben es letzte Woche mit deinem Team getestet. Es ist voll kompatibel.',
      type: 'reply',
      replyContext: 'Mike (Motortechnik): Nur zur Bestätigung, die neue BMS-Firmware...',
      isMe: false,
      time: 'Gestern 17:10'
    },
    {
      id: 'sc_6',
      senderName: 'David (Produkt)',
      senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      content: '@Sarah (Batterievertrieb), kannst du die Batterien heute direkt an das Montagewerk schicken?',
      type: 'text',
      isMe: false,
      time: '10:30'
    }
  ]
};

const ChatDetailScreen: React.FC<ChatDetailScreenProps> = ({ 
    chat, 
    onBack, 
    onAddTask, 
    systemInstruction, 
    variant = 'default',
    history,
    onUpdateMessages,
    onMinimize,
    onConfigClick
}) => {
  const isEmbedded = variant === 'embedded';

  const bubbleTextClass = isEmbedded ? "text-[12px] leading-snug" : "text-[15px] leading-snug";
  const bubblePaddingClass = isEmbedded ? "px-3 py-2 min-h-[32px]" : "px-4 py-2.5 min-h-[42px]";
  const avatarClass = isEmbedded ? "w-8 h-8 rounded-lg" : "w-10 h-10 rounded-[14px]";
  const senderNameClass = isEmbedded ? "text-[9px]" : "text-[11px]";
  const timeClass = isEmbedded ? "text-[9px]" : "text-[10px]";
  const headerTitleClass = isEmbedded ? "text-[13px]" : "text-[17px]";
  const inputClass = isEmbedded ? "text-[12px]" : "text-[15px]";
  const iconScale = isEmbedded ? 0.8 : 1;

  const [language, setLanguage] = useState<'zh' | 'en' | 'de'>('zh');

  const [messages, setMessages] = useState<Message[]>(() => {
    // If history is provided from parent, use it.
    if (history && history.length > 0) return history;
    
    // Fallback to defaults
    if (chat.id === 'group_14') return POWERHOO_MESSAGES;
    if (chat.id === 'group_supply_chain') return SUPPLY_CHAIN_MESSAGES_DATA.zh as Message[];
    return [{
      id: 'init',
      senderName: chat.name,
      senderAvatar: chat.avatar,
      content: chat.message || '你好！我是你的 AI 创业导师。让我们聊聊你的项目吧。',
      type: 'text',
      isMe: false,
      time: '刚刚'
    }];
  });

  const toggleLanguage = () => {
    const nextLang = language === 'zh' ? 'en' : language === 'en' ? 'de' : 'zh';
    setLanguage(nextLang);
    
    if (chat.id === 'group_supply_chain') {
        setMessages(SUPPLY_CHAIN_MESSAGES_DATA[nextLang] as Message[]);
    }
  };
  
  const [inputValue, setInputValue] = useState('');
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState('');
  const [addedTasks, setAddedTasks] = useState<Set<number>>(new Set());
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [aiContext, setAiContext] = useState<AiContextState>({ mode: 'idle', data: null });
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [showNetworkView, setShowNetworkView] = useState(false);
  const [networkData, setNetworkData] = useState<{ nodes: any[], links: any[] } | null>(null);
  const [isGeneratingNetwork, setIsGeneratingNetwork] = useState(false);
  
  const [showFollowUpView, setShowFollowUpView] = useState(false);
  const [followUpItems, setFollowUpItems] = useState<FollowUpItem[]>([]);
  const [isGeneratingFollowUps, setIsGeneratingFollowUps] = useState(false);
  
  // Multi-selection state
  const [selectedMemberIds, setSelectedMemberIds] = useState<Set<string>>(new Set());

  // Active Group Participants (Initialized with defaults for demo)
  const [groupParticipants, setGroupParticipants] = useState<Set<string>>(() => {
      const initial = new Set<string>();
      // Always add the current chat counterpart if it exists in our constants
      // Also add some defaults for the group chat demo
      if (chat.id === 'group_14') {
          initial.add('elon');
          initial.add('jobs');
          initial.add('c_evan');
      }
      if (chat.id === 'group_supply_chain') {
          initial.add('owner'); // Mr. Chen
          initial.add('cto');   // David (Product/Tech)
          initial.add('coo');   // Sarah (Ops/Sales)
      }
      return initial;
  });

  // Mention Popover State
  const [mentionSearch, setMentionSearch] = useState<{ active: boolean; query: string }>({ active: false, query: '' });

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync messages back to parent whenever they change
  useEffect(() => {
      if (onUpdateMessages) {
          onUpdateMessages(messages);
      }
  }, [messages, onUpdateMessages]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isAiThinking]);

  useEffect(() => {
    setAiContext({ mode: 'idle', data: null });
    setCustomPrompt('');
    setAddedTasks(new Set());
  }, [activeMessageId]);

  // Reset selections when modal opens/closes
  useEffect(() => {
      if (!showAddMemberModal) {
          setSelectedMemberIds(new Set());
      }
  }, [showAddMemberModal]);

  // Handle Input Change for Mentions
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setInputValue(val);

      // Regex to detect if user is typing a mention at the end (e.g., "Hello @St")
      // Matches @ followed by non-whitespace characters at the end of string
      const match = val.match(/@([^@\s]*)$/);
      if (match) {
          setMentionSearch({ active: true, query: match[1].toLowerCase() });
      } else {
          setMentionSearch({ active: false, query: '' });
      }
  };

  const handleSelectMention = (name: string) => {
      // Replace the query part with the full name
      // e.g., "Hello @St" -> "Hello @Steve "
      const newValue = inputValue.replace(/@([^@\s]*)$/, `@${name} `);
      setInputValue(newValue);
      setMentionSearch({ active: false, query: '' });
      inputRef.current?.focus();
  };

  // Helper to generate AI reply
  const generateReply = async (prompt: string, instruction: string, senderName: string, avatar: string) => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const historyContext = messages.slice(-10).map(m => ({
            role: m.isMe ? 'user' : 'model',
            parts: [{ text: `${m.senderName ? m.senderName + ': ' : ''}${m.content}` }]
        }));

        // Efficient Instruction
        const efficientInstruction = `${instruction}\n\nIMPORTANT: Reply in Chinese. Be extremely concise, efficient, and direct. No fluff. Maximum 60 words.`;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: [ ...historyContext, { role: 'user', parts: [{ text: prompt }] } ],
            config: { systemInstruction: efficientInstruction }
        });

        const aiText = response.text || '...';
        const aiReply: Message = {
            id: Date.now().toString() + Math.random().toString(),
            senderName: senderName,
            senderAvatar: avatar,
            content: aiText,
            type: 'text',
            isMe: false,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, aiReply]);
      } catch (error) {
          console.error(`Error generating reply for ${senderName}:`, error);
      }
  };

  const handleGenerateFollowUps = async () => {
    setIsGeneratingFollowUps(true);
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const contextMessages = messages.map(m => `[${m.time || 'Unknown Time'}] ${m.senderName || 'User'}: ${m.content}`).join('\n');
        
        const prompt = `
        Analyze the following conversation and identify actionable follow-up items, key decisions, or tasks.
        Sort them chronologically based on when they appeared in the chat.
        
        Return a JSON object with:
        - "items": Array of { "id": string, "time": string, "content": string, "owner": string, "status": "pending" | "done" }
        
        "time": Use the timestamp from the message or infer "Today/Yesterday".
        "owner": The person responsible or the speaker if it's a commitment.
        
        Conversation:
        ${contextMessages.slice(-5000)}
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: { responseMimeType: 'application/json' }
        });

        const data = JSON.parse(response.text || '{"items":[]}');
        setFollowUpItems(data.items || []);
        setShowFollowUpView(true);
    } catch (e) {
        console.error("FollowUp Gen Error", e);
        alert("Failed to generate follow-up items.");
    } finally {
        setIsGeneratingFollowUps(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userText = inputValue;
    setInputValue('');
    setMentionSearch({ active: false, query: '' });

    const newMessage: Message = {
      id: Date.now().toString(),
      senderAvatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=200&h=200&fit=crop', 
      content: userText,
      type: 'text',
      isMe: true,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMessage]);
    setIsAiThinking(true);

    try {
      // 0. Idea Capture Logic (Pre-check)
      const ideaKeywords = ["我觉得", "我们应该", "建议", "如果能", "idea", "想法", "痛点"];
      const hasIdeaKeyword = ideaKeywords.some(kw => userText.toLowerCase().includes(kw));

      if (hasIdeaKeyword) {
          try {
             const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
             const prompt = `
             Analyze the following user message to see if it contains a product idea or feature suggestion.
             If it does, extract the "Title" (short name), "Pain Point" (problem being solved), and "Suggestion" (proposed solution).
             
             Message: "${userText}"
             
             Return JSON object: { "isIdea": boolean, "title": string, "painPoint": string, "suggestion": string }
             `;
             
             const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: prompt,
                config: { responseMimeType: 'application/json' }
             });
             
             const result = JSON.parse(response.text || '{}');
             
             if (result.isIdea) {
                 const ideaMsg: Message = {
                     id: Date.now().toString() + "_idea",
                     senderName: 'Javis (PM Agent)',
                     senderAvatar: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=200&h=200&fit=crop',
                     content: 'Idea Captured',
                     type: 'idea-card',
                     isMe: false,
                     time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                     ideaData: {
                         title: result.title,
                         painPoint: result.painPoint,
                         suggestion: result.suggestion
                     }
                 };
                 setMessages(prev => [...prev, ideaMsg]);
                 setIsAiThinking(false);
                 return; // Stop further processing
             }
          } catch (e) {
              console.error("Idea detection failed", e);
          }
      }

      // 1. Detect Mentions
      const mentionRegex = /@(\w+)/g; // Matches @Steve, @everyone, etc.
      const mentions = [...userText.matchAll(mentionRegex)].map(match => match[1].toLowerCase());
      
      let responded = false;

      // 2. Handle @everyone or @all
      if (mentions.includes('everyone') || mentions.includes('all')) {
           // Trigger currently active AI members in group
           const activeBots = AI_TEAM_MEMBERS.filter(m => groupParticipants.has(m.id));
           // Fallback to top 3 if group is empty/defaults not set for demo
           const botsToReply = activeBots.length > 0 ? activeBots : AI_TEAM_MEMBERS.slice(0, 3);

           for (const bot of botsToReply) {
               await generateReply(userText, bot.instruction, bot.name, bot.avatar);
           }
           responded = true;
      } else {
          // 3. Handle Specific Mentions
          for (const mention of mentions) {
              const targetBot = AI_TEAM_MEMBERS.find(m => m.name.toLowerCase().includes(mention));
              if (targetBot) {
                  await generateReply(userText, targetBot.instruction, targetBot.name, targetBot.avatar);
                  responded = true;
              } else {
                  // Check if it's a contact (mock reply for now since contacts don't have instructions)
                  const targetContact = CONTACTS.find(c => c.name.toLowerCase().includes(mention));
                  if (targetContact) {
                       // Mock reply for contact
                       setTimeout(() => {
                           setMessages(prev => [...prev, {
                               id: Date.now().toString(),
                               senderName: targetContact.name,
                               senderAvatar: targetContact.avatar,
                               content: "收到，我等下看。",
                               type: 'text',
                               isMe: false,
                               time: 'Now'
                           }]);
                       }, 1000);
                       responded = true;
                  }
              }
          }
      }

      // 4. Default Reply (if no specific mention and this is a bot chat)
      // Only if NO mentions were processed, reply as the main bot of this chat.
      if (!responded) {
           // Check if current chat is a specific bot
           const currentBot = AI_TEAM_MEMBERS.find(m => chat.name.includes(m.name));
           
           if (currentBot) {
               await generateReply(userText, currentBot.instruction, currentBot.name, currentBot.avatar);
           } else {
              // Generic Chat Logic
              const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
              const history = messages.slice(-10).map(m => ({
                role: m.isMe ? 'user' : 'model',
                parts: [{ text: `${m.senderName ? m.senderName + ': ' : ''}${m.content}` }]
              }));
              
              const finalInstruction = systemInstruction || `
                你是一名顶尖的 AI 创业导师，目前在名为“${chat.name}”的群聊中。
                回复规则：1. 使用中文。2. 契合AI创业语境。3. 简短有力(50字内)。
              `;
              
              const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: [ ...history, { role: 'user', parts: [{ text: userText }] } ],
                config: { systemInstruction: finalInstruction }
              });
              const aiText = response.text || '...';
              const aiReply: Message = {
                id: (Date.now() + 1).toString(),
                senderName: chat.name === 'MyBot' ? chat.name : (chat.name.includes('(') ? chat.name.split(' ')[0] : chat.name),
                senderAvatar: chat.avatar,
                content: aiText,
                type: 'text',
                isMe: false,
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              };
              setMessages(prev => [...prev, aiReply]);
           }
      }

    } catch (error) { console.error("AI Error", error); } finally { setIsAiThinking(false); }
  };

  const handleReplyClick = async (msg: Message) => {
    setAiContext({ mode: 'loading', data: null });
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        // Context: Last 10 messages to understand the flow
        const contextMessages = messages.slice(-10).map(m => 
            `${m.senderName || (m.isMe ? 'Me' : 'User')}: ${m.content}`
        ).join('\n');
        
        const prompt = `
        You are an AI assistant helping the user reply to a chat message.
        Analyze the conversation context and the specific message selected.
        Generate 3 distinct, relevant, and professional reply suggestions for the user ("Me").
        
        Conversation Context:
        ${contextMessages}
        
        Selected Message to Reply to:
        ${msg.senderName || 'User'}: ${msg.content}
        
        Requirements:
        1. Suggestions should be concise (under 20 words).
        2. Match the language and tone of the conversation (e.g. if conversation is in Chinese, output Chinese).
        3. Provide variety: one positive/agreement, one questioning/clarifying, one action-oriented.
        4. Return ONLY a raw JSON array of strings.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: { responseMimeType: 'application/json' }
        });

        const suggestions = JSON.parse(response.text || '[]');
        // Ensure we have an array
        const finalSuggestions = Array.isArray(suggestions) ? suggestions.slice(0, 3) : ["收到", "好的", "稍等"];
        setAiContext({ mode: 'reply', data: finalSuggestions });

    } catch (e) {
        console.error("Reply Gen Error", e);
        setAiContext({ mode: 'reply', data: ["收到，我确认一下。", "好的，没问题。", "稍后回复。"] });
    }
  };

  const handleTaskClick = async (msg: Message) => {
    setAiContext({ mode: 'loading', data: null });
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const contextMessages = messages.slice(-6).map(m => `${m.senderName || 'User'}: ${m.content}`).join('\n');
        
        const prompt = `
        Based on the conversation context, generate 3 specific, actionable to-do tasks (待办事项).
        If the conversation is in Chinese, generate tasks in Chinese.
        Conversation history:
        ${contextMessages}
        
        Return a raw JSON array of strings, e.g. ["Complete report", "Call John"].
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: {
                responseMimeType: 'application/json'
            }
        });

        const tasks = JSON.parse(response.text || '[]');
        setAiContext({ mode: 'task', data: tasks });
    } catch (e) {
        console.error("Task Gen Error", e);
        setAiContext({ mode: 'idle', data: null });
    }
  };

  const handleConfirmAddTask = (taskTitle: string) => {
      onAddTask({
          title: taskTitle,
          assignee: 'Me',
          priority: 'Medium',
          status: 'Pending'
      });
      setActiveMessageId(null);
      setAiContext({ mode: 'idle', data: null });
  };

  const handleCustomAiPrompt = async (msg: Message, promptText: string) => {
    setAiContext({ mode: 'custom', data: "AI 导师正在思考: " + promptText });
  };
  const handleSuggestionSelect = (text: string) => { setInputValue(text); setActiveMessageId(null); };

  const toggleMemberSelection = (id: string) => {
      const newSet = new Set(selectedMemberIds);
      if (newSet.has(id)) {
          newSet.delete(id);
      } else {
          newSet.add(id);
      }
      setSelectedMemberIds(newSet);
  };

  const handleConfirmAddMembers = () => {
      const allCandidates = [...AI_TEAM_MEMBERS, ...CONTACTS];
      const selected = allCandidates.filter(m => selectedMemberIds.has(m.id));
      
      if (selected.length === 0) return;

      const newMessages: Message[] = selected.map((member, index) => ({
          id: Date.now().toString() + index,
          senderAvatar: member.avatar,
          content: `${member.name} has joined the group.`,
          type: 'system',
          isMe: false,
          senderName: 'System',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }));

      // Update active participants
      const updatedParticipants = new Set(groupParticipants);
      selected.forEach(m => updatedParticipants.add(m.id));
      setGroupParticipants(updatedParticipants);

      setMessages(prev => [...prev, ...newMessages]);
      setShowAddMemberModal(false);
  };

  // Filter members for mention popup
  const filteredMentionMembers = mentionSearch.active 
    ? [...AI_TEAM_MEMBERS, ...CONTACTS].filter(m => 
        // Show if in group OR if query matches (allowing adding by mention behavior)
        // For strictly "in group" behavior: groupParticipants.has(m.id) && m.name...
        // But for better demo UX, let's show all matches but prioritize group members
        m.name.toLowerCase().includes(mentionSearch.query)
      ).sort((a, b) => {
          // Prioritize members already in group
          const aIn = groupParticipants.has(a.id) ? 1 : 0;
          const bIn = groupParticipants.has(b.id) ? 1 : 0;
          return bIn - aIn;
      })
    : [];

  const [showPlusMenu, setShowPlusMenu] = useState(false);

  return (
    <div className={`flex flex-col h-full font-sans relative z-50 animate-fade-in ${isEmbedded ? 'bg-transparent' : 'bg-black/90'}`}>
      
      {/* Plus Menu Popup */}
      {showPlusMenu && (
        <div className="absolute bottom-20 left-4 z-[70] animate-scale-in origin-bottom-left">
            <div className="bg-[#2c2c2e] rounded-xl shadow-2xl border border-white/10 overflow-hidden w-40 flex flex-col py-1">
                <button className="flex items-center gap-3 px-4 py-3 hover:bg-white/10 text-white transition-colors text-sm">
                    <MessageSquare size={18} />
                    <span>发起群聊</span>
                </button>
                <div className="h-[1px] bg-white/5 mx-4"></div>
                <button className="flex items-center gap-3 px-4 py-3 hover:bg-white/10 text-white transition-colors text-sm">
                    <UserPlus size={18} />
                    <span>添加朋友</span>
                </button>
                <div className="h-[1px] bg-white/5 mx-4"></div>
                <button className="flex items-center gap-3 px-4 py-3 hover:bg-white/10 text-white transition-colors text-sm">
                    <div className="relative">
                        <UserPlus size={18} />
                        <div className="absolute -bottom-1 -right-1 bg-blue-500 w-2 h-2 rounded-full border border-[#2c2c2e]"></div>
                    </div>
                    <span>添加Bot</span>
                </button>
                <div className="h-[1px] bg-white/5 mx-4"></div>
                <button className="flex items-center gap-3 px-4 py-3 hover:bg-white/10 text-white transition-colors text-sm">
                    <div className="relative">
                        <div className="w-4 h-4 border-2 border-white rounded-sm"></div>
                        <div className="absolute top-1/2 left-0 w-full h-[1px] bg-white"></div>
                    </div>
                    <span>扫一扫</span>
                </button>
            </div>
            {/* Triangle Pointer */}
            <div className="absolute -bottom-2 left-4 w-4 h-4 bg-[#2c2c2e] transform rotate-45 border-r border-b border-white/10"></div>
        </div>
      )}

      {/* Glass Header */}
      <div className="absolute top-0 left-0 right-0 z-[60] bg-[#1c1c1e]/70 backdrop-blur-xl border-b border-white/10 flex items-center justify-between px-4 py-3 pb-4 rounded-t-[32px]">
          <div className="flex items-center gap-3">
             <button onClick={onBack} className="flex items-center text-blue-500 hover:text-blue-400 active:opacity-60 transition-colors">
                <ChevronLeft size={26} strokeWidth={2} />
             </button>
             {isEmbedded && (
                 <div className="w-8 h-8 rounded-full overflow-hidden border border-white/20">
                    <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover"/>
                 </div>
             )}
             <div className="flex flex-col">
                <h1 className={`${headerTitleClass} font-semibold text-white`}>
                    {chat.name}
                </h1>
                {!isEmbedded && <span className="text-[10px] text-gray-400">{groupParticipants.size} people active</span>}
             </div>
          </div>
          <div className="flex items-center gap-2">
            {onMinimize && (
                <button 
                    onClick={onMinimize}
                    className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-colors"
                >
                    <Minus size={16} />
                </button>
            )}
            <button 
                onClick={toggleLanguage}
                className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-colors"
                title="Switch Language"
            >
                {language === 'zh' ? <span className="text-[10px] font-bold">中</span> : 
                 language === 'en' ? <span className="text-[10px] font-bold">En</span> : 
                 <span className="text-[10px] font-bold">De</span>}
            </button>
            <button 
                onClick={handleGenerateFollowUps}
                className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-colors"
                disabled={isGeneratingFollowUps}
            >
                {isGeneratingFollowUps ? <Loader2 size={16} className="animate-spin" /> : <ListChecks size={18} />}
            </button>
            <button 
                onClick={() => setShowAddMemberModal(true)}
                className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-colors"
            >
                <UserPlus size={16} />
            </button>
            <button 
                onClick={onConfigClick}
                className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-white/80 hover:bg-white/20 hover:text-white transition-colors"
            >
                <MoreHorizontal size={18} />
            </button>
          </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar relative z-10 pt-20 pb-24">
        {messages.map((msg, index) => {
          const showTime = msg.time && (index === 0 || messages[index - 1].time !== msg.time);
          const isSystem = msg.type === 'system';
          
          if (isSystem) {
              return (
                  <div key={msg.id} className="flex flex-col items-center justify-center my-4 space-y-1 animate-fade-in">
                      {showTime && <span className={`${timeClass} text-white/40 font-medium`}>{msg.time}</span>}
                      <div className="bg-white/10 px-3 py-1 rounded-full text-[10px] text-gray-300 flex items-center gap-2 border border-white/5">
                          <img src={msg.senderAvatar} className="w-4 h-4 rounded-full" alt="avatar"/>
                          <span>{msg.content}</span>
                      </div>
                  </div>
              )
          }

          return (
            <React.Fragment key={msg.id}>
              {showTime && (
                <div className="flex justify-center my-4">
                  <span className={`${timeClass} text-white/40 font-medium`}>{msg.time}</span>
                </div>
              )}
              
              <div className={`flex flex-col gap-1 ${msg.isMe ? 'items-end' : 'items-start'}`}>
                <div className={`flex gap-3 ${msg.isMe ? 'flex-row-reverse' : 'flex-row'}`}>
                  {!msg.isMe && <img src={msg.senderAvatar} alt={msg.senderName} className={`${avatarClass} object-cover bg-gray-800 shadow-sm`} />}
                  <div className={`flex flex-col max-w-[80%] ${msg.isMe ? 'items-end' : 'items-start'}`}>
                    {!msg.isMe && msg.senderName && (
                      <span className={`${senderNameClass} text-gray-500 mb-1 ml-1`}>{msg.senderName}</span>
                    )}
                    <div className="relative group transition-all duration-300">
                      <div 
                        onClick={(e) => { e.stopPropagation(); setActiveMessageId(activeMessageId === msg.id ? null : msg.id); }}
                        className={`
                          cursor-pointer relative ${bubblePaddingClass} shadow-sm break-words ${bubbleTextClass}
                          ${msg.isMe 
                            ? 'bg-blue-600 text-white rounded-[20px] rounded-br-[4px]' 
                            : 'bg-[#2c2c2e] text-gray-100 rounded-[20px] rounded-bl-[4px] border border-white/5'}
                          ${msg.type === 'voice' ? 'min-w-[80px] flex items-center' : ''}
                          ${activeMessageId === msg.id ? 'ring-2 ring-blue-500/50 scale-[1.02]' : ''}
                        `}
                      >
                        {msg.type === 'text' && <span>{msg.content}</span>}
                        {msg.type === 'idea-card' && msg.ideaData && (
                            <div className="flex flex-col gap-2 min-w-[200px]">
                                <div className="flex items-center gap-2 border-b border-white/10 pb-2 mb-1">
                                    <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                                    <span className="text-xs font-bold text-red-400 uppercase tracking-wider">New Idea Detected</span>
                                </div>
                                <div>
                                    <span className="text-[10px] text-gray-400 uppercase font-bold">Name</span>
                                    <div className="text-sm font-bold text-white">{msg.ideaData.title}</div>
                                </div>
                                <div>
                                    <span className="text-[10px] text-gray-400 uppercase font-bold">Pain Point</span>
                                    <div className="text-xs text-gray-300">{msg.ideaData.painPoint}</div>
                                </div>
                                <div>
                                    <span className="text-[10px] text-gray-400 uppercase font-bold">Suggestion</span>
                                    <div className="text-xs text-blue-300">{msg.ideaData.suggestion}</div>
                                </div>
                                <div className="grid grid-cols-3 gap-1 mt-2 pt-2 border-t border-white/10">
                                    <button className="bg-white/10 hover:bg-white/20 text-[10px] py-1.5 rounded text-center transition-colors">
                                        1. Detail
                                    </button>
                                    <button className="bg-white/10 hover:bg-white/20 text-[10px] py-1.5 rounded text-center transition-colors">
                                        2. PRD
                                    </button>
                                    <button className="bg-white/10 hover:bg-white/20 text-[10px] py-1.5 rounded text-center transition-colors">
                                        3. Pool
                                    </button>
                                </div>
                            </div>
                        )}
                        {msg.type === 'reply' && (
                          <div className="flex flex-col">
                            <span>{msg.content}</span>
                            <div className="mt-1.5 pt-1.5 border-t border-white/10 relative opacity-70">
                              <div className={`${timeClass} text-white/80 italic`}>{msg.replyContext}</div>
                            </div>
                          </div>
                        )}
                        {msg.type === 'voice' && (
                          <div className="flex items-center gap-2">
                            <Wifi className="transform rotate-90 text-white/80" size={14 * iconScale} />
                            <span className="font-medium">{msg.voiceDuration}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Context Menu - Glass Style */}
                {activeMessageId === msg.id && (
                    <div className={`w-full max-w-[280px] ${msg.isMe ? 'mr-12' : 'ml-12'} animate-fade-in-up origin-top z-10 mt-2`}>
                        <div className="bg-[#1c1c1e]/90 backdrop-blur-xl rounded-[20px] p-3 flex flex-col gap-3 border border-white/20 shadow-2xl">
                            <div className="flex items-center gap-2 px-3 py-2 bg-black/40 rounded-xl border border-white/10 focus-within:ring-1 focus-within:ring-blue-500 transition-all">
                                <Sparkles size={14} className="text-blue-400 shrink-0" />
                                <input 
                                    className="flex-1 bg-transparent text-[12px] outline-none text-white placeholder-gray-500 min-w-0"
                                    placeholder="Ask AI..."
                                    value={customPrompt}
                                    onChange={(e) => setCustomPrompt(e.target.value)}
                                />
                                <button className={`p-1 rounded-full ${customPrompt.trim() ? 'bg-blue-500 text-white' : 'bg-white/10 text-gray-500'}`}>
                                    <ArrowUp size={12} />
                                </button>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={() => handleReplyClick(msg)} className="flex-1 text-[11px] font-bold text-white bg-white/10 hover:bg-white/20 py-2 rounded-lg transition-colors">Reply</button>
                                <button onClick={() => handleTaskClick(msg)} className="flex-1 text-[11px] font-bold text-white bg-white/10 hover:bg-white/20 py-2 rounded-lg transition-colors">Task</button>
                            </div>
                             
                             {/* Content - Reply Suggestions */}
                             {aiContext.mode === 'reply' && aiContext.data && (
                                <div className="space-y-1">
                                    {(aiContext.data as string[]).map((suggestion, idx) => (
                                        <button key={idx} onClick={() => handleSuggestionSelect(suggestion)} className="w-full text-left text-[11px] text-gray-300 bg-white/5 hover:bg-white/10 p-2 rounded-lg border border-white/5 transition-colors">{suggestion}</button>
                                    ))}
                                </div>
                            )}

                            {/* Content - Task Suggestions */}
                            {aiContext.mode === 'task' && aiContext.data && (
                                <div className="space-y-1 mt-1 animate-fade-in">
                                    <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                                        <CheckSquare size={10} className="text-green-500" /> Suggested Tasks
                                    </div>
                                    {(aiContext.data as string[]).map((task, idx) => (
                                        <button key={idx} onClick={() => handleConfirmAddTask(task)} className="w-full text-left text-[11px] text-white bg-green-500/10 hover:bg-green-500/20 p-2 rounded-lg border border-green-500/20 transition-colors flex items-center gap-2 group">
                                            <PlusCircle size={12} className="text-green-500 group-hover:scale-110 transition-transform"/>
                                            <span>Add to list: "{task}"</span>
                                        </button>
                                    ))}
                                </div>
                            )}

                             {/* Loading State */}
                            {aiContext.mode === 'loading' && (
                                <div className="flex justify-center py-2">
                                    <Loader2 size={16} className="animate-spin text-white/50" />
                                </div>
                            )}
                        </div>
                    </div>
                )}
              </div>
            </React.Fragment>
          );
        })}
      </div>

      {/* Mention Popup */}
      {mentionSearch.active && filteredMentionMembers.length > 0 && (
          <div className="absolute bottom-20 left-4 right-4 z-[70] animate-fade-in-up">
              <div className="bg-[#1c1c1e]/95 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden max-h-[240px] flex flex-col">
                  <div className="px-3 py-2 border-b border-white/5 text-[10px] font-bold text-white/50 bg-white/5 uppercase tracking-wider">
                      Mention Member
                  </div>
                  <div className="overflow-y-auto no-scrollbar">
                      {filteredMentionMembers.map(member => (
                          <button
                              key={member.id}
                              onClick={() => handleSelectMention(member.name.split(' ')[0])} // Use first name for cleaner mention
                              className="w-full px-3 py-2.5 flex items-center gap-3 hover:bg-blue-500/20 hover:text-white transition-colors group"
                          >
                              <div className="relative">
                                <img src={member.avatar} className="w-8 h-8 rounded-lg object-cover bg-gray-800" alt={member.name}/>
                                {groupParticipants.has(member.id) && (
                                    <div className="absolute -bottom-1 -right-1 bg-green-500 w-2.5 h-2.5 rounded-full border border-[#1c1c1e]"></div>
                                )}
                              </div>
                              <div className="flex flex-col items-start">
                                  <span className="text-sm font-bold text-gray-200 group-hover:text-white">{member.name}</span>
                                  <span className="text-[10px] text-gray-500 group-hover:text-blue-200">{member.role}</span>
                              </div>
                          </button>
                      ))}
                  </div>
              </div>
          </div>
      )}

      {/* Input Area - Floating Capsule */}
      <div className={`absolute bottom-0 left-0 right-0 bg-[#1c1c1e]/80 backdrop-blur-xl border-t border-white/10 p-2 flex items-end gap-2 z-[60] rounded-b-[32px] ${isEmbedded ? 'pb-3' : 'pb-6'}`}>
        <button 
            onClick={() => setShowPlusMenu(!showPlusMenu)}
            className={`p-2.5 rounded-full transition-colors ${showPlusMenu ? 'bg-white text-black' : 'bg-gray-800 text-gray-400 hover:text-white'}`}
        >
            <Plus size={20} className={`transition-transform duration-300 ${showPlusMenu ? 'rotate-45' : ''}`} />
        </button>
        <div className="flex-1 bg-[#2c2c2e] rounded-[24px] min-h-[44px] px-4 py-2.5 flex items-center border border-white/10 focus-within:border-white/30 transition-colors relative">
           <input 
            ref={inputRef}
            type="text" 
            className={`w-full bg-transparent outline-none ${inputClass} text-white placeholder-gray-500`} 
            placeholder="Message (@Steve, @everyone)"
            value={inputValue} 
            onChange={handleInputChange} 
            onKeyDown={(e) => {
                if (e.key === 'Enter') {
                    if (mentionSearch.active && filteredMentionMembers.length > 0) {
                        e.preventDefault();
                        handleSelectMention(filteredMentionMembers[0].name.split(' ')[0]);
                    } else {
                        handleSendMessage();
                    }
                }
            }} 
           />
           <button className="text-gray-400 hover:text-white ml-2">
               <Smile size={20} />
           </button>
        </div>
        {inputValue.trim() ? (
             <button onClick={handleSendMessage} className="p-2.5 bg-blue-500 text-white rounded-full shadow-lg shadow-blue-500/30 animate-scale-in">
                <ArrowUp size={20} strokeWidth={3} />
             </button>
        ) : (
            <button className="p-2.5 rounded-full bg-gray-800 text-gray-400">
                <Wifi className="transform rotate-90" size={20} />
            </button>
        )}
      </div>

      {/* Add Member Modal */}
      {showAddMemberModal && (
        <div className="absolute inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center animate-fade-in">
            <div className="bg-[#1c1c1e] w-full sm:w-[360px] sm:rounded-[24px] rounded-t-[24px] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[85%] animate-slide-in-up">
                <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
                    <span className="text-sm font-bold text-white">Add Members</span>
                    <button onClick={() => setShowAddMemberModal(false)} className="p-1 bg-white/10 rounded-full text-gray-400 hover:text-white">
                        <X size={16} />
                    </button>
                </div>
                <div className="p-3">
                    <div className="bg-black/40 rounded-xl flex items-center px-3 py-2 border border-white/10 focus-within:border-blue-500/50 transition-colors">
                        <Search size={14} className="text-gray-500 mr-2" />
                        <input placeholder="Search bots or people..." className="bg-transparent text-xs text-white outline-none w-full placeholder-gray-600" />
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-4 custom-scrollbar">
                    
                    {/* Bot Section */}
                    <div className="px-2">
                        <div className="text-[10px] font-bold text-gray-500 uppercase mb-2 flex items-center gap-1.5">
                            <Sparkles size={10} className="text-blue-500" />
                            AI Team Members
                        </div>
                        <div className="space-y-1">
                            {AI_TEAM_MEMBERS.filter(m => m.name !== chat.name).map(member => {
                                const isSelected = selectedMemberIds.has(member.id);
                                return (
                                <button 
                                    key={member.id}
                                    onClick={() => toggleMemberSelection(member.id)}
                                    className={`w-full flex items-center gap-3 p-2 rounded-xl transition-colors group ${isSelected ? 'bg-white/10' : 'hover:bg-white/5'}`}
                                >
                                    <div className="relative">
                                        <img src={member.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" alt={member.name} />
                                        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-blue-500 rounded-full border-2 border-[#1c1c1e]"></div>
                                    </div>
                                    <div className="flex-1 text-left">
                                        <div className="text-sm font-bold text-white">{member.name}</div>
                                        <div className="text-[10px] text-gray-400">{member.role}</div>
                                    </div>
                                    <div className={`w-6 h-6 rounded-full border flex items-center justify-center transition-all ${
                                        isSelected 
                                        ? 'bg-blue-500 border-blue-500 text-white' 
                                        : 'border-white/20 group-hover:border-white/40 text-white/50'
                                    }`}>
                                        {isSelected ? <Check size={14} /> : <Plus size={14} />}
                                    </div>
                                </button>
                            )})}
                        </div>
                    </div>

                    {/* Contacts Section */}
                    <div className="px-2">
                         <div className="text-[10px] font-bold text-gray-500 uppercase mb-2 flex items-center gap-1.5">
                            <Users size={10} className="text-green-500" />
                            Contacts & Colleagues
                        </div>
                        <div className="space-y-1">
                            {CONTACTS.filter(m => m.name !== chat.name).map(contact => {
                                const isSelected = selectedMemberIds.has(contact.id);
                                return (
                                <button 
                                    key={contact.id}
                                    onClick={() => toggleMemberSelection(contact.id)}
                                    className={`w-full flex items-center gap-3 p-2 rounded-xl transition-colors group ${isSelected ? 'bg-white/10' : 'hover:bg-white/5'}`}
                                >
                                    <div className="relative">
                                        <img src={contact.avatar} className="w-10 h-10 rounded-full object-cover border border-white/10" alt={contact.name} />
                                    </div>
                                    <div className="flex-1 text-left">
                                        <div className="text-sm font-bold text-white">{contact.name}</div>
                                        <div className="text-[10px] text-gray-400">{contact.role}</div>
                                    </div>
                                    <div className={`w-6 h-6 rounded-full border flex items-center justify-center transition-all ${
                                        isSelected 
                                        ? 'bg-green-500 border-green-500 text-white' 
                                        : 'border-white/20 group-hover:border-white/40 text-white/50'
                                    }`}>
                                        {isSelected ? <Check size={14} /> : <Plus size={14} />}
                                    </div>
                                </button>
                            )})}
                        </div>
                    </div>
                </div>

                {/* Footer Action */}
                <div className="p-4 border-t border-white/10 bg-white/5">
                    <button 
                        onClick={handleConfirmAddMembers}
                        disabled={selectedMemberIds.size === 0}
                        className={`w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
                            selectedMemberIds.size > 0 
                            ? 'bg-blue-600 text-white shadow-lg hover:bg-blue-500 active:scale-95' 
                            : 'bg-white/10 text-white/30 cursor-not-allowed'
                        }`}
                    >
                        {selectedMemberIds.size > 0 ? (
                            <>
                                <UserPlus size={18} />
                                <span>Add {selectedMemberIds.size} Member{selectedMemberIds.size > 1 ? 's' : ''}</span>
                            </>
                        ) : (
                            <span>Select members to add</span>
                        )}
                    </button>
                </div>
            </div>
        </div>
      )}

      {showFollowUpView && (
        <FollowUpTimelineView 
            items={followUpItems} 
            onClose={() => setShowFollowUpView(false)} 
            onAddToTask={(content) => {
                onAddTask({
                    title: content,
                    assignee: 'Me',
                    priority: 'Medium',
                    status: 'Pending'
                });
            }}
        />
      )}
    </div>
  );
};

export default ChatDetailScreen;
