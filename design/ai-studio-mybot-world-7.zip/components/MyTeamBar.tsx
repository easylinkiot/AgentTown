
import React, { useState } from 'react';
import { Plus, Settings2, MessageSquare, UserPlus, ScanLine, Sparkles } from 'lucide-react';
import { TeamMember } from '../types';

interface MyTeamBarProps {
  members: TeamMember[];
  onMemberClick: (member: TeamMember) => void;
  onEditMember: (member: TeamMember) => void;
  onAddClick: () => void;
  onStartGroup?: () => void;
  onAddFriend?: () => void;
}

const MyTeamBar: React.FC<MyTeamBarProps> = ({ members, onMemberClick, onEditMember, onAddClick, onStartGroup, onAddFriend }) => {
  const [showMenu, setShowMenu] = useState(false);

  return (
    <div className="w-full flex items-end justify-center pointer-events-none pb-1">
      {/* Dock Container - Capsule Shape */}
      <div className="bg-[#1c1c1e]/90 backdrop-blur-2xl border border-white/10 rounded-full shadow-[0_8px_32px_rgba(0,0,0,0.5)] pointer-events-auto ring-1 ring-white/5 relative max-w-[85vw] flex items-center">
        
        {/* Fixed Section: Add Button */}
        <div className="relative shrink-0 pl-4 py-3">
            <button 
                onClick={() => setShowMenu(!showMenu)}
                className={`w-[42px] h-[42px] rounded-[14px] border border-white/10 border-dashed flex items-center justify-center transition-all active:scale-95 group ${showMenu ? 'bg-white text-black border-white' : 'bg-white/5 hover:bg-white/10 text-white/40 hover:text-white'}`}
            >
                <Plus size={20} className={`transition-transform duration-300 ${showMenu ? 'rotate-45' : 'group-hover:scale-110'}`}/>
            </button>

            {/* Popup Menu */}
            {showMenu && (
                <div className="absolute bottom-full left-0 mb-4 bg-[#2c2c2e] rounded-xl shadow-2xl border border-white/10 overflow-hidden w-40 flex flex-col py-1 z-[100] animate-scale-in origin-bottom-left">
                    <button 
                        onClick={() => {
                            setShowMenu(false);
                            onStartGroup?.();
                        }}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-white/10 text-white transition-colors text-sm text-left"
                    >
                        <MessageSquare size={18} />
                        <span>发起群聊</span>
                    </button>
                    <div className="h-[1px] bg-white/5 mx-4"></div>
                    <button 
                        onClick={() => {
                            setShowMenu(false);
                            onAddFriend?.();
                        }}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-white/10 text-white transition-colors text-sm text-left"
                    >
                        <UserPlus size={18} />
                        <span>添加朋友</span>
                    </button>
                    <div className="h-[1px] bg-white/5 mx-4"></div>
                    <button 
                        onClick={() => {
                            setShowMenu(false);
                            onAddClick();
                        }}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-white/10 text-white transition-colors text-sm text-left"
                    >
                        <div className="relative">
                            <UserPlus size={18} />
                            <div className="absolute -bottom-1 -right-1 bg-blue-500 w-2 h-2 rounded-full border border-[#2c2c2e]"></div>
                        </div>
                        <span>添加Bot</span>
                    </button>
                    <div className="h-[1px] bg-white/5 mx-4"></div>
                    <button className="flex items-center gap-3 px-4 py-3 hover:bg-white/10 text-white transition-colors text-sm text-left">
                        <ScanLine size={18} />
                        <span>扫一扫</span>
                    </button>
                    
                    {/* Triangle Pointer */}
                    <div className="absolute -bottom-1.5 left-4 w-3 h-3 bg-[#2c2c2e] transform rotate-45 border-r border-b border-white/10"></div>
                </div>
            )}
        </div>

        {/* Vertical Divider */}
        <div className="w-[1px] h-6 bg-white/10 mx-1 shrink-0"></div>

        {/* Scrollable Area: Members */}
        <div className="flex items-center gap-3 pr-4 py-3 overflow-x-auto no-scrollbar scroll-smooth">
            {members.map((member) => (
            <div key={member.id} className="relative group flex flex-col items-center justify-center shrink-0">
                <button
                    onClick={() => onMemberClick(member)}
                    className="transition-transform active:scale-95"
                >
                    {/* Avatar Container - Squircle */}
                    <div className="w-[42px] h-[42px] rounded-[14px] overflow-hidden border border-white/10 group-hover:border-white/40 transition-colors shadow-lg relative bg-gray-800">
                        <img 
                            src={member.avatar} 
                            alt={member.name} 
                            className="w-full h-full object-cover"
                        />
                        {/* Online Indicator (Green Dot) */}
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#00e676] border-[2px] border-[#1c1c1e] rounded-full"></div>
                    </div>
                </button>
                
                {/* Tooltip on Hover */}
                <div className="absolute bottom-full mb-3 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                    <div className="bg-black/90 backdrop-blur-md text-white text-[10px] font-bold px-2 py-1 rounded-lg border border-white/10 whitespace-nowrap shadow-xl">
                        {member.name}
                    </div>
                </div>

                {/* Edit Button Overlay (Top Right) */}
                <button 
                    onClick={(e) => { e.stopPropagation(); onEditMember(member); }}
                    className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-gray-800 rounded-full border border-white/20 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-blue-600 hover:border-blue-400 z-40 shadow-md transform scale-90 group-hover:scale-100"
                    title="Edit Bot"
                >
                    <Settings2 size={10} />
                </button>
            </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default MyTeamBar;
