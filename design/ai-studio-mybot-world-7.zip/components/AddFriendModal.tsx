import React, { useState } from 'react';
import { X, Search, QrCode, Smartphone, Mail, ChevronRight, User } from 'lucide-react';

interface AddFriendModalProps {
  onClose: () => void;
}

const AddFriendModal: React.FC<AddFriendModalProps> = ({ onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#1c1c1e] w-full max-w-md rounded-[32px] shadow-2xl overflow-hidden animate-scale-in border border-white/10 flex flex-col h-[600px] max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/5">
            <h2 className="text-white font-bold text-lg">Add Friend</h2>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full text-white/70 transition-colors">
                <X size={20} />
            </button>
        </div>

        {/* Search Bar */}
        <div className="p-4">
            <div className="bg-black/40 border border-white/10 rounded-xl flex items-center px-3 py-3 gap-3 focus-within:border-green-500/50 transition-colors">
                <Search size={18} className="text-gray-500" />
                <input 
                    type="text" 
                    placeholder="Account ID / Phone / Email" 
                    className="bg-transparent w-full text-white text-sm outline-none placeholder-gray-600"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    autoFocus
                />
            </div>
            {searchTerm && (
                <div className="mt-4 p-4 bg-white/5 rounded-xl flex items-center gap-3 cursor-pointer hover:bg-white/10 transition-colors border border-white/5">
                    <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center shrink-0">
                        <Search size={20} className="text-white" />
                    </div>
                    <div>
                        <div className="text-white font-medium text-sm">Search: <span className="text-green-400">{searchTerm}</span></div>
                        <div className="text-xs text-gray-500">Search global directory</div>
                    </div>
                </div>
            )}
        </div>

        {/* My ID Card */}
        <div className="px-6 pb-4 flex justify-center">
            <div className="flex items-center gap-2 text-xs text-gray-500">
                <span>My ID:</span>
                <span className="text-white font-mono font-medium">wxid_888888</span>
                <QrCode size={14} className="text-gray-500 ml-1" />
            </div>
        </div>

        {/* Options List */}
        <div className="flex-1 overflow-y-auto border-t border-white/5">
            <div className="p-2 space-y-1">
                <OptionItem icon={QrCode} title="Scan QR Code" sub="Scan friend's QR code" color="bg-blue-500" />
                <OptionItem icon={Smartphone} title="Mobile Contacts" sub="Find friends from contacts" color="bg-green-500" />
                <OptionItem icon={Mail} title="Invite via Email" sub="Send email invitation" color="bg-purple-500" />
                <OptionItem icon={User} title="Official Accounts" sub="Follow official brands" color="bg-orange-500" />
            </div>
        </div>
      </div>
    </div>
  );
};

const OptionItem = ({ icon: Icon, title, sub, color }: any) => (
    <button className="w-full flex items-center gap-4 p-4 hover:bg-white/5 rounded-xl transition-colors group">
        <div className={`w-10 h-10 rounded-full ${color} flex items-center justify-center text-white shadow-lg shrink-0`}>
            <Icon size={20} />
        </div>
        <div className="flex-1 text-left">
            <div className="text-white font-medium text-sm">{title}</div>
            <div className="text-xs text-gray-500">{sub}</div>
        </div>
        <ChevronRight size={16} className="text-gray-600 group-hover:text-white transition-colors" />
    </button>
);

export default AddFriendModal;
