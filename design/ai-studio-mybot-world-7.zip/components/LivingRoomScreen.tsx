
import React, { useState } from 'react';
import { ChevronLeft, Home, Zap, Gamepad2, Briefcase, Coins, Check, X, Palette, LayoutGrid, Film, Trophy, Users, FileText, TrendingUp } from 'lucide-react';

interface LivingRoomScreenProps {
  onBack: () => void;
  currentHouseType: number;
  onUpdateHouseType: (type: number) => void;
  onOpenMarket: () => void; // Link to existing config/market
}

interface AppIconProps {
  label: string;
  icon: React.ReactNode;
  color: string;
  onClick: () => void;
}

const AppIcon: React.FC<AppIconProps> = ({ label, icon, color, onClick }) => (
  <button 
    onClick={onClick}
    className="flex flex-col items-center gap-2 group p-2 active:scale-95 transition-transform"
  >
    <div className={`w-14 h-14 ${color} rounded-2xl shadow-lg flex items-center justify-center text-white border border-white/20 group-hover:scale-105 transition-transform`}>
      {icon}
    </div>
    <span className="text-xs font-medium text-white shadow-black/50 drop-shadow-md">{label}</span>
  </button>
);

const LivingRoomScreen: React.FC<LivingRoomScreenProps> = ({ onBack, currentHouseType, onUpdateHouseType, onOpenMarket }) => {
  const [activeModal, setActiveModal] = useState<'house' | 'interests' | 'jobs' | 'assets' | null>(null);

  // House Styles Data
  const HOUSE_STYLES = [
    { id: 0, name: 'Cozy Cottage', color: 'bg-orange-100', roof: 'bg-red-700' },
    { id: 1, name: 'Modern Blue', color: 'bg-blue-100', roof: 'bg-slate-700' },
    { id: 2, name: 'Minimalist', color: 'bg-white', roof: 'bg-indigo-800' },
    { id: 3, name: 'Golden Manor', color: 'bg-yellow-50', roof: 'bg-amber-800' },
  ];

  const renderModalContent = () => {
    switch(activeModal) {
      case 'house':
        return (
          <div className="p-4">
             <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Palette className="text-orange-500" /> Decorate Exterior
             </h3>
             <div className="grid grid-cols-2 gap-4">
                {HOUSE_STYLES.map((style) => (
                    <button 
                        key={style.id}
                        onClick={() => { onUpdateHouseType(style.id); setActiveModal(null); }}
                        className={`p-3 rounded-xl border-2 flex flex-col items-center gap-3 transition-all ${currentHouseType === style.id ? 'border-green-500 bg-green-50' : 'border-gray-100 bg-gray-50 hover:bg-white'}`}
                    >
                        {/* Mini visual representation of the house */}
                        <div className="relative flex flex-col items-center pt-2">
                             <div className={`w-12 h-8 ${style.roof} rounded-t-sm clip-roof`}></div>
                             <div className={`w-10 h-8 ${style.color} shadow-sm -mt-0.5`}></div>
                        </div>
                        <span className={`text-xs font-bold ${currentHouseType === style.id ? 'text-green-700' : 'text-gray-600'}`}>
                            {style.name}
                        </span>
                    </button>
                ))}
             </div>
             <style>{`.clip-roof { clip-path: polygon(50% 0%, 0% 100%, 100% 100%); }`}</style>
          </div>
        );
      case 'interests':
        return (
          <div className="p-4 grid grid-cols-2 gap-3">
             <div className="bg-purple-50 p-3 rounded-xl flex items-center gap-3">
                 <div className="bg-purple-100 p-2 rounded-lg text-purple-600"><Gamepad2 size={20}/></div>
                 <span className="text-sm font-bold text-gray-700">Games</span>
             </div>
             <div className="bg-red-50 p-3 rounded-xl flex items-center gap-3">
                 <div className="bg-red-100 p-2 rounded-lg text-red-600"><Film size={20}/></div>
                 <span className="text-sm font-bold text-gray-700">Movies</span>
             </div>
             <div className="bg-green-50 p-3 rounded-xl flex items-center gap-3">
                 <div className="bg-green-100 p-2 rounded-lg text-green-600"><Trophy size={20}/></div>
                 <span className="text-sm font-bold text-gray-700">Sports</span>
             </div>
             <div className="bg-blue-50 p-3 rounded-xl flex items-center gap-3">
                 <div className="bg-blue-100 p-2 rounded-lg text-blue-600"><Users size={20}/></div>
                 <span className="text-sm font-bold text-gray-700">Social</span>
             </div>
          </div>
        );
      case 'jobs':
          return (
            <div className="p-4 space-y-3">
                <div className="bg-white border border-gray-100 p-3 rounded-xl shadow-sm">
                    <div className="flex justify-between items-start mb-1">
                        <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">Content Creation</span>
                        <span className="text-xs font-bold text-green-600">$500/mo</span>
                    </div>
                    <p className="text-sm font-bold text-gray-800">Video Script Writer</p>
                    <p className="text-xs text-gray-500">Create engaging scripts for tech reviews.</p>
                </div>
                <div className="bg-white border border-gray-100 p-3 rounded-xl shadow-sm">
                    <div className="flex justify-between items-start mb-1">
                        <span className="text-xs font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded">Projects</span>
                        <span className="text-xs font-bold text-green-600">$1200</span>
                    </div>
                    <p className="text-sm font-bold text-gray-800">React Dashboard</p>
                    <p className="text-xs text-gray-500">Build a responsive admin panel.</p>
                </div>
            </div>
          );
      case 'assets':
          return (
              <div className="p-4 text-center">
                  <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white p-6 rounded-2xl shadow-lg mb-4">
                      <p className="text-xs opacity-80 font-medium uppercase tracking-wider">Total Earnings</p>
                      <h2 className="text-3xl font-bold mt-1">$12,450.00</h2>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                      <button className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                          <TrendingUp className="mx-auto mb-2 text-green-500" />
                          <span className="text-xs font-bold text-gray-700">Analytics</span>
                      </button>
                      <button className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                          <FileText className="mx-auto mb-2 text-blue-500" />
                          <span className="text-xs font-bold text-gray-700">Contracts</span>
                      </button>
                  </div>
              </div>
          );
      default: return null;
    }
  };

  return (
    <div className="w-full h-full relative font-sans overflow-hidden bg-gray-900">
      
      {/* Immersive Background */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-1000 scale-110"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1600210492493-0946911123ea?q=80&w=1600&auto=format&fit=crop")' }}
      >
        <div className="absolute inset-0 bg-black/30 backdrop-blur-[1px]"></div>
      </div>

      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 pt-safe-top flex items-center justify-between">
         <button 
            onClick={onBack}
            className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/30 hover:bg-white/30 transition-colors"
         >
            <ChevronLeft size={24} />
         </button>
         <div className="bg-black/30 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/10">
            <span className="text-white text-xs font-bold flex items-center gap-2">
                <Home size={12} /> Living Room
            </span>
         </div>
         <div className="w-10"></div>
      </div>

      {/* App Grid */}
      <div className="absolute top-24 left-0 right-0 z-10 p-6">
        <div className="grid grid-cols-4 gap-y-6">
            <AppIcon 
                label="House" 
                icon={<Home size={28}/>} 
                color="bg-orange-500" 
                onClick={() => setActiveModal('house')}
            />
            <AppIcon 
                label="Skills" 
                icon={<Zap size={28}/>} 
                color="bg-blue-600" 
                onClick={onOpenMarket}
            />
            <AppIcon 
                label="Interests" 
                icon={<Gamepad2 size={28}/>} 
                color="bg-purple-500" 
                onClick={() => setActiveModal('interests')}
            />
            <AppIcon 
                label="Jobs" 
                icon={<Briefcase size={28}/>} 
                color="bg-pink-500" 
                onClick={() => setActiveModal('jobs')}
            />
            <AppIcon 
                label="Assets" 
                icon={<Coins size={28}/>} 
                color="bg-green-500" 
                onClick={() => setActiveModal('assets')}
            />
        </div>
      </div>

      {/* Modal Sheet */}
      {activeModal && (
        <div className="absolute inset-0 z-50 flex items-end">
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setActiveModal(null)}></div>
            <div className="bg-white w-full rounded-t-[32px] shadow-2xl relative animate-slide-in-up pb-8">
                <div className="w-full flex justify-center pt-3 pb-1">
                    <div className="w-12 h-1.5 bg-gray-200 rounded-full"></div>
                </div>
                <div className="flex justify-end px-4">
                    <button onClick={() => setActiveModal(null)} className="p-1 bg-gray-100 rounded-full text-gray-500">
                        <X size={16} />
                    </button>
                </div>
                
                {renderModalContent()}
            </div>
        </div>
      )}

    </div>
  );
};

export default LivingRoomScreen;
