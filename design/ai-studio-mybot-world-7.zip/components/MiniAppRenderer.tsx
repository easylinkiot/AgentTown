
import React, { useState, useMemo, useRef } from 'react';
import { X, RefreshCw, Share2, TrendingUp, TrendingDown, Clock, MessageSquare, Volume2, RotateCw, Tag, BarChart2, Activity, Zap, Eye, CheckSquare, Check, Shirt, Upload, Loader2, Image as ImageIcon, FileText, Sparkles } from 'lucide-react';
import { MiniApp } from '../types';
import * as LucideIcons from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";

interface MiniAppRendererProps {
  app: MiniApp;
  onClose: () => void;
}

// --- Visual Components ---

const Sparkline = ({ data, color = "#10b981", height = 24, width = 60, fill = true }: { data: number[], color?: string, height?: number, width?: number, fill?: boolean }) => {
  if (!data || data.length < 2) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1);
  
  const points = data.map((d, i) => {
    const x = i * step;
    const y = height - ((d - min) / range) * height; // Invert Y
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width={width} height={height} className="overflow-visible">
      <defs>
        <linearGradient id={`grad-${color.replace('#', '')}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={color} stopOpacity={0.2} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      {fill && <polygon points={`0,${height} ${points} ${width},${height}`} fill={`url(#grad-${color.replace('#', '')})`} stroke="none" />}
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={width} cy={height - ((data[data.length-1] - min) / range) * height} r="1.5" fill={color} />
    </svg>
  );
};

const ProgressBar = ({ value, max = 100, color = "bg-blue-500", trackColor = "bg-gray-100", height = "h-1.5" }: { value: number, max?: number, color?: string, trackColor?: string, height?: string }) => {
    const percent = Math.min(100, Math.max(0, (value / max) * 100));
    return (
        <div className={`w-full ${height} ${trackColor} rounded-full overflow-hidden`}>
            <div className={`h-full rounded-full ${color}`} style={{ width: `${percent}%` }}></div>
        </div>
    );
};

const CircularProgress = ({ value, size = 36, color = "#8b5cf6", strokeWidth = 3, label }: { value: number, size?: number, color?: string, strokeWidth?: number, label?: string }) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const offset = circumference - (value / 100) * circumference;

    return (
        <div className="relative flex flex-col items-center gap-1">
            <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
                <svg width={size} height={size} className="transform -rotate-90">
                    <circle cx={size/2} cy={size/2} r={radius} stroke="#f3f4f6" strokeWidth={strokeWidth} fill="none" />
                    <circle cx={size/2} cy={size/2} r={radius} stroke={color} strokeWidth={strokeWidth} fill="none" strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round" />
                </svg>
                <span className="absolute text-[8px] font-bold text-gray-700">{Math.round(value)}%</span>
            </div>
            {label && <span className="text-[8px] text-gray-500 font-medium">{label}</span>}
        </div>
    );
};

// 6. Fashion Designer Template
const FashionDesignerView: React.FC<{ app: MiniApp }> = ({ app }) => {
    const [requirements, setRequirements] = useState('');
    const [referenceImage, setReferenceImage] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [results, setResults] = useState<any>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleGenerate = async () => {
        if (!requirements.trim() && !referenceImage) return;
        setLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            // 1. Generate Production Plan and Image Prompts
            const textResponse = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `作为一名资深服装设计师，根据以下需求和参考图（如果有），请生成：
                1. 服装设计效果图的详细描述（用于AI绘图，英文描述）。
                2. 模特展示图的详细描述（用于AI绘图，英文描述）。
                3. 详细的生产方案（包含面料建议、工艺说明、成本预估，中文描述）。
                
                需求：${requirements}
                
                请以JSON格式返回：
                {
                  "renderingPrompt": "...",
                  "modelPrompt": "...",
                  "productionPlan": "..."
                }`,
                config: { responseMimeType: 'application/json' }
            });

            const planData = JSON.parse(textResponse.text || '{}');

            // 2. Generate Images
            const [renderingImg, modelImg] = await Promise.all([
                ai.models.generateContent({
                    model: 'gemini-2.5-flash-image',
                    contents: planData.renderingPrompt,
                    config: { imageConfig: { aspectRatio: "3:4" } }
                }),
                ai.models.generateContent({
                    model: 'gemini-2.5-flash-image',
                    contents: planData.modelPrompt,
                    config: { imageConfig: { aspectRatio: "3:4" } }
                })
            ]);

            const getImgUrl = (resp: any) => {
                const part = resp.candidates[0].content.parts.find((p: any) => p.inlineData);
                return part ? `data:image/png;base64,${part.inlineData.data}` : null;
            };

            setResults({
                rendering: getImgUrl(renderingImg),
                model: getImgUrl(modelImg),
                plan: planData.productionPlan
            });

        } catch (error) {
            console.error("Fashion generation failed", error);
            alert("生成失败，请重试");
        } finally {
            setLoading(false);
        }
    };

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => setReferenceImage(reader.result as string);
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 overflow-y-auto no-scrollbar">
            <div className="p-5 space-y-6">
                {/* Input Section */}
                <div className="bg-white rounded-[24px] p-5 shadow-sm border border-gray-100 space-y-4">
                    <div className="flex items-center gap-2 mb-1">
                        <LucideIcons.Shirt size={18} className="text-pink-500" />
                        <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wider">设计需求</h3>
                    </div>
                    
                    <textarea 
                        value={requirements}
                        onChange={(e) => setRequirements(e.target.value)}
                        placeholder="描述您的设计灵感、风格、受众..."
                        className="w-full h-24 bg-gray-50 rounded-xl p-3 text-sm text-gray-800 placeholder-gray-400 outline-none border border-gray-100 focus:border-pink-500/30 transition-colors resize-none"
                    />

                    <div className="flex items-center gap-3">
                        <button 
                            onClick={() => fileInputRef.current?.click()}
                            className="flex-1 h-12 bg-gray-50 hover:bg-gray-100 rounded-xl border border-dashed border-gray-300 flex items-center justify-center gap-2 text-gray-500 transition-colors"
                        >
                            {referenceImage ? <LucideIcons.Check size={16} className="text-green-500" /> : <LucideIcons.Upload size={16} />}
                            <span className="text-xs font-bold">{referenceImage ? '参考图已上传' : '上传参考图'}</span>
                        </button>
                        <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                    </div>

                    <button 
                        onClick={handleGenerate}
                        disabled={loading}
                        className="w-full h-12 bg-pink-600 hover:bg-pink-700 disabled:bg-gray-300 text-white rounded-xl font-bold shadow-lg shadow-pink-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                    >
                        {loading ? <LucideIcons.Loader2 size={18} className="animate-spin" /> : <LucideIcons.Sparkles size={18} />}
                        <span>{loading ? '正在生成设计...' : '开始生成设计'}</span>
                    </button>
                </div>

                {/* Results Section */}
                {results && (
                    <div className="space-y-6 animate-fade-in pb-10">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <div className="flex items-center gap-2 ml-1">
                                    <LucideIcons.Image size={14} className="text-blue-500" />
                                    <span className="text-[10px] font-bold text-gray-400 uppercase">设计效果图</span>
                                </div>
                                <div className="aspect-[3/4] bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm">
                                    <img src={results.rendering} className="w-full h-full object-cover" alt="Rendering" />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <div className="flex items-center gap-2 ml-1">
                                    <LucideIcons.Users size={14} className="text-purple-500" />
                                    <span className="text-[10px] font-bold text-gray-400 uppercase">模特展示图</span>
                                </div>
                                <div className="aspect-[3/4] bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm">
                                    <img src={results.model} className="w-full h-full object-cover" alt="Model" />
                                </div>
                            </div>
                        </div>

                        <div className="bg-white rounded-[24px] p-5 shadow-sm border border-gray-100">
                            <div className="flex items-center gap-2 mb-4">
                                <LucideIcons.FileText size={18} className="text-orange-500" />
                                <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wider">生产方案</h3>
                            </div>
                            <div className="text-xs text-gray-600 leading-relaxed whitespace-pre-wrap bg-gray-50 p-4 rounded-xl border border-gray-100">
                                {results.plan}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

// 7. Car Caring Game Template
const CarCaringGameView: React.FC<{ data: any }> = ({ data }) => {
    const [stats, setStats] = useState(data.stats || { cleanliness: 50, fuel: 50, health: 80 });
    const [message, setMessage] = useState("Ready to take care of your car!");

    const handleAction = (action: string) => {
        setStats((prev: any) => {
            const newStats = { ...prev };
            if (action === 'Wash') {
                newStats.cleanliness = Math.min(100, prev.cleanliness + 30);
                setMessage("Car washed! Sparkling clean.");
            } else if (action === 'Refuel') {
                newStats.fuel = Math.min(100, prev.fuel + 40);
                setMessage("Tank full! Ready to go.");
            } else if (action === 'Repair') {
                newStats.health = Math.min(100, prev.health + 20);
                setMessage("Repairs done! Good as new.");
            }
            return newStats;
        });
    };

    return (
        <div className="p-4 flex flex-col h-full bg-gray-50">
            <div className="flex-1 flex flex-col items-center justify-center space-y-6">
                <div className="relative">
                    <div className="w-48 h-32 bg-blue-100 rounded-3xl flex items-center justify-center shadow-lg border-4 border-white">
                        <LucideIcons.Car size={64} className="text-blue-600" />
                    </div>
                    {stats.cleanliness < 40 && (
                        <div className="absolute -top-2 -right-2 bg-yellow-400 text-xs font-bold px-2 py-1 rounded-full shadow-md animate-bounce">
                            Dirty!
                        </div>
                    )}
                    {stats.fuel < 20 && (
                        <div className="absolute -bottom-2 -left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-md animate-pulse">
                            Low Fuel!
                        </div>
                    )}
                </div>

                <div className="w-full space-y-4 bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                    <h3 className="text-center font-bold text-gray-800">{data.carName || 'My Car'}</h3>
                    
                    <div className="space-y-3">
                        <div>
                            <div className="flex justify-between text-xs font-bold text-gray-500 mb-1">
                                <span>Cleanliness</span>
                                <span>{stats.cleanliness}%</span>
                            </div>
                            <ProgressBar value={stats.cleanliness} color="bg-blue-400" />
                        </div>
                        <div>
                            <div className="flex justify-between text-xs font-bold text-gray-500 mb-1">
                                <span>Fuel</span>
                                <span>{stats.fuel}%</span>
                            </div>
                            <ProgressBar value={stats.fuel} color="bg-yellow-400" />
                        </div>
                        <div>
                            <div className="flex justify-between text-xs font-bold text-gray-500 mb-1">
                                <span>Health</span>
                                <span>{stats.health}%</span>
                            </div>
                            <ProgressBar value={stats.health} color="bg-green-400" />
                        </div>
                    </div>
                </div>

                <div className="text-center h-6">
                    <p className="text-xs font-medium text-gray-500 animate-fade-in">{message}</p>
                </div>
            </div>

            <div className="grid grid-cols-3 gap-3 mt-4">
                {(data.actions || ['Wash', 'Refuel', 'Repair']).map((action: string) => (
                    <button
                        key={action}
                        onClick={() => handleAction(action)}
                        className="flex flex-col items-center justify-center p-3 bg-white border border-gray-200 rounded-xl shadow-sm active:scale-95 transition-all hover:bg-gray-50 hover:border-blue-200"
                    >
                        <div className="mb-1 text-blue-500">
                            {action === 'Wash' && <LucideIcons.Droplets size={20} />}
                            {action === 'Refuel' && <LucideIcons.Fuel size={20} />}
                            {action === 'Repair' && <LucideIcons.Wrench size={20} />}
                        </div>
                        <span className="text-[10px] font-bold text-gray-700">{action}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

// --- Main Renderer ---

const MiniAppRenderer: React.FC<MiniAppRendererProps> = ({ app, onClose }) => {
  // Dynamic Icon
  const IconComponent = (LucideIcons as any)[app.icon] || LucideIcons.Zap;

  // Render logic based on app type
  const renderContent = () => {
    switch (app.type) {
      case 'news_feed':
        return <NewsFeedView data={app.content} />;
      case 'flashcard':
        return <FlashcardView data={app.content} />;
      case 'price_tracker':
        return <PriceTrackerView data={app.content} />;
      case 'task_list':
        return <TaskListView data={app.content} />;
      case 'generative_app':
        return <GenerativeAppView data={app.content} />;
      case 'fashion_designer':
        return <FashionDesignerView app={app} />;
      case 'car_caring':
        return <CarCaringGameView data={app.content} />;
      default:
        return <div className="p-4 text-center text-gray-500">不支持的应用类型</div>;
    }
  };

  return (
    <div className="absolute inset-0 z-[70] flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm animate-fade-in">
        <div className="bg-[#F2F2F6] w-full h-[85%] max-w-sm rounded-[32px] shadow-2xl overflow-hidden flex flex-col animate-scale-in border border-white/40">
            
            {/* App Header */}
            <div className="bg-white/80 backdrop-blur-md px-4 py-3 border-b border-gray-200 flex justify-between items-center shrink-0">
                <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-xl ${app.color || 'bg-black'} flex items-center justify-center text-white shadow-md shadow-${app.color?.split('-')[1]}-200`}>
                        <IconComponent size={18} />
                    </div>
                    <div>
                        <h2 className="text-sm font-bold text-gray-900 leading-none">{app.title}</h2>
                        <span className="text-[9px] text-gray-500 font-medium mt-1 block">
                            AI 生成应用
                        </span>
                    </div>
                </div>
                <div className="flex gap-2">
                     <button className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors">
                        <Share2 size={18} />
                     </button>
                     <button onClick={onClose} className="p-2 hover:bg-red-50 hover:text-red-500 rounded-full text-gray-500 transition-colors">
                        <X size={18} />
                     </button>
                </div>
            </div>

            {/* App Body */}
            <div className="flex-1 overflow-y-auto no-scrollbar relative">
                 {renderContent()}
            </div>
            
            {/* App Footer */}
            <div className="bg-white px-4 py-2 border-t border-gray-200 shrink-0 flex justify-between items-center">
                 <span className="text-[9px] text-gray-400 font-medium">AI 自动生成内容</span>
                 <div className="flex items-center gap-1 text-[9px] text-green-600 font-bold bg-green-50 px-2 py-0.5 rounded-full border border-green-100">
                    <Activity size={10} />
                    实时数据
                 </div>
            </div>
        </div>
    </div>
  );
};

// --- Views ---

// 1. News Feed Template
const NewsFeedView: React.FC<{ data: any }> = ({ data }) => {
    const items = Array.isArray(data) ? data : (data.items || []);

    return (
        <div className="p-4 space-y-4">
            <div className="space-y-3">
                {items.map((item: any, idx: number) => {
                    // Simulate random engagement data
                    const views = Math.floor(Math.random() * 5000) + 1000;
                    const heat = Math.floor(Math.random() * 100);
                    
                    return (
                        <div key={idx} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 active:scale-[0.99] transition-transform group">
                            <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                    <span className="text-[9px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
                                        {item.source || '快讯'}
                                    </span>
                                    <span className="text-[9px] text-gray-400 flex items-center gap-0.5">
                                        <Clock size={8} /> {item.time || '2小时前'}
                                    </span>
                                </div>
                                <div className="flex items-center gap-1 text-[9px] text-gray-400">
                                    <Eye size={10} /> {views}
                                </div>
                            </div>
                            
                            <h3 className="text-xs font-bold text-gray-800 leading-snug mb-1.5 group-hover:text-blue-600 transition-colors">
                                {item.title}
                            </h3>
                            <p className="text-[11px] text-gray-500 leading-relaxed line-clamp-2 mb-3">
                                {item.summary}
                            </p>

                            {/* Engagement Viz */}
                            <div className="flex items-center gap-3 pt-2 border-t border-gray-50">
                                <div className="flex-1">
                                    <div className="flex justify-between text-[8px] text-gray-400 mb-0.5">
                                        <span>热度指数</span>
                                        <span className="font-bold text-orange-500">{heat}/100</span>
                                    </div>
                                    <ProgressBar value={heat} color="bg-gradient-to-r from-orange-400 to-red-500" height="h-1" />
                                </div>
                                {item.tag && (
                                    <div className="px-2 py-0.5 bg-gray-50 rounded text-[9px] text-gray-500 font-medium">
                                        #{item.tag}
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

// 2. Flashcard Template
const FlashcardView: React.FC<{ data: any }> = ({ data }) => {
    const [flipped, setFlipped] = useState(false);
    
    // Fallback if data structure varies slightly
    const word = data.word || "Serendipity";
    const phonetic = data.pronunciation || "/ˌser.ənˈdɪp.ə.ti/";
    const def = data.definition || "意外发现珍奇事物的本领；机缘凑巧。";
    const example = data.example || "We found the restaurant by pure serendipity.";

    // Simulated Stats
    const mastery = 72;
    const history = [20, 45, 60, 65, 72];

    return (
        <div className="flex flex-col h-full bg-gray-50">
            {/* Stats Bar */}
            <div className="px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <CircularProgress value={mastery} color="#8b5cf6" size={40} label="掌握度" />
                    <div>
                        <div className="text-[10px] text-gray-400 font-bold uppercase">连续打卡</div>
                        <div className="flex items-baseline gap-1">
                            <span className="text-lg font-black text-gray-800">12</span>
                            <span className="text-[10px] text-gray-500">天</span>
                        </div>
                    </div>
                </div>
                <div className="text-right">
                    <div className="text-[10px] text-gray-400 font-bold uppercase">下次复习</div>
                    <div className="text-xs font-bold text-purple-600">4小时后</div>
                </div>
            </div>

            <div className="flex-1 px-6 pb-6 flex flex-col justify-center">
                <div 
                    className="w-full aspect-[4/5] perspective-1000 cursor-pointer"
                    onClick={() => setFlipped(!flipped)}
                >
                    <div className={`relative w-full h-full duration-500 transform-style-3d transition-transform ${flipped ? 'rotate-y-180' : ''}`}>
                        
                        {/* Front */}
                        <div className="absolute w-full h-full backface-hidden bg-white rounded-[32px] shadow-xl border border-white/60 flex flex-col items-center justify-between p-8 text-center bg-gradient-to-b from-white to-purple-50/30">
                            <div className="w-full flex justify-between items-start">
                                <span className="text-[10px] font-bold text-white bg-purple-500 px-2 py-0.5 rounded-full shadow-sm shadow-purple-200">每日单词</span>
                                <Volume2 size={16} className="text-gray-400 hover:text-purple-600 transition-colors" />
                            </div>
                            
                            <div>
                                <h2 className="text-3xl font-black text-gray-800 mb-2 tracking-tight">{word}</h2>
                                <div className="inline-block bg-gray-100 px-3 py-1 rounded-full text-xs font-mono text-gray-500 border border-gray-200">
                                    {phonetic}
                                </div>
                            </div>

                            <div className="w-full">
                                <div className="flex justify-center mb-2">
                                     <span className="text-[9px] text-gray-400 font-medium animate-pulse">点击翻转卡片</span>
                                </div>
                                {/* Simple visual decor */}
                                <div className="h-1 w-16 bg-gray-100 rounded-full mx-auto"></div>
                            </div>
                        </div>

                        {/* Back */}
                        <div className="absolute w-full h-full backface-hidden bg-gray-900 text-white rounded-[32px] shadow-xl flex flex-col p-8 rotate-y-180 border border-gray-700">
                             <div className="flex-1 flex flex-col justify-center text-center">
                                <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-2">释义</span>
                                <p className="text-sm font-medium leading-relaxed mb-6">{def}</p>
                                
                                <div className="bg-white/10 p-4 rounded-2xl border border-white/5 text-left mb-6">
                                    <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest block mb-1">例句</span>
                                    <p className="text-xs italic text-gray-300">"{example}"</p>
                                </div>
                             </div>

                             <div className="border-t border-white/10 pt-4">
                                <div className="flex justify-between items-end mb-2">
                                    <span className="text-[9px] font-bold text-gray-500 uppercase">记忆曲线</span>
                                </div>
                                <SparklesSparkline data={history} color="#a78bfa" height={30} width={200} />
                             </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="px-6 pb-4 flex justify-center">
                 <button className="flex items-center gap-2 text-xs font-bold text-gray-500 hover:text-gray-900 transition-colors bg-white px-4 py-2 rounded-full shadow-sm border border-gray-100">
                    <RotateCw size={14} /> 下一个
                </button>
            </div>
            <style>{`.perspective-1000 { perspective: 1000px; } .transform-style-3d { transform-style: preserve-3d; } .backface-hidden { backface-visibility: hidden; } .rotate-y-180 { transform: rotateY(180deg); }`}</style>
        </div>
    );
};

// 3. Price Tracker Template
const PriceTrackerView: React.FC<{ data: any }> = ({ data }) => {
    const items = Array.isArray(data) ? data : (data.items || []);

    return (
        <div className="p-4 space-y-5">
             {/* Category Tabs */}
             <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                 {['全部', '鞋履', '数码', '家居'].map((cat, i) => (
                     <button key={i} className={`px-3 py-1.5 rounded-full text-[10px] font-bold whitespace-nowrap transition-colors ${i===0 ? 'bg-black text-white shadow-md' : 'bg-white text-gray-500 border border-gray-200 hover:bg-gray-50'}`}>
                         {cat}
                     </button>
                 ))}
             </div>

             {/* Items List */}
             <div className="space-y-4">
                 {items.map((item: any, idx: number) => {
                     // Generate Simulated Price History
                     const basePrice = item.price || 100;
                     const history = [
                         basePrice * 1.05, 
                         basePrice * 1.02, 
                         basePrice * 1.08, 
                         basePrice * 1.04, 
                         basePrice * 0.98,
                         basePrice
                     ];
                     const isDrop = item.trend === 'down';
                     const percentChange = Math.floor(Math.random() * 15) + 5;

                     return (
                         <div key={idx} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col gap-3">
                             {/* Top Row: Icon + Info + Current Price */}
                             <div className="flex gap-3">
                                <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center text-2xl border border-gray-100 shadow-inner">
                                    {item.product?.includes('LEGO') ? '🧱' : item.product?.includes('Lululemon') ? '🧘' : '👟'}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <h4 className="text-xs font-bold text-gray-800 truncate mb-1">{item.product}</h4>
                                    <div className="flex items-center gap-1 text-[9px] text-gray-400">
                                        <Tag size={10} /> {item.retailer}
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className="text-sm font-black text-gray-900">¥{item.price}</div>
                                    <div className={`text-[9px] font-bold flex items-center justify-end gap-0.5 ${isDrop ? 'text-green-600' : 'text-red-500'}`}>
                                        {isDrop ? <TrendingDown size={10} /> : <TrendingUp size={10} />}
                                        {percentChange}%
                                    </div>
                                </div>
                             </div>

                             {/* Bottom Row: Sparkline + Action */}
                             <div className="bg-gray-50 rounded-xl p-3 flex items-center justify-between border border-gray-100">
                                 <div className="flex flex-col gap-1">
                                     <span className="text-[8px] font-bold text-gray-400 uppercase">30天价格趋势</span>
                                     <Sparkline data={history} color={isDrop ? "#10b981" : "#ef4444"} width={80} height={24} />
                                 </div>
                                 <div className="h-6 w-[1px] bg-gray-200"></div>
                                 <button className="text-[10px] font-bold bg-black text-white px-3 py-1.5 rounded-lg hover:scale-105 transition-transform shadow-md">
                                     查看详情
                                 </button>
                             </div>
                         </div>
                     );
                 })}
             </div>
             
             {/* Total Savings Card */}
             <div className="bg-gradient-to-r from-orange-400 to-pink-500 rounded-2xl p-4 text-white shadow-lg shadow-orange-200">
                 <div className="flex justify-between items-center mb-2">
                     <span className="text-[10px] font-bold opacity-80 uppercase tracking-wider">潜在节省</span>
                     <Zap size={14} className="fill-white" />
                 </div>
                 <div className="flex items-baseline gap-1">
                    <h3 className="text-2xl font-black">¥325.00</h3>
                    <span className="text-[10px] opacity-80">今日发现</span>
                 </div>
                 <div className="mt-3 bg-white/20 h-1.5 rounded-full overflow-hidden">
                     <div className="bg-white w-[60%] h-full rounded-full"></div>
                 </div>
             </div>
        </div>
    );
};

// 4. Task List Template
const TaskListView: React.FC<{ data: any }> = ({ data }) => {
    const items = Array.isArray(data) ? data : (data.items || []);

    return (
        <div className="p-4 space-y-4">
            {items.length === 0 ? (
                <div className="text-center text-gray-400 py-10">
                    <CheckSquare size={48} className="mx-auto mb-3 opacity-20" />
                    <p className="text-xs">No tasks yet</p>
                </div>
            ) : (
                <div className="space-y-3">
                    {items.map((item: any, idx: number) => (
                        <div key={idx} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-start gap-3 group hover:border-blue-200 transition-colors">
                            <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${item.status === 'Done' ? 'bg-green-500 border-green-500' : 'border-gray-300 group-hover:border-blue-400'}`}>
                                {item.status === 'Done' && <LucideIcons.Check size={12} className="text-white" />}
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className={`text-sm font-bold text-gray-800 leading-snug ${item.status === 'Done' ? 'line-through text-gray-400' : ''}`}>
                                    {item.title}
                                </h3>
                                <div className="flex items-center gap-2 mt-1.5">
                                    <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${
                                        item.priority === 'High' ? 'bg-red-50 text-red-500' :
                                        item.priority === 'Medium' ? 'bg-orange-50 text-orange-500' :
                                        'bg-blue-50 text-blue-500'
                                    }`}>
                                        {item.priority}
                                    </span>
                                    <span className="text-[9px] text-gray-400 flex items-center gap-1">
                                        <LucideIcons.User size={10} /> {item.assignee}
                                    </span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

// 5. Generative App Template
const GenerativeAppView: React.FC<{ data: any }> = ({ data }) => {
    const widgets = data.widgets || [];
    const [states, setStates] = useState<Record<number, any>>({});

    const handleToggle = (idx: number) => {
        setStates(prev => ({ ...prev, [idx]: !prev[idx] }));
    };

    return (
        <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 gap-3">
                {widgets.map((widget: any, idx: number) => {
                    const Icon = (LucideIcons as any)[widget.icon] || LucideIcons.Circle;
                    const isFullWidth = widget.type === 'list' || widget.type === 'chart' || widget.type === 'text';
                    
                    return (
                        <div 
                            key={idx} 
                            className={`bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col gap-2 transition-all hover:border-blue-100 ${isFullWidth ? 'col-span-2' : ''}`}
                        >
                            <div className="flex justify-between items-start">
                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{widget.label}</span>
                                <Icon size={14} className={widget.color || 'text-gray-400'} />
                            </div>

                            {widget.type === 'stat' && (
                                <div className="flex items-baseline gap-1.5">
                                    <span className="text-xl font-black text-gray-900">{widget.value}</span>
                                    {widget.subValue && <span className="text-[10px] text-gray-400 font-medium">{widget.subValue}</span>}
                                </div>
                            )}

                            {widget.type === 'button' && (
                                <button 
                                    className="w-full mt-1 py-2 bg-black text-white rounded-xl text-xs font-bold shadow-md active:scale-95 transition-transform"
                                    onClick={() => alert(`执行操作: ${widget.action}`)}
                                >
                                    {widget.value || '执行'}
                                </button>
                            )}

                            {widget.type === 'toggle' && (
                                <div className="flex justify-between items-center mt-1">
                                    <span className="text-xs font-bold text-gray-700">{states[idx] ? '已开启' : '已关闭'}</span>
                                    <button 
                                        onClick={() => handleToggle(idx)}
                                        className={`w-10 h-5 rounded-full relative transition-colors ${states[idx] ? 'bg-green-500' : 'bg-gray-200'}`}
                                    >
                                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${states[idx] ? 'left-6' : 'left-1'}`}></div>
                                    </button>
                                </div>
                            )}

                            {widget.type === 'list' && (
                                <div className="space-y-2 mt-1">
                                    {(widget.data || []).map((item: any, i: number) => (
                                        <div key={i} className="flex justify-between items-center p-2 bg-gray-50 rounded-lg border border-gray-100">
                                            <span className="text-[11px] font-medium text-gray-700">{item.label || item}</span>
                                            <span className="text-[10px] font-bold text-gray-900">{item.value}</span>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {widget.type === 'chart' && (
                                <div className="mt-2 h-16 flex items-end gap-1 px-1">
                                    {(widget.data || [40, 70, 45, 90, 65, 80, 50]).map((v: number, i: number) => (
                                        <div 
                                            key={i} 
                                            className="flex-1 bg-blue-500/20 rounded-t-sm relative group"
                                            style={{ height: `${v}%` }}
                                        >
                                            <div className="absolute inset-0 bg-blue-500 rounded-t-sm opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {widget.type === 'text' && (
                                <p className="text-xs text-gray-600 leading-relaxed mt-1">
                                    {widget.value}
                                </p>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

// Helper Wrapper for Flashcard Sparkline to reuse
const SparklesSparkline = (props: any) => <Sparkline {...props} />;

export default MiniAppRenderer;
