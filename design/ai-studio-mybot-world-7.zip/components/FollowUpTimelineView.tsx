import React from 'react';
import { X, CheckCircle, Clock, CalendarClock } from 'lucide-react';

export interface FollowUpItem {
  id: string;
  time: string;
  content: string;
  owner: string;
  status: 'pending' | 'done';
}

interface FollowUpTimelineViewProps {
  items: FollowUpItem[];
  onClose: () => void;
  onAddToTask: (task: string) => void;
}

const FollowUpTimelineView: React.FC<FollowUpTimelineViewProps> = ({ items, onClose, onAddToTask }) => {
  const [addedItems, setAddedItems] = React.useState<Set<string>>(new Set());

  const handleAdd = (id: string, content: string) => {
    onAddToTask(content);
    setAddedItems(prev => new Set(prev).add(id));
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#1c1c1e] w-full max-w-md h-[80vh] rounded-[32px] shadow-2xl border border-white/10 flex flex-col overflow-hidden relative animate-scale-in">
        
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex justify-between items-center bg-white/5 shrink-0">
            <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 border border-blue-500/30">
                    <CalendarClock size={20} />
                </div>
                <div>
                    <h2 className="text-white font-bold text-base">Follow-up Items</h2>
                    <p className="text-[10px] text-gray-400">AI-Generated Timeline</p>
                </div>
            </div>
            <button onClick={onClose} className="p-2 bg-white/10 rounded-full text-white/70 hover:text-white hover:bg-white/20 transition-colors">
                <X size={20} />
            </button>
        </div>

        {/* Timeline */}
        <div className="flex-1 overflow-y-auto p-6 relative custom-scrollbar">
            {/* Vertical Line */}
            <div className="absolute left-[34px] top-6 bottom-6 w-[2px] bg-gradient-to-b from-blue-500/50 via-white/10 to-transparent rounded-full"></div>

            <div className="space-y-6">
                {items.map((item, index) => (
                    <div key={item.id} className="relative pl-12 group animate-slide-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                        {/* Dot */}
                        <div className="absolute left-[29px] top-4 w-3 h-3 rounded-full bg-[#1c1c1e] border-2 border-blue-500 z-10 group-hover:scale-125 transition-transform shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>
                        
                        {/* Card */}
                        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 hover:bg-white/10 transition-all duration-300 hover:border-white/20 hover:shadow-lg group-hover:translate-x-1">
                            <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-1.5 text-[10px] text-blue-300 font-mono bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                                    <Clock size={10} />
                                    {item.time}
                                </div>
                                <div className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded border ${item.status === 'done' ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-orange-500/10 text-orange-300 border-orange-500/20'}`}>
                                    {item.status === 'done' ? <CheckCircle size={10} /> : <div className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse"></div>}
                                    {item.status === 'done' ? 'Resolved' : 'Action Req'}
                                </div>
                            </div>
                            
                            <p className="text-sm text-gray-200 font-medium leading-relaxed mb-3">
                                {item.content}
                            </p>

                            <div className="flex items-center justify-between pt-2 border-t border-white/5">
                                <div className="flex items-center gap-2">
                                    <div className="w-5 h-5 rounded-full bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center text-[10px] text-white font-bold shadow-sm">
                                        {item.owner.charAt(0)}
                                    </div>
                                    <span className="text-xs text-gray-400 font-medium">{item.owner}</span>
                                </div>
                                <div className="flex gap-2">
                                    <button 
                                        onClick={() => handleAdd(item.id, item.content)}
                                        disabled={addedItems.has(item.id)}
                                        className={`text-[10px] px-2 py-1 rounded transition-colors ${
                                            addedItems.has(item.id) 
                                            ? 'bg-green-600/20 text-green-400 cursor-default' 
                                            : 'bg-blue-600 hover:bg-blue-500 text-white'
                                        }`}
                                    >
                                        {addedItems.has(item.id) ? 'Added' : 'Add to MyTask'}
                                    </button>
                                    <button className="text-[10px] text-white/40 hover:text-white transition-colors">
                                        View Context &rarr;
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
                
                {items.length === 0 && (
                    <div className="text-center text-gray-500 py-10">
                        No follow-up items detected.
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default FollowUpTimelineView;
